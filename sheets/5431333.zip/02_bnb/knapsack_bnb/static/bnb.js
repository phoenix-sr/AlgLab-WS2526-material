var e = Object.defineProperty,
  t = (t) => {
    let n = {};
    for (var r in t) e(n, r, { get: t[r], enumerable: !0 });
    return n;
  },
  n = `bottom`,
  r = `right`,
  i = `left`,
  a = `auto`,
  o = [`top`, n, r, i],
  s = `start`,
  c = `clippingParents`,
  l = `viewport`,
  u = `popper`,
  d = `reference`,
  f = o.reduce(function (e, t) {
    return e.concat([t + `-` + s, t + `-end`]);
  }, []),
  p = [].concat(o, [a]).reduce(function (e, t) {
    return e.concat([t, t + `-` + s, t + `-end`]);
  }, []),
  m = `beforeRead`,
  h = `read`,
  g = `afterRead`,
  _ = `beforeMain`,
  v = `main`,
  y = `afterMain`,
  b = `beforeWrite`,
  x = `write`,
  S = `afterWrite`,
  C = [m, h, g, _, v, y, b, x, S];
function w(e) {
  return e ? (e.nodeName || ``).toLowerCase() : null;
}
function T(e) {
  if (e == null) return window;
  if (e.toString() !== `[object Window]`) {
    var t = e.ownerDocument;
    return (t && t.defaultView) || window;
  }
  return e;
}
function E(e) {
  return e instanceof T(e).Element || e instanceof Element;
}
function D(e) {
  return e instanceof T(e).HTMLElement || e instanceof HTMLElement;
}
function O(e) {
  return typeof ShadowRoot > `u`
    ? !1
    : e instanceof T(e).ShadowRoot || e instanceof ShadowRoot;
}
function k(e) {
  var t = e.state;
  Object.keys(t.elements).forEach(function (e) {
    var n = t.styles[e] || {},
      r = t.attributes[e] || {},
      i = t.elements[e];
    !D(i) ||
      !w(i) ||
      (Object.assign(i.style, n),
      Object.keys(r).forEach(function (e) {
        var t = r[e];
        t === !1 ? i.removeAttribute(e) : i.setAttribute(e, t === !0 ? `` : t);
      }));
  });
}
function A(e) {
  var t = e.state,
    n = {
      popper: {
        position: t.options.strategy,
        left: `0`,
        top: `0`,
        margin: `0`,
      },
      arrow: { position: `absolute` },
      reference: {},
    };
  return (
    Object.assign(t.elements.popper.style, n.popper),
    (t.styles = n),
    t.elements.arrow && Object.assign(t.elements.arrow.style, n.arrow),
    function () {
      Object.keys(t.elements).forEach(function (e) {
        var r = t.elements[e],
          i = t.attributes[e] || {},
          a = Object.keys(
            t.styles.hasOwnProperty(e) ? t.styles[e] : n[e],
          ).reduce(function (e, t) {
            return (e[t] = ``), e;
          }, {});
        !D(r) ||
          !w(r) ||
          (Object.assign(r.style, a),
          Object.keys(i).forEach(function (e) {
            r.removeAttribute(e);
          }));
      });
    }
  );
}
var j = {
  name: `applyStyles`,
  enabled: !0,
  phase: `write`,
  fn: k,
  effect: A,
  requires: [`computeStyles`],
};
function M(e) {
  return e.split(`-`)[0];
}
var N = Math.max,
  ee = Math.min,
  P = Math.round;
function te() {
  var e = navigator.userAgentData;
  return e != null && e.brands && Array.isArray(e.brands)
    ? e.brands
        .map(function (e) {
          return e.brand + `/` + e.version;
        })
        .join(` `)
    : navigator.userAgent;
}
function F() {
  return !/^((?!chrome|android).)*safari/i.test(te());
}
function I(e, t, n) {
  t === void 0 && (t = !1), n === void 0 && (n = !1);
  var r = e.getBoundingClientRect(),
    i = 1,
    a = 1;
  t &&
    D(e) &&
    ((i = (e.offsetWidth > 0 && P(r.width) / e.offsetWidth) || 1),
    (a = (e.offsetHeight > 0 && P(r.height) / e.offsetHeight) || 1));
  var o = (E(e) ? T(e) : window).visualViewport,
    s = !F() && n,
    c = (r.left + (s && o ? o.offsetLeft : 0)) / i,
    l = (r.top + (s && o ? o.offsetTop : 0)) / a,
    u = r.width / i,
    d = r.height / a;
  return {
    width: u,
    height: d,
    top: l,
    right: c + u,
    bottom: l + d,
    left: c,
    x: c,
    y: l,
  };
}
function ne(e) {
  var t = I(e),
    n = e.offsetWidth,
    r = e.offsetHeight;
  return (
    Math.abs(t.width - n) <= 1 && (n = t.width),
    Math.abs(t.height - r) <= 1 && (r = t.height),
    { x: e.offsetLeft, y: e.offsetTop, width: n, height: r }
  );
}
function re(e, t) {
  var n = t.getRootNode && t.getRootNode();
  if (e.contains(t)) return !0;
  if (n && O(n)) {
    var r = t;
    do {
      if (r && e.isSameNode(r)) return !0;
      r = r.parentNode || r.host;
    } while (r);
  }
  return !1;
}
function L(e) {
  return T(e).getComputedStyle(e);
}
function ie(e) {
  return [`table`, `td`, `th`].indexOf(w(e)) >= 0;
}
function ae(e) {
  return ((E(e) ? e.ownerDocument : e.document) || window.document)
    .documentElement;
}
function oe(e) {
  return w(e) === `html`
    ? e
    : e.assignedSlot || e.parentNode || (O(e) ? e.host : null) || ae(e);
}
function se(e) {
  return !D(e) || L(e).position === `fixed` ? null : e.offsetParent;
}
function ce(e) {
  var t = /firefox/i.test(te());
  if (/Trident/i.test(te()) && D(e) && L(e).position === `fixed`) return null;
  var n = oe(e);
  for (O(n) && (n = n.host); D(n) && [`html`, `body`].indexOf(w(n)) < 0; ) {
    var r = L(n);
    if (
      r.transform !== `none` ||
      r.perspective !== `none` ||
      r.contain === `paint` ||
      [`transform`, `perspective`].indexOf(r.willChange) !== -1 ||
      (t && r.willChange === `filter`) ||
      (t && r.filter && r.filter !== `none`)
    )
      return n;
    n = n.parentNode;
  }
  return null;
}
function le(e) {
  for (var t = T(e), n = se(e); n && ie(n) && L(n).position === `static`; )
    n = se(n);
  return n &&
    (w(n) === `html` || (w(n) === `body` && L(n).position === `static`))
    ? t
    : n || ce(e) || t;
}
function ue(e) {
  return [`top`, `bottom`].indexOf(e) >= 0 ? `x` : `y`;
}
function de(e, t, n) {
  return N(e, ee(t, n));
}
function fe(e, t, n) {
  var r = de(e, t, n);
  return r > n ? n : r;
}
function pe() {
  return { top: 0, right: 0, bottom: 0, left: 0 };
}
function me(e) {
  return Object.assign({}, pe(), e);
}
function he(e, t) {
  return t.reduce(function (t, n) {
    return (t[n] = e), t;
  }, {});
}
var ge = function (e, t) {
  return (
    (e =
      typeof e == `function`
        ? e(Object.assign({}, t.rects, { placement: t.placement }))
        : e),
    me(typeof e == `number` ? he(e, o) : e)
  );
};
function _e(e) {
  var t,
    a = e.state,
    o = e.name,
    s = e.options,
    c = a.elements.arrow,
    l = a.modifiersData.popperOffsets,
    u = M(a.placement),
    d = ue(u),
    f = [`left`, `right`].indexOf(u) >= 0 ? `height` : `width`;
  if (!(!c || !l)) {
    var p = ge(s.padding, a),
      m = ne(c),
      h = d === `y` ? `top` : i,
      g = d === `y` ? n : r,
      _ =
        a.rects.reference[f] + a.rects.reference[d] - l[d] - a.rects.popper[f],
      v = l[d] - a.rects.reference[d],
      y = le(c),
      b = y ? (d === `y` ? y.clientHeight || 0 : y.clientWidth || 0) : 0,
      x = _ / 2 - v / 2,
      S = p[h],
      C = b - m[f] - p[g],
      w = b / 2 - m[f] / 2 + x,
      T = de(S, w, C),
      E = d;
    a.modifiersData[o] = ((t = {}), (t[E] = T), (t.centerOffset = T - w), t);
  }
}
function ve(e) {
  var t = e.state,
    n = e.options.element,
    r = n === void 0 ? `[data-popper-arrow]` : n;
  r != null &&
    ((typeof r == `string` && ((r = t.elements.popper.querySelector(r)), !r)) ||
      (re(t.elements.popper, r) && (t.elements.arrow = r)));
}
var ye = {
  name: `arrow`,
  enabled: !0,
  phase: `main`,
  fn: _e,
  effect: ve,
  requires: [`popperOffsets`],
  requiresIfExists: [`preventOverflow`],
};
function be(e) {
  return e.split(`-`)[1];
}
var xe = { top: `auto`, right: `auto`, bottom: `auto`, left: `auto` };
function Se(e, t) {
  var n = e.x,
    r = e.y,
    i = t.devicePixelRatio || 1;
  return { x: P(n * i) / i || 0, y: P(r * i) / i || 0 };
}
function Ce(e) {
  var t,
    a = e.popper,
    o = e.popperRect,
    s = e.placement,
    c = e.variation,
    l = e.offsets,
    u = e.position,
    d = e.gpuAcceleration,
    f = e.adaptive,
    p = e.roundOffsets,
    m = e.isFixed,
    h = l.x,
    g = h === void 0 ? 0 : h,
    _ = l.y,
    v = _ === void 0 ? 0 : _,
    y = typeof p == `function` ? p({ x: g, y: v }) : { x: g, y: v };
  (g = y.x), (v = y.y);
  var b = l.hasOwnProperty(`x`),
    x = l.hasOwnProperty(`y`),
    S = i,
    C = `top`,
    w = window;
  if (f) {
    var E = le(a),
      D = `clientHeight`,
      O = `clientWidth`;
    if (
      (E === T(a) &&
        ((E = ae(a)),
        L(E).position !== `static` &&
          u === `absolute` &&
          ((D = `scrollHeight`), (O = `scrollWidth`))),
      (E = E),
      s === `top` || ((s === `left` || s === `right`) && c === `end`))
    ) {
      C = n;
      var k = m && E === w && w.visualViewport ? w.visualViewport.height : E[D];
      (v -= k - o.height), (v *= d ? 1 : -1);
    }
    if (s === `left` || ((s === `top` || s === `bottom`) && c === `end`)) {
      S = r;
      var A = m && E === w && w.visualViewport ? w.visualViewport.width : E[O];
      (g -= A - o.width), (g *= d ? 1 : -1);
    }
  }
  var j = Object.assign({ position: u }, f && xe),
    M = p === !0 ? Se({ x: g, y: v }, T(a)) : { x: g, y: v };
  if (((g = M.x), (v = M.y), d)) {
    var N;
    return Object.assign(
      {},
      j,
      ((N = {}),
      (N[C] = x ? `0` : ``),
      (N[S] = b ? `0` : ``),
      (N.transform =
        (w.devicePixelRatio || 1) <= 1
          ? `translate(` + g + `px, ` + v + `px)`
          : `translate3d(` + g + `px, ` + v + `px, 0)`),
      N),
    );
  }
  return Object.assign(
    {},
    j,
    ((t = {}),
    (t[C] = x ? v + `px` : ``),
    (t[S] = b ? g + `px` : ``),
    (t.transform = ``),
    t),
  );
}
function we(e) {
  var t = e.state,
    n = e.options,
    r = n.gpuAcceleration,
    i = r === void 0 ? !0 : r,
    a = n.adaptive,
    o = a === void 0 ? !0 : a,
    s = n.roundOffsets,
    c = s === void 0 ? !0 : s,
    l = {
      placement: M(t.placement),
      variation: be(t.placement),
      popper: t.elements.popper,
      popperRect: t.rects.popper,
      gpuAcceleration: i,
      isFixed: t.options.strategy === `fixed`,
    };
  t.modifiersData.popperOffsets != null &&
    (t.styles.popper = Object.assign(
      {},
      t.styles.popper,
      Ce(
        Object.assign({}, l, {
          offsets: t.modifiersData.popperOffsets,
          position: t.options.strategy,
          adaptive: o,
          roundOffsets: c,
        }),
      ),
    )),
    t.modifiersData.arrow != null &&
      (t.styles.arrow = Object.assign(
        {},
        t.styles.arrow,
        Ce(
          Object.assign({}, l, {
            offsets: t.modifiersData.arrow,
            position: `absolute`,
            adaptive: !1,
            roundOffsets: c,
          }),
        ),
      )),
    (t.attributes.popper = Object.assign({}, t.attributes.popper, {
      "data-popper-placement": t.placement,
    }));
}
var Te = {
    name: `computeStyles`,
    enabled: !0,
    phase: `beforeWrite`,
    fn: we,
    data: {},
  },
  Ee = { passive: !0 };
function De(e) {
  var t = e.state,
    n = e.instance,
    r = e.options,
    i = r.scroll,
    a = i === void 0 ? !0 : i,
    o = r.resize,
    s = o === void 0 ? !0 : o,
    c = T(t.elements.popper),
    l = [].concat(t.scrollParents.reference, t.scrollParents.popper);
  return (
    a &&
      l.forEach(function (e) {
        e.addEventListener(`scroll`, n.update, Ee);
      }),
    s && c.addEventListener(`resize`, n.update, Ee),
    function () {
      a &&
        l.forEach(function (e) {
          e.removeEventListener(`scroll`, n.update, Ee);
        }),
        s && c.removeEventListener(`resize`, n.update, Ee);
    }
  );
}
var Oe = {
    name: `eventListeners`,
    enabled: !0,
    phase: `write`,
    fn: function () {},
    effect: De,
    data: {},
  },
  ke = { left: `right`, right: `left`, bottom: `top`, top: `bottom` };
function Ae(e) {
  return e.replace(/left|right|bottom|top/g, function (e) {
    return ke[e];
  });
}
var je = { start: `end`, end: `start` };
function Me(e) {
  return e.replace(/start|end/g, function (e) {
    return je[e];
  });
}
function Ne(e) {
  var t = T(e);
  return { scrollLeft: t.pageXOffset, scrollTop: t.pageYOffset };
}
function Pe(e) {
  return I(ae(e)).left + Ne(e).scrollLeft;
}
function Fe(e, t) {
  var n = T(e),
    r = ae(e),
    i = n.visualViewport,
    a = r.clientWidth,
    o = r.clientHeight,
    s = 0,
    c = 0;
  if (i) {
    (a = i.width), (o = i.height);
    var l = F();
    (l || (!l && t === `fixed`)) && ((s = i.offsetLeft), (c = i.offsetTop));
  }
  return { width: a, height: o, x: s + Pe(e), y: c };
}
function Ie(e) {
  var t = ae(e),
    n = Ne(e),
    r = e.ownerDocument?.body,
    i = N(
      t.scrollWidth,
      t.clientWidth,
      r ? r.scrollWidth : 0,
      r ? r.clientWidth : 0,
    ),
    a = N(
      t.scrollHeight,
      t.clientHeight,
      r ? r.scrollHeight : 0,
      r ? r.clientHeight : 0,
    ),
    o = -n.scrollLeft + Pe(e),
    s = -n.scrollTop;
  return (
    L(r || t).direction === `rtl` &&
      (o += N(t.clientWidth, r ? r.clientWidth : 0) - i),
    { width: i, height: a, x: o, y: s }
  );
}
function Le(e) {
  var t = L(e),
    n = t.overflow,
    r = t.overflowX,
    i = t.overflowY;
  return /auto|scroll|overlay|hidden/.test(n + i + r);
}
function Re(e) {
  return [`html`, `body`, `#document`].indexOf(w(e)) >= 0
    ? e.ownerDocument.body
    : D(e) && Le(e)
    ? e
    : Re(oe(e));
}
function ze(e, t) {
  t === void 0 && (t = []);
  var n = Re(e),
    r = n === e.ownerDocument?.body,
    i = T(n),
    a = r ? [i].concat(i.visualViewport || [], Le(n) ? n : []) : n,
    o = t.concat(a);
  return r ? o : o.concat(ze(oe(a)));
}
function Be(e) {
  return Object.assign({}, e, {
    left: e.x,
    top: e.y,
    right: e.x + e.width,
    bottom: e.y + e.height,
  });
}
function Ve(e, t) {
  var n = I(e, !1, t === `fixed`);
  return (
    (n.top += e.clientTop),
    (n.left += e.clientLeft),
    (n.bottom = n.top + e.clientHeight),
    (n.right = n.left + e.clientWidth),
    (n.width = e.clientWidth),
    (n.height = e.clientHeight),
    (n.x = n.left),
    (n.y = n.top),
    n
  );
}
function He(e, t, n) {
  return t === `viewport` ? Be(Fe(e, n)) : E(t) ? Ve(t, n) : Be(Ie(ae(e)));
}
function Ue(e) {
  var t = ze(oe(e)),
    n = [`absolute`, `fixed`].indexOf(L(e).position) >= 0 && D(e) ? le(e) : e;
  return E(n)
    ? t.filter(function (e) {
        return E(e) && re(e, n) && w(e) !== `body`;
      })
    : [];
}
function We(e, t, n, r) {
  var i = t === `clippingParents` ? Ue(e) : [].concat(t),
    a = [].concat(i, [n]),
    o = a[0],
    s = a.reduce(
      function (t, n) {
        var i = He(e, n, r);
        return (
          (t.top = N(i.top, t.top)),
          (t.right = ee(i.right, t.right)),
          (t.bottom = ee(i.bottom, t.bottom)),
          (t.left = N(i.left, t.left)),
          t
        );
      },
      He(e, o, r),
    );
  return (
    (s.width = s.right - s.left),
    (s.height = s.bottom - s.top),
    (s.x = s.left),
    (s.y = s.top),
    s
  );
}
function Ge(e) {
  var t = e.reference,
    a = e.element,
    o = e.placement,
    c = o ? M(o) : null,
    l = o ? be(o) : null,
    u = t.x + t.width / 2 - a.width / 2,
    d = t.y + t.height / 2 - a.height / 2,
    f;
  switch (c) {
    case `top`:
      f = { x: u, y: t.y - a.height };
      break;
    case n:
      f = { x: u, y: t.y + t.height };
      break;
    case r:
      f = { x: t.x + t.width, y: d };
      break;
    case i:
      f = { x: t.x - a.width, y: d };
      break;
    default:
      f = { x: t.x, y: t.y };
  }
  var p = c ? ue(c) : null;
  if (p != null) {
    var m = p === `y` ? `height` : `width`;
    switch (l) {
      case s:
        f[p] = f[p] - (t[m] / 2 - a[m] / 2);
        break;
      case `end`:
        f[p] = f[p] + (t[m] / 2 - a[m] / 2);
        break;
      default:
    }
  }
  return f;
}
function Ke(e, t) {
  t === void 0 && (t = {});
  var n = t,
    r = n.placement,
    i = r === void 0 ? e.placement : r,
    a = n.strategy,
    s = a === void 0 ? e.strategy : a,
    f = n.boundary,
    p = f === void 0 ? c : f,
    m = n.rootBoundary,
    h = m === void 0 ? l : m,
    g = n.elementContext,
    _ = g === void 0 ? u : g,
    v = n.altBoundary,
    y = v === void 0 ? !1 : v,
    b = n.padding,
    x = b === void 0 ? 0 : b,
    S = me(typeof x == `number` ? he(x, o) : x),
    C = _ === `popper` ? d : u,
    w = e.rects.popper,
    T = e.elements[y ? C : _],
    D = We(E(T) ? T : T.contextElement || ae(e.elements.popper), p, h, s),
    O = I(e.elements.reference),
    k = Ge({ reference: O, element: w, strategy: `absolute`, placement: i }),
    A = Be(Object.assign({}, w, k)),
    j = _ === `popper` ? A : O,
    M = {
      top: D.top - j.top + S.top,
      bottom: j.bottom - D.bottom + S.bottom,
      left: D.left - j.left + S.left,
      right: j.right - D.right + S.right,
    },
    N = e.modifiersData.offset;
  if (_ === `popper` && N) {
    var ee = N[i];
    Object.keys(M).forEach(function (e) {
      var t = [`right`, `bottom`].indexOf(e) >= 0 ? 1 : -1,
        n = [`top`, `bottom`].indexOf(e) >= 0 ? `y` : `x`;
      M[e] += ee[n] * t;
    });
  }
  return M;
}
function qe(e, t) {
  t === void 0 && (t = {});
  var n = t,
    r = n.placement,
    i = n.boundary,
    a = n.rootBoundary,
    s = n.padding,
    c = n.flipVariations,
    l = n.allowedAutoPlacements,
    u = l === void 0 ? p : l,
    d = be(r),
    m = d
      ? c
        ? f
        : f.filter(function (e) {
            return be(e) === d;
          })
      : o,
    h = m.filter(function (e) {
      return u.indexOf(e) >= 0;
    });
  h.length === 0 && (h = m);
  var g = h.reduce(function (t, n) {
    return (
      (t[n] = Ke(e, { placement: n, boundary: i, rootBoundary: a, padding: s })[
        M(n)
      ]),
      t
    );
  }, {});
  return Object.keys(g).sort(function (e, t) {
    return g[e] - g[t];
  });
}
function Je(e) {
  if (M(e) === `auto`) return [];
  var t = Ae(e);
  return [Me(e), t, Me(t)];
}
function Ye(e) {
  var t = e.state,
    a = e.options,
    o = e.name;
  if (!t.modifiersData[o]._skip) {
    for (
      var c = a.mainAxis,
        l = c === void 0 ? !0 : c,
        u = a.altAxis,
        d = u === void 0 ? !0 : u,
        f = a.fallbackPlacements,
        p = a.padding,
        m = a.boundary,
        h = a.rootBoundary,
        g = a.altBoundary,
        _ = a.flipVariations,
        v = _ === void 0 ? !0 : _,
        y = a.allowedAutoPlacements,
        b = t.options.placement,
        x = M(b) === b,
        S = f || (x || !v ? [Ae(b)] : Je(b)),
        C = [b].concat(S).reduce(function (e, n) {
          return e.concat(
            M(n) === `auto`
              ? qe(t, {
                  placement: n,
                  boundary: m,
                  rootBoundary: h,
                  padding: p,
                  flipVariations: v,
                  allowedAutoPlacements: y,
                })
              : n,
          );
        }, []),
        w = t.rects.reference,
        T = t.rects.popper,
        E = new Map(),
        D = !0,
        O = C[0],
        k = 0;
      k < C.length;
      k++
    ) {
      var A = C[k],
        j = M(A),
        N = be(A) === s,
        ee = [`top`, n].indexOf(j) >= 0,
        P = ee ? `width` : `height`,
        te = Ke(t, {
          placement: A,
          boundary: m,
          rootBoundary: h,
          altBoundary: g,
          padding: p,
        }),
        F = ee ? (N ? r : i) : N ? n : `top`;
      w[P] > T[P] && (F = Ae(F));
      var I = Ae(F),
        ne = [];
      if (
        (l && ne.push(te[j] <= 0),
        d && ne.push(te[F] <= 0, te[I] <= 0),
        ne.every(function (e) {
          return e;
        }))
      ) {
        (O = A), (D = !1);
        break;
      }
      E.set(A, ne);
    }
    if (D)
      for (
        var re = v ? 3 : 1,
          L = function (e) {
            var t = C.find(function (t) {
              var n = E.get(t);
              if (n)
                return n.slice(0, e).every(function (e) {
                  return e;
                });
            });
            if (t) return (O = t), `break`;
          },
          ie = re;
        ie > 0 && L(ie) !== `break`;
        ie--
      );
    t.placement !== O &&
      ((t.modifiersData[o]._skip = !0), (t.placement = O), (t.reset = !0));
  }
}
var Xe = {
  name: `flip`,
  enabled: !0,
  phase: `main`,
  fn: Ye,
  requiresIfExists: [`offset`],
  data: { _skip: !1 },
};
function Ze(e, t, n) {
  return (
    n === void 0 && (n = { x: 0, y: 0 }),
    {
      top: e.top - t.height - n.y,
      right: e.right - t.width + n.x,
      bottom: e.bottom - t.height + n.y,
      left: e.left - t.width - n.x,
    }
  );
}
function Qe(e) {
  return [`top`, r, n, i].some(function (t) {
    return e[t] >= 0;
  });
}
function $e(e) {
  var t = e.state,
    n = e.name,
    r = t.rects.reference,
    i = t.rects.popper,
    a = t.modifiersData.preventOverflow,
    o = Ke(t, { elementContext: `reference` }),
    s = Ke(t, { altBoundary: !0 }),
    c = Ze(o, r),
    l = Ze(s, i, a),
    u = Qe(c),
    d = Qe(l);
  (t.modifiersData[n] = {
    referenceClippingOffsets: c,
    popperEscapeOffsets: l,
    isReferenceHidden: u,
    hasPopperEscaped: d,
  }),
    (t.attributes.popper = Object.assign({}, t.attributes.popper, {
      "data-popper-reference-hidden": u,
      "data-popper-escaped": d,
    }));
}
var et = {
  name: `hide`,
  enabled: !0,
  phase: `main`,
  requiresIfExists: [`preventOverflow`],
  fn: $e,
};
function tt(e, t, n) {
  var r = M(e),
    i = [`left`, `top`].indexOf(r) >= 0 ? -1 : 1,
    a = typeof n == `function` ? n(Object.assign({}, t, { placement: e })) : n,
    o = a[0],
    s = a[1];
  return (
    (o ||= 0),
    (s = (s || 0) * i),
    [`left`, `right`].indexOf(r) >= 0 ? { x: s, y: o } : { x: o, y: s }
  );
}
function nt(e) {
  var t = e.state,
    n = e.options,
    r = e.name,
    i = n.offset,
    a = i === void 0 ? [0, 0] : i,
    o = p.reduce(function (e, n) {
      return (e[n] = tt(n, t.rects, a)), e;
    }, {}),
    s = o[t.placement],
    c = s.x,
    l = s.y;
  t.modifiersData.popperOffsets != null &&
    ((t.modifiersData.popperOffsets.x += c),
    (t.modifiersData.popperOffsets.y += l)),
    (t.modifiersData[r] = o);
}
var rt = {
  name: `offset`,
  enabled: !0,
  phase: `main`,
  requires: [`popperOffsets`],
  fn: nt,
};
function it(e) {
  var t = e.state,
    n = e.name;
  t.modifiersData[n] = Ge({
    reference: t.rects.reference,
    element: t.rects.popper,
    strategy: `absolute`,
    placement: t.placement,
  });
}
var at = {
  name: `popperOffsets`,
  enabled: !0,
  phase: `read`,
  fn: it,
  data: {},
};
function ot(e) {
  return e === `x` ? `y` : `x`;
}
function st(e) {
  var t = e.state,
    a = e.options,
    o = e.name,
    s = a.mainAxis,
    c = s === void 0 ? !0 : s,
    l = a.altAxis,
    u = l === void 0 ? !1 : l,
    d = a.boundary,
    f = a.rootBoundary,
    p = a.altBoundary,
    m = a.padding,
    h = a.tether,
    g = h === void 0 ? !0 : h,
    _ = a.tetherOffset,
    v = _ === void 0 ? 0 : _,
    y = Ke(t, { boundary: d, rootBoundary: f, padding: m, altBoundary: p }),
    b = M(t.placement),
    x = be(t.placement),
    S = !x,
    C = ue(b),
    w = ot(C),
    T = t.modifiersData.popperOffsets,
    E = t.rects.reference,
    D = t.rects.popper,
    O =
      typeof v == `function`
        ? v(Object.assign({}, t.rects, { placement: t.placement }))
        : v,
    k =
      typeof O == `number`
        ? { mainAxis: O, altAxis: O }
        : Object.assign({ mainAxis: 0, altAxis: 0 }, O),
    A = t.modifiersData.offset ? t.modifiersData.offset[t.placement] : null,
    j = { x: 0, y: 0 };
  if (T) {
    if (c) {
      var P = C === `y` ? `top` : i,
        te = C === `y` ? n : r,
        F = C === `y` ? `height` : `width`,
        I = T[C],
        re = I + y[P],
        L = I - y[te],
        ie = g ? -D[F] / 2 : 0,
        ae = x === `start` ? E[F] : D[F],
        oe = x === `start` ? -D[F] : -E[F],
        se = t.elements.arrow,
        ce = g && se ? ne(se) : { width: 0, height: 0 },
        me = t.modifiersData[`arrow#persistent`]
          ? t.modifiersData[`arrow#persistent`].padding
          : pe(),
        he = me[P],
        ge = me[te],
        _e = de(0, E[F], ce[F]),
        ve = S
          ? E[F] / 2 - ie - _e - he - k.mainAxis
          : ae - _e - he - k.mainAxis,
        ye = S
          ? -E[F] / 2 + ie + _e + ge + k.mainAxis
          : oe + _e + ge + k.mainAxis,
        xe = t.elements.arrow && le(t.elements.arrow),
        Se = xe ? (C === `y` ? xe.clientTop || 0 : xe.clientLeft || 0) : 0,
        Ce = A?.[C] ?? 0,
        we = I + ve - Ce - Se,
        Te = I + ye - Ce,
        Ee = de(g ? ee(re, we) : re, I, g ? N(L, Te) : L);
      (T[C] = Ee), (j[C] = Ee - I);
    }
    if (u) {
      var De = C === `x` ? `top` : i,
        Oe = C === `x` ? n : r,
        ke = T[w],
        Ae = w === `y` ? `height` : `width`,
        je = ke + y[De],
        Me = ke - y[Oe],
        Ne = [`top`, i].indexOf(b) !== -1,
        Pe = A?.[w] ?? 0,
        Fe = Ne ? je : ke - E[Ae] - D[Ae] - Pe + k.altAxis,
        Ie = Ne ? ke + E[Ae] + D[Ae] - Pe - k.altAxis : Me,
        Le = g && Ne ? fe(Fe, ke, Ie) : de(g ? Fe : je, ke, g ? Ie : Me);
      (T[w] = Le), (j[w] = Le - ke);
    }
    t.modifiersData[o] = j;
  }
}
var ct = {
  name: `preventOverflow`,
  enabled: !0,
  phase: `main`,
  fn: st,
  requiresIfExists: [`offset`],
};
function lt(e) {
  return { scrollLeft: e.scrollLeft, scrollTop: e.scrollTop };
}
function ut(e) {
  return e === T(e) || !D(e) ? Ne(e) : lt(e);
}
function dt(e) {
  var t = e.getBoundingClientRect(),
    n = P(t.width) / e.offsetWidth || 1,
    r = P(t.height) / e.offsetHeight || 1;
  return n !== 1 || r !== 1;
}
function ft(e, t, n) {
  n === void 0 && (n = !1);
  var r = D(t),
    i = D(t) && dt(t),
    a = ae(t),
    o = I(e, i, n),
    s = { scrollLeft: 0, scrollTop: 0 },
    c = { x: 0, y: 0 };
  return (
    (r || (!r && !n)) &&
      ((w(t) !== `body` || Le(a)) && (s = ut(t)),
      D(t)
        ? ((c = I(t, !0)), (c.x += t.clientLeft), (c.y += t.clientTop))
        : a && (c.x = Pe(a))),
    {
      x: o.left + s.scrollLeft - c.x,
      y: o.top + s.scrollTop - c.y,
      width: o.width,
      height: o.height,
    }
  );
}
function pt(e) {
  var t = new Map(),
    n = new Set(),
    r = [];
  e.forEach(function (e) {
    t.set(e.name, e);
  });
  function i(e) {
    n.add(e.name),
      []
        .concat(e.requires || [], e.requiresIfExists || [])
        .forEach(function (e) {
          if (!n.has(e)) {
            var r = t.get(e);
            r && i(r);
          }
        }),
      r.push(e);
  }
  return (
    e.forEach(function (e) {
      n.has(e.name) || i(e);
    }),
    r
  );
}
function mt(e) {
  var t = pt(e);
  return C.reduce(function (e, n) {
    return e.concat(
      t.filter(function (e) {
        return e.phase === n;
      }),
    );
  }, []);
}
function ht(e) {
  var t;
  return function () {
    return (
      (t ||= new Promise(function (n) {
        Promise.resolve().then(function () {
          (t = void 0), n(e());
        });
      })),
      t
    );
  };
}
function gt(e) {
  var t = e.reduce(function (e, t) {
    var n = e[t.name];
    return (
      (e[t.name] = n
        ? Object.assign({}, n, t, {
            options: Object.assign({}, n.options, t.options),
            data: Object.assign({}, n.data, t.data),
          })
        : t),
      e
    );
  }, {});
  return Object.keys(t).map(function (e) {
    return t[e];
  });
}
var _t = { placement: `bottom`, modifiers: [], strategy: `absolute` };
function vt() {
  return ![...arguments].some(function (e) {
    return !(e && typeof e.getBoundingClientRect == `function`);
  });
}
function yt(e) {
  e === void 0 && (e = {});
  var t = e,
    n = t.defaultModifiers,
    r = n === void 0 ? [] : n,
    i = t.defaultOptions,
    a = i === void 0 ? _t : i;
  return function (e, t, n) {
    n === void 0 && (n = a);
    var i = {
        placement: `bottom`,
        orderedModifiers: [],
        options: Object.assign({}, _t, a),
        modifiersData: {},
        elements: { reference: e, popper: t },
        attributes: {},
        styles: {},
      },
      o = [],
      s = !1,
      c = {
        state: i,
        setOptions: function (n) {
          var o = typeof n == `function` ? n(i.options) : n;
          return (
            u(),
            (i.options = Object.assign({}, a, i.options, o)),
            (i.scrollParents = {
              reference: E(e)
                ? ze(e)
                : e.contextElement
                ? ze(e.contextElement)
                : [],
              popper: ze(t),
            }),
            (i.orderedModifiers = mt(
              gt([].concat(r, i.options.modifiers)),
            ).filter(function (e) {
              return e.enabled;
            })),
            l(),
            c.update()
          );
        },
        forceUpdate: function () {
          if (!s) {
            var e = i.elements,
              t = e.reference,
              n = e.popper;
            if (vt(t, n)) {
              (i.rects = {
                reference: ft(t, le(n), i.options.strategy === `fixed`),
                popper: ne(n),
              }),
                (i.reset = !1),
                (i.placement = i.options.placement),
                i.orderedModifiers.forEach(function (e) {
                  return (i.modifiersData[e.name] = Object.assign({}, e.data));
                });
              for (var r = 0; r < i.orderedModifiers.length; r++) {
                if (i.reset === !0) {
                  (i.reset = !1), (r = -1);
                  continue;
                }
                var a = i.orderedModifiers[r],
                  o = a.fn,
                  l = a.options,
                  u = l === void 0 ? {} : l,
                  d = a.name;
                typeof o == `function` &&
                  (i = o({ state: i, options: u, name: d, instance: c }) || i);
              }
            }
          }
        },
        update: ht(function () {
          return new Promise(function (e) {
            c.forceUpdate(), e(i);
          });
        }),
        destroy: function () {
          u(), (s = !0);
        },
      };
    if (!vt(e, t)) return c;
    c.setOptions(n).then(function (e) {
      !s && n.onFirstUpdate && n.onFirstUpdate(e);
    });
    function l() {
      i.orderedModifiers.forEach(function (e) {
        var t = e.name,
          n = e.options,
          r = n === void 0 ? {} : n,
          a = e.effect;
        if (typeof a == `function`) {
          var s = a({ state: i, name: t, instance: c, options: r });
          o.push(s || function () {});
        }
      });
    }
    function u() {
      o.forEach(function (e) {
        return e();
      }),
        (o = []);
    }
    return c;
  };
}
var bt = yt(),
  xt = yt({ defaultModifiers: [Oe, at, Te, j] }),
  St = yt({ defaultModifiers: [Oe, at, Te, j, rt, Xe, ct, ye, et] }),
  Ct = t({
    afterMain: () => y,
    afterRead: () => g,
    afterWrite: () => S,
    applyStyles: () => j,
    arrow: () => ye,
    auto: () => a,
    basePlacements: () => o,
    beforeMain: () => _,
    beforeRead: () => m,
    beforeWrite: () => b,
    bottom: () => n,
    clippingParents: () => c,
    computeStyles: () => Te,
    createPopper: () => St,
    createPopperBase: () => bt,
    createPopperLite: () => xt,
    detectOverflow: () => Ke,
    end: () => `end`,
    eventListeners: () => Oe,
    flip: () => Xe,
    hide: () => et,
    left: () => i,
    main: () => v,
    modifierPhases: () => C,
    offset: () => rt,
    placements: () => p,
    popper: () => u,
    popperGenerator: () => yt,
    popperOffsets: () => at,
    preventOverflow: () => ct,
    read: () => h,
    reference: () => d,
    right: () => r,
    start: () => s,
    top: () => `top`,
    variationPlacements: () => f,
    viewport: () => l,
    write: () => x,
  }),
  wt = new Map(),
  Tt = {
    set(e, t, n) {
      wt.has(e) || wt.set(e, new Map());
      let r = wt.get(e);
      if (!r.has(t) && r.size !== 0) {
        console.error(
          `Bootstrap doesn't allow more than one instance per element. Bound instance: ${
            Array.from(r.keys())[0]
          }.`,
        );
        return;
      }
      r.set(t, n);
    },
    get(e, t) {
      return (wt.has(e) && wt.get(e).get(t)) || null;
    },
    remove(e, t) {
      if (!wt.has(e)) return;
      let n = wt.get(e);
      n.delete(t), n.size === 0 && wt.delete(e);
    },
  },
  Et = 1e6,
  Dt = 1e3,
  Ot = `transitionend`,
  kt = (e) => (
    e &&
      window.CSS &&
      window.CSS.escape &&
      (e = e.replace(/#([^\s"#']+)/g, (e, t) => `#${CSS.escape(t)}`)),
    e
  ),
  At = (e) =>
    e == null
      ? `${e}`
      : Object.prototype.toString
          .call(e)
          .match(/\s([a-z]+)/i)[1]
          .toLowerCase(),
  jt = (e) => {
    do e += Math.floor(Math.random() * Et);
    while (document.getElementById(e));
    return e;
  },
  Mt = (e) => {
    if (!e) return 0;
    let { transitionDuration: t, transitionDelay: n } =
      window.getComputedStyle(e);
    return !Number.parseFloat(t) && !Number.parseFloat(n)
      ? 0
      : ((t = t.split(`,`)[0]),
        (n = n.split(`,`)[0]),
        (Number.parseFloat(t) + Number.parseFloat(n)) * Dt);
  },
  Nt = (e) => {
    e.dispatchEvent(new Event(Ot));
  },
  Pt = (e) =>
    !e || typeof e != `object`
      ? !1
      : (e.jquery !== void 0 && (e = e[0]), e.nodeType !== void 0),
  Ft = (e) =>
    Pt(e)
      ? e.jquery
        ? e[0]
        : e
      : typeof e == `string` && e.length > 0
      ? document.querySelector(kt(e))
      : null,
  It = (e) => {
    if (!Pt(e) || e.getClientRects().length === 0) return !1;
    let t = getComputedStyle(e).getPropertyValue(`visibility`) === `visible`,
      n = e.closest(`details:not([open])`);
    if (!n) return t;
    if (n !== e) {
      let t = e.closest(`summary`);
      if ((t && t.parentNode !== n) || t === null) return !1;
    }
    return t;
  },
  Lt = (e) =>
    !e || e.nodeType !== Node.ELEMENT_NODE || e.classList.contains(`disabled`)
      ? !0
      : e.disabled === void 0
      ? e.hasAttribute(`disabled`) && e.getAttribute(`disabled`) !== `false`
      : e.disabled,
  Rt = (e) => {
    if (!document.documentElement.attachShadow) return null;
    if (typeof e.getRootNode == `function`) {
      let t = e.getRootNode();
      return t instanceof ShadowRoot ? t : null;
    }
    return e instanceof ShadowRoot ? e : e.parentNode ? Rt(e.parentNode) : null;
  },
  zt = () => {},
  Bt = (e) => {
    e.offsetHeight;
  },
  Vt = () =>
    window.jQuery && !document.body.hasAttribute(`data-bs-no-jquery`)
      ? window.jQuery
      : null,
  Ht = [],
  Ut = (e) => {
    document.readyState === `loading`
      ? (Ht.length ||
          document.addEventListener(`DOMContentLoaded`, () => {
            for (let e of Ht) e();
          }),
        Ht.push(e))
      : e();
  },
  R = () => document.documentElement.dir === `rtl`,
  z = (e) => {
    Ut(() => {
      let t = Vt();
      if (t) {
        let n = e.NAME,
          r = t.fn[n];
        (t.fn[n] = e.jQueryInterface),
          (t.fn[n].Constructor = e),
          (t.fn[n].noConflict = () => ((t.fn[n] = r), e.jQueryInterface));
      }
    });
  },
  B = (e, t = [], n = e) => (typeof e == `function` ? e.call(...t) : n),
  Wt = (e, t, n = !0) => {
    if (!n) {
      B(e);
      return;
    }
    let r = Mt(t) + 5,
      i = !1,
      a = ({ target: n }) => {
        n === t && ((i = !0), t.removeEventListener(Ot, a), B(e));
      };
    t.addEventListener(Ot, a),
      setTimeout(() => {
        i || Nt(t);
      }, r);
  },
  Gt = (e, t, n, r) => {
    let i = e.length,
      a = e.indexOf(t);
    return a === -1
      ? !n && r
        ? e[i - 1]
        : e[0]
      : ((a += n ? 1 : -1),
        r && (a = (a + i) % i),
        e[Math.max(0, Math.min(a, i - 1))]);
  },
  Kt = /[^.]*(?=\..*)\.|.*/,
  qt = /\..*/,
  Jt = /::\d+$/,
  Yt = {},
  Xt = 1,
  Zt = { mouseenter: `mouseover`, mouseleave: `mouseout` },
  Qt = new Set(
    `click.dblclick.mouseup.mousedown.contextmenu.mousewheel.DOMMouseScroll.mouseover.mouseout.mousemove.selectstart.selectend.keydown.keypress.keyup.orientationchange.touchstart.touchmove.touchend.touchcancel.pointerdown.pointermove.pointerup.pointerleave.pointercancel.gesturestart.gesturechange.gestureend.focus.blur.change.reset.select.submit.focusin.focusout.load.unload.beforeunload.resize.move.DOMContentLoaded.readystatechange.error.abort.scroll`.split(
      `.`,
    ),
  );
function $t(e, t) {
  return (t && `${t}::${Xt++}`) || e.uidEvent || Xt++;
}
function en(e) {
  let t = $t(e);
  return (e.uidEvent = t), (Yt[t] = Yt[t] || {}), Yt[t];
}
function tn(e, t) {
  return function n(r) {
    return (
      un(r, { delegateTarget: e }),
      n.oneOff && V.off(e, r.type, t),
      t.apply(e, [r])
    );
  };
}
function nn(e, t, n) {
  return function r(i) {
    let a = e.querySelectorAll(t);
    for (let { target: o } = i; o && o !== this; o = o.parentNode)
      for (let s of a)
        if (s === o)
          return (
            un(i, { delegateTarget: o }),
            r.oneOff && V.off(e, i.type, t, n),
            n.apply(o, [i])
          );
  };
}
function rn(e, t, n = null) {
  return Object.values(e).find(
    (e) => e.callable === t && e.delegationSelector === n,
  );
}
function an(e, t, n) {
  let r = typeof t == `string`,
    i = r ? n : t || n,
    a = ln(e);
  return Qt.has(a) || (a = e), [r, i, a];
}
function on(e, t, n, r, i) {
  if (typeof t != `string` || !e) return;
  let [a, o, s] = an(t, n, r);
  t in Zt &&
    (o = ((e) =>
      function (t) {
        if (
          !t.relatedTarget ||
          (t.relatedTarget !== t.delegateTarget &&
            !t.delegateTarget.contains(t.relatedTarget))
        )
          return e.call(this, t);
      })(o));
  let c = en(e),
    l = c[s] || (c[s] = {}),
    u = rn(l, o, a ? n : null);
  if (u) {
    u.oneOff = u.oneOff && i;
    return;
  }
  let d = $t(o, t.replace(Kt, ``)),
    f = a ? nn(e, n, o) : tn(e, o);
  (f.delegationSelector = a ? n : null),
    (f.callable = o),
    (f.oneOff = i),
    (f.uidEvent = d),
    (l[d] = f),
    e.addEventListener(s, f, a);
}
function sn(e, t, n, r, i) {
  let a = rn(t[n], r, i);
  a && (e.removeEventListener(n, a, !!i), delete t[n][a.uidEvent]);
}
function cn(e, t, n, r) {
  let i = t[n] || {};
  for (let [a, o] of Object.entries(i))
    a.includes(r) && sn(e, t, n, o.callable, o.delegationSelector);
}
function ln(e) {
  return (e = e.replace(qt, ``)), Zt[e] || e;
}
var V = {
  on(e, t, n, r) {
    on(e, t, n, r, !1);
  },
  one(e, t, n, r) {
    on(e, t, n, r, !0);
  },
  off(e, t, n, r) {
    if (typeof t != `string` || !e) return;
    let [i, a, o] = an(t, n, r),
      s = o !== t,
      c = en(e),
      l = c[o] || {},
      u = t.startsWith(`.`);
    if (a !== void 0) {
      if (!Object.keys(l).length) return;
      sn(e, c, o, a, i ? n : null);
      return;
    }
    if (u) for (let n of Object.keys(c)) cn(e, c, n, t.slice(1));
    for (let [n, r] of Object.entries(l)) {
      let i = n.replace(Jt, ``);
      (!s || t.includes(i)) && sn(e, c, o, r.callable, r.delegationSelector);
    }
  },
  trigger(e, t, n) {
    if (typeof t != `string` || !e) return null;
    let r = Vt(),
      i = t !== ln(t),
      a = null,
      o = !0,
      s = !0,
      c = !1;
    i &&
      r &&
      ((a = r.Event(t, n)),
      r(e).trigger(a),
      (o = !a.isPropagationStopped()),
      (s = !a.isImmediatePropagationStopped()),
      (c = a.isDefaultPrevented()));
    let l = un(new Event(t, { bubbles: o, cancelable: !0 }), n);
    return (
      c && l.preventDefault(),
      s && e.dispatchEvent(l),
      l.defaultPrevented && a && a.preventDefault(),
      l
    );
  },
};
function un(e, t = {}) {
  for (let [n, r] of Object.entries(t))
    try {
      e[n] = r;
    } catch {
      Object.defineProperty(e, n, {
        configurable: !0,
        get() {
          return r;
        },
      });
    }
  return e;
}
function dn(e) {
  if (e === `true`) return !0;
  if (e === `false`) return !1;
  if (e === Number(e).toString()) return Number(e);
  if (e === `` || e === `null`) return null;
  if (typeof e != `string`) return e;
  try {
    return JSON.parse(decodeURIComponent(e));
  } catch {
    return e;
  }
}
function fn(e) {
  return e.replace(/[A-Z]/g, (e) => `-${e.toLowerCase()}`);
}
var H = {
    setDataAttribute(e, t, n) {
      e.setAttribute(`data-bs-${fn(t)}`, n);
    },
    removeDataAttribute(e, t) {
      e.removeAttribute(`data-bs-${fn(t)}`);
    },
    getDataAttributes(e) {
      if (!e) return {};
      let t = {},
        n = Object.keys(e.dataset).filter(
          (e) => e.startsWith(`bs`) && !e.startsWith(`bsConfig`),
        );
      for (let r of n) {
        let n = r.replace(/^bs/, ``);
        (n = n.charAt(0).toLowerCase() + n.slice(1)), (t[n] = dn(e.dataset[r]));
      }
      return t;
    },
    getDataAttribute(e, t) {
      return dn(e.getAttribute(`data-bs-${fn(t)}`));
    },
  },
  pn = class {
    static get Default() {
      return {};
    }
    static get DefaultType() {
      return {};
    }
    static get NAME() {
      throw Error(
        `You have to implement the static method "NAME", for each component!`,
      );
    }
    _getConfig(e) {
      return (
        (e = this._mergeConfigObj(e)),
        (e = this._configAfterMerge(e)),
        this._typeCheckConfig(e),
        e
      );
    }
    _configAfterMerge(e) {
      return e;
    }
    _mergeConfigObj(e, t) {
      let n = Pt(t) ? H.getDataAttribute(t, `config`) : {};
      return {
        ...this.constructor.Default,
        ...(typeof n == `object` ? n : {}),
        ...(Pt(t) ? H.getDataAttributes(t) : {}),
        ...(typeof e == `object` ? e : {}),
      };
    }
    _typeCheckConfig(e, t = this.constructor.DefaultType) {
      for (let [n, r] of Object.entries(t)) {
        let t = e[n],
          i = Pt(t) ? `element` : At(t);
        if (!new RegExp(r).test(i))
          throw TypeError(
            `${this.constructor.NAME.toUpperCase()}: Option "${n}" provided type "${i}" but expected type "${r}".`,
          );
      }
    }
  },
  mn = `5.3.8`,
  U = class extends pn {
    constructor(e, t) {
      super(),
        (e = Ft(e)),
        e &&
          ((this._element = e),
          (this._config = this._getConfig(t)),
          Tt.set(this._element, this.constructor.DATA_KEY, this));
    }
    dispose() {
      Tt.remove(this._element, this.constructor.DATA_KEY),
        V.off(this._element, this.constructor.EVENT_KEY);
      for (let e of Object.getOwnPropertyNames(this)) this[e] = null;
    }
    _queueCallback(e, t, n = !0) {
      Wt(e, t, n);
    }
    _getConfig(e) {
      return (
        (e = this._mergeConfigObj(e, this._element)),
        (e = this._configAfterMerge(e)),
        this._typeCheckConfig(e),
        e
      );
    }
    static getInstance(e) {
      return Tt.get(Ft(e), this.DATA_KEY);
    }
    static getOrCreateInstance(e, t = {}) {
      return (
        this.getInstance(e) || new this(e, typeof t == `object` ? t : null)
      );
    }
    static get VERSION() {
      return mn;
    }
    static get DATA_KEY() {
      return `bs.${this.NAME}`;
    }
    static get EVENT_KEY() {
      return `.${this.DATA_KEY}`;
    }
    static eventName(e) {
      return `${e}${this.EVENT_KEY}`;
    }
  },
  hn = (e) => {
    let t = e.getAttribute(`data-bs-target`);
    if (!t || t === `#`) {
      let n = e.getAttribute(`href`);
      if (!n || (!n.includes(`#`) && !n.startsWith(`.`))) return null;
      n.includes(`#`) && !n.startsWith(`#`) && (n = `#${n.split(`#`)[1]}`),
        (t = n && n !== `#` ? n.trim() : null);
    }
    return t
      ? t
          .split(`,`)
          .map((e) => kt(e))
          .join(`,`)
      : null;
  },
  W = {
    find(e, t = document.documentElement) {
      return [].concat(...Element.prototype.querySelectorAll.call(t, e));
    },
    findOne(e, t = document.documentElement) {
      return Element.prototype.querySelector.call(t, e);
    },
    children(e, t) {
      return [].concat(...e.children).filter((e) => e.matches(t));
    },
    parents(e, t) {
      let n = [],
        r = e.parentNode.closest(t);
      for (; r; ) n.push(r), (r = r.parentNode.closest(t));
      return n;
    },
    prev(e, t) {
      let n = e.previousElementSibling;
      for (; n; ) {
        if (n.matches(t)) return [n];
        n = n.previousElementSibling;
      }
      return [];
    },
    next(e, t) {
      let n = e.nextElementSibling;
      for (; n; ) {
        if (n.matches(t)) return [n];
        n = n.nextElementSibling;
      }
      return [];
    },
    focusableChildren(e) {
      let t = [
        `a`,
        `button`,
        `input`,
        `textarea`,
        `select`,
        `details`,
        `[tabindex]`,
        `[contenteditable="true"]`,
      ]
        .map((e) => `${e}:not([tabindex^="-"])`)
        .join(`,`);
      return this.find(t, e).filter((e) => !Lt(e) && It(e));
    },
    getSelectorFromElement(e) {
      let t = hn(e);
      return t && W.findOne(t) ? t : null;
    },
    getElementFromSelector(e) {
      let t = hn(e);
      return t ? W.findOne(t) : null;
    },
    getMultipleElementsFromSelector(e) {
      let t = hn(e);
      return t ? W.find(t) : [];
    },
  },
  gn = (e, t = `hide`) => {
    let n = `click.dismiss${e.EVENT_KEY}`,
      r = e.NAME;
    V.on(document, n, `[data-bs-dismiss="${r}"]`, function (n) {
      if (
        ([`A`, `AREA`].includes(this.tagName) && n.preventDefault(), Lt(this))
      )
        return;
      let i = W.getElementFromSelector(this) || this.closest(`.${r}`);
      e.getOrCreateInstance(i)[t]();
    });
  },
  _n = `alert`,
  vn = `.bs.alert`,
  yn = `close${vn}`,
  bn = `closed${vn}`,
  xn = `fade`,
  Sn = `show`,
  Cn = class e extends U {
    static get NAME() {
      return _n;
    }
    close() {
      if (V.trigger(this._element, yn).defaultPrevented) return;
      this._element.classList.remove(Sn);
      let e = this._element.classList.contains(xn);
      this._queueCallback(() => this._destroyElement(), this._element, e);
    }
    _destroyElement() {
      this._element.remove(), V.trigger(this._element, bn), this.dispose();
    }
    static jQueryInterface(t) {
      return this.each(function () {
        let n = e.getOrCreateInstance(this);
        if (typeof t == `string`) {
          if (n[t] === void 0 || t.startsWith(`_`) || t === `constructor`)
            throw TypeError(`No method named "${t}"`);
          n[t](this);
        }
      });
    }
  };
gn(Cn, `close`), z(Cn);
var wn = `button`,
  Tn = `.bs.button`,
  En = `.data-api`,
  Dn = `active`,
  On = `[data-bs-toggle="button"]`,
  kn = `click${Tn}${En}`,
  An = class e extends U {
    static get NAME() {
      return wn;
    }
    toggle() {
      this._element.setAttribute(
        `aria-pressed`,
        this._element.classList.toggle(Dn),
      );
    }
    static jQueryInterface(t) {
      return this.each(function () {
        let n = e.getOrCreateInstance(this);
        t === `toggle` && n[t]();
      });
    }
  };
V.on(document, kn, On, (e) => {
  e.preventDefault();
  let t = e.target.closest(On);
  An.getOrCreateInstance(t).toggle();
}),
  z(An);
var jn = `swipe`,
  Mn = `.bs.swipe`,
  Nn = `touchstart${Mn}`,
  Pn = `touchmove${Mn}`,
  Fn = `touchend${Mn}`,
  In = `pointerdown${Mn}`,
  Ln = `pointerup${Mn}`,
  Rn = `touch`,
  zn = `pen`,
  Bn = `pointer-event`,
  Vn = 40,
  Hn = { endCallback: null, leftCallback: null, rightCallback: null },
  Un = {
    endCallback: `(function|null)`,
    leftCallback: `(function|null)`,
    rightCallback: `(function|null)`,
  },
  Wn = class e extends pn {
    constructor(t, n) {
      super(),
        (this._element = t),
        !(!t || !e.isSupported()) &&
          ((this._config = this._getConfig(n)),
          (this._deltaX = 0),
          (this._supportPointerEvents = !!window.PointerEvent),
          this._initEvents());
    }
    static get Default() {
      return Hn;
    }
    static get DefaultType() {
      return Un;
    }
    static get NAME() {
      return jn;
    }
    dispose() {
      V.off(this._element, Mn);
    }
    _start(e) {
      if (!this._supportPointerEvents) {
        this._deltaX = e.touches[0].clientX;
        return;
      }
      this._eventIsPointerPenTouch(e) && (this._deltaX = e.clientX);
    }
    _end(e) {
      this._eventIsPointerPenTouch(e) &&
        (this._deltaX = e.clientX - this._deltaX),
        this._handleSwipe(),
        B(this._config.endCallback);
    }
    _move(e) {
      this._deltaX =
        e.touches && e.touches.length > 1
          ? 0
          : e.touches[0].clientX - this._deltaX;
    }
    _handleSwipe() {
      let e = Math.abs(this._deltaX);
      if (e <= Vn) return;
      let t = e / this._deltaX;
      (this._deltaX = 0),
        t && B(t > 0 ? this._config.rightCallback : this._config.leftCallback);
    }
    _initEvents() {
      this._supportPointerEvents
        ? (V.on(this._element, In, (e) => this._start(e)),
          V.on(this._element, Ln, (e) => this._end(e)),
          this._element.classList.add(Bn))
        : (V.on(this._element, Nn, (e) => this._start(e)),
          V.on(this._element, Pn, (e) => this._move(e)),
          V.on(this._element, Fn, (e) => this._end(e)));
    }
    _eventIsPointerPenTouch(e) {
      return (
        this._supportPointerEvents &&
        (e.pointerType === zn || e.pointerType === Rn)
      );
    }
    static isSupported() {
      return (
        `ontouchstart` in document.documentElement ||
        navigator.maxTouchPoints > 0
      );
    }
  },
  Gn = `carousel`,
  Kn = `.bs.carousel`,
  qn = `.data-api`,
  Jn = `ArrowLeft`,
  Yn = `ArrowRight`,
  Xn = 500,
  Zn = `next`,
  Qn = `prev`,
  $n = `left`,
  er = `right`,
  tr = `slide${Kn}`,
  nr = `slid${Kn}`,
  rr = `keydown${Kn}`,
  ir = `mouseenter${Kn}`,
  ar = `mouseleave${Kn}`,
  or = `dragstart${Kn}`,
  sr = `load${Kn}${qn}`,
  cr = `click${Kn}${qn}`,
  lr = `carousel`,
  ur = `active`,
  dr = `slide`,
  fr = `carousel-item-end`,
  pr = `carousel-item-start`,
  mr = `carousel-item-next`,
  hr = `carousel-item-prev`,
  gr = `.active`,
  _r = `.carousel-item`,
  vr = gr + _r,
  yr = `.carousel-item img`,
  br = `.carousel-indicators`,
  xr = `[data-bs-slide], [data-bs-slide-to]`,
  Sr = `[data-bs-ride="carousel"]`,
  Cr = { [Jn]: er, [Yn]: $n },
  wr = {
    interval: 5e3,
    keyboard: !0,
    pause: `hover`,
    ride: !1,
    touch: !0,
    wrap: !0,
  },
  Tr = {
    interval: `(number|boolean)`,
    keyboard: `boolean`,
    pause: `(string|boolean)`,
    ride: `(boolean|string)`,
    touch: `boolean`,
    wrap: `boolean`,
  },
  Er = class e extends U {
    constructor(e, t) {
      super(e, t),
        (this._interval = null),
        (this._activeElement = null),
        (this._isSliding = !1),
        (this.touchTimeout = null),
        (this._swipeHelper = null),
        (this._indicatorsElement = W.findOne(br, this._element)),
        this._addEventListeners(),
        this._config.ride === lr && this.cycle();
    }
    static get Default() {
      return wr;
    }
    static get DefaultType() {
      return Tr;
    }
    static get NAME() {
      return Gn;
    }
    next() {
      this._slide(Zn);
    }
    nextWhenVisible() {
      !document.hidden && It(this._element) && this.next();
    }
    prev() {
      this._slide(Qn);
    }
    pause() {
      this._isSliding && Nt(this._element), this._clearInterval();
    }
    cycle() {
      this._clearInterval(),
        this._updateInterval(),
        (this._interval = setInterval(
          () => this.nextWhenVisible(),
          this._config.interval,
        ));
    }
    _maybeEnableCycle() {
      if (this._config.ride) {
        if (this._isSliding) {
          V.one(this._element, nr, () => this.cycle());
          return;
        }
        this.cycle();
      }
    }
    to(e) {
      let t = this._getItems();
      if (e > t.length - 1 || e < 0) return;
      if (this._isSliding) {
        V.one(this._element, nr, () => this.to(e));
        return;
      }
      let n = this._getItemIndex(this._getActive());
      if (n === e) return;
      let r = e > n ? Zn : Qn;
      this._slide(r, t[e]);
    }
    dispose() {
      this._swipeHelper && this._swipeHelper.dispose(), super.dispose();
    }
    _configAfterMerge(e) {
      return (e.defaultInterval = e.interval), e;
    }
    _addEventListeners() {
      this._config.keyboard && V.on(this._element, rr, (e) => this._keydown(e)),
        this._config.pause === `hover` &&
          (V.on(this._element, ir, () => this.pause()),
          V.on(this._element, ar, () => this._maybeEnableCycle())),
        this._config.touch &&
          Wn.isSupported() &&
          this._addTouchEventListeners();
    }
    _addTouchEventListeners() {
      for (let e of W.find(yr, this._element))
        V.on(e, or, (e) => e.preventDefault());
      this._swipeHelper = new Wn(this._element, {
        leftCallback: () => this._slide(this._directionToOrder($n)),
        rightCallback: () => this._slide(this._directionToOrder(er)),
        endCallback: () => {
          this._config.pause === `hover` &&
            (this.pause(),
            this.touchTimeout && clearTimeout(this.touchTimeout),
            (this.touchTimeout = setTimeout(
              () => this._maybeEnableCycle(),
              Xn + this._config.interval,
            )));
        },
      });
    }
    _keydown(e) {
      if (/input|textarea/i.test(e.target.tagName)) return;
      let t = Cr[e.key];
      t && (e.preventDefault(), this._slide(this._directionToOrder(t)));
    }
    _getItemIndex(e) {
      return this._getItems().indexOf(e);
    }
    _setActiveIndicatorElement(e) {
      if (!this._indicatorsElement) return;
      let t = W.findOne(gr, this._indicatorsElement);
      t.classList.remove(ur), t.removeAttribute(`aria-current`);
      let n = W.findOne(`[data-bs-slide-to="${e}"]`, this._indicatorsElement);
      n && (n.classList.add(ur), n.setAttribute(`aria-current`, `true`));
    }
    _updateInterval() {
      let e = this._activeElement || this._getActive();
      if (!e) return;
      let t = Number.parseInt(e.getAttribute(`data-bs-interval`), 10);
      this._config.interval = t || this._config.defaultInterval;
    }
    _slide(e, t = null) {
      if (this._isSliding) return;
      let n = this._getActive(),
        r = e === Zn,
        i = t || Gt(this._getItems(), n, r, this._config.wrap);
      if (i === n) return;
      let a = this._getItemIndex(i),
        o = (t) =>
          V.trigger(this._element, t, {
            relatedTarget: i,
            direction: this._orderToDirection(e),
            from: this._getItemIndex(n),
            to: a,
          });
      if (o(tr).defaultPrevented || !n || !i) return;
      let s = !!this._interval;
      this.pause(),
        (this._isSliding = !0),
        this._setActiveIndicatorElement(a),
        (this._activeElement = i);
      let c = r ? pr : fr,
        l = r ? mr : hr;
      i.classList.add(l),
        Bt(i),
        n.classList.add(c),
        i.classList.add(c),
        this._queueCallback(
          () => {
            i.classList.remove(c, l),
              i.classList.add(ur),
              n.classList.remove(ur, l, c),
              (this._isSliding = !1),
              o(nr);
          },
          n,
          this._isAnimated(),
        ),
        s && this.cycle();
    }
    _isAnimated() {
      return this._element.classList.contains(dr);
    }
    _getActive() {
      return W.findOne(vr, this._element);
    }
    _getItems() {
      return W.find(_r, this._element);
    }
    _clearInterval() {
      this._interval &&= (clearInterval(this._interval), null);
    }
    _directionToOrder(e) {
      return R() ? (e === $n ? Qn : Zn) : e === $n ? Zn : Qn;
    }
    _orderToDirection(e) {
      return R() ? (e === Qn ? $n : er) : e === Qn ? er : $n;
    }
    static jQueryInterface(t) {
      return this.each(function () {
        let n = e.getOrCreateInstance(this, t);
        if (typeof t == `number`) {
          n.to(t);
          return;
        }
        if (typeof t == `string`) {
          if (n[t] === void 0 || t.startsWith(`_`) || t === `constructor`)
            throw TypeError(`No method named "${t}"`);
          n[t]();
        }
      });
    }
  };
V.on(document, cr, xr, function (e) {
  let t = W.getElementFromSelector(this);
  if (!t || !t.classList.contains(lr)) return;
  e.preventDefault();
  let n = Er.getOrCreateInstance(t),
    r = this.getAttribute(`data-bs-slide-to`);
  if (r) {
    n.to(r), n._maybeEnableCycle();
    return;
  }
  if (H.getDataAttribute(this, `slide`) === `next`) {
    n.next(), n._maybeEnableCycle();
    return;
  }
  n.prev(), n._maybeEnableCycle();
}),
  V.on(window, sr, () => {
    let e = W.find(Sr);
    for (let t of e) Er.getOrCreateInstance(t);
  }),
  z(Er);
var Dr = `collapse`,
  Or = `.bs.collapse`,
  kr = `.data-api`,
  Ar = `show${Or}`,
  jr = `shown${Or}`,
  Mr = `hide${Or}`,
  Nr = `hidden${Or}`,
  Pr = `click${Or}${kr}`,
  Fr = `show`,
  Ir = `collapse`,
  Lr = `collapsing`,
  Rr = `collapsed`,
  zr = `:scope .${Ir} .${Ir}`,
  Br = `collapse-horizontal`,
  Vr = `width`,
  Hr = `height`,
  Ur = `.collapse.show, .collapse.collapsing`,
  Wr = `[data-bs-toggle="collapse"]`,
  Gr = { parent: null, toggle: !0 },
  Kr = { parent: `(null|element)`, toggle: `boolean` },
  qr = class e extends U {
    constructor(e, t) {
      super(e, t), (this._isTransitioning = !1), (this._triggerArray = []);
      let n = W.find(Wr);
      for (let e of n) {
        let t = W.getSelectorFromElement(e),
          n = W.find(t).filter((e) => e === this._element);
        t !== null && n.length && this._triggerArray.push(e);
      }
      this._initializeChildren(),
        this._config.parent ||
          this._addAriaAndCollapsedClass(this._triggerArray, this._isShown()),
        this._config.toggle && this.toggle();
    }
    static get Default() {
      return Gr;
    }
    static get DefaultType() {
      return Kr;
    }
    static get NAME() {
      return Dr;
    }
    toggle() {
      this._isShown() ? this.hide() : this.show();
    }
    show() {
      if (this._isTransitioning || this._isShown()) return;
      let t = [];
      if (
        (this._config.parent &&
          (t = this._getFirstLevelChildren(Ur)
            .filter((e) => e !== this._element)
            .map((t) => e.getOrCreateInstance(t, { toggle: !1 }))),
        (t.length && t[0]._isTransitioning) ||
          V.trigger(this._element, Ar).defaultPrevented)
      )
        return;
      for (let e of t) e.hide();
      let n = this._getDimension();
      this._element.classList.remove(Ir),
        this._element.classList.add(Lr),
        (this._element.style[n] = 0),
        this._addAriaAndCollapsedClass(this._triggerArray, !0),
        (this._isTransitioning = !0);
      let r = () => {
          (this._isTransitioning = !1),
            this._element.classList.remove(Lr),
            this._element.classList.add(Ir, Fr),
            (this._element.style[n] = ``),
            V.trigger(this._element, jr);
        },
        i = `scroll${n[0].toUpperCase() + n.slice(1)}`;
      this._queueCallback(r, this._element, !0),
        (this._element.style[n] = `${this._element[i]}px`);
    }
    hide() {
      if (
        this._isTransitioning ||
        !this._isShown() ||
        V.trigger(this._element, Mr).defaultPrevented
      )
        return;
      let e = this._getDimension();
      (this._element.style[e] = `${
        this._element.getBoundingClientRect()[e]
      }px`),
        Bt(this._element),
        this._element.classList.add(Lr),
        this._element.classList.remove(Ir, Fr);
      for (let e of this._triggerArray) {
        let t = W.getElementFromSelector(e);
        t && !this._isShown(t) && this._addAriaAndCollapsedClass([e], !1);
      }
      this._isTransitioning = !0;
      let t = () => {
        (this._isTransitioning = !1),
          this._element.classList.remove(Lr),
          this._element.classList.add(Ir),
          V.trigger(this._element, Nr);
      };
      (this._element.style[e] = ``), this._queueCallback(t, this._element, !0);
    }
    _isShown(e = this._element) {
      return e.classList.contains(Fr);
    }
    _configAfterMerge(e) {
      return (e.toggle = !!e.toggle), (e.parent = Ft(e.parent)), e;
    }
    _getDimension() {
      return this._element.classList.contains(Br) ? Vr : Hr;
    }
    _initializeChildren() {
      if (!this._config.parent) return;
      let e = this._getFirstLevelChildren(Wr);
      for (let t of e) {
        let e = W.getElementFromSelector(t);
        e && this._addAriaAndCollapsedClass([t], this._isShown(e));
      }
    }
    _getFirstLevelChildren(e) {
      let t = W.find(zr, this._config.parent);
      return W.find(e, this._config.parent).filter((e) => !t.includes(e));
    }
    _addAriaAndCollapsedClass(e, t) {
      if (e.length)
        for (let n of e)
          n.classList.toggle(Rr, !t), n.setAttribute(`aria-expanded`, t);
    }
    static jQueryInterface(t) {
      let n = {};
      return (
        typeof t == `string` && /show|hide/.test(t) && (n.toggle = !1),
        this.each(function () {
          let r = e.getOrCreateInstance(this, n);
          if (typeof t == `string`) {
            if (r[t] === void 0) throw TypeError(`No method named "${t}"`);
            r[t]();
          }
        })
      );
    }
  };
V.on(document, Pr, Wr, function (e) {
  (e.target.tagName === `A` ||
    (e.delegateTarget && e.delegateTarget.tagName === `A`)) &&
    e.preventDefault();
  for (let e of W.getMultipleElementsFromSelector(this))
    qr.getOrCreateInstance(e, { toggle: !1 }).toggle();
}),
  z(qr);
var Jr = `dropdown`,
  Yr = `.bs.dropdown`,
  Xr = `.data-api`,
  Zr = `Escape`,
  Qr = `Tab`,
  $r = `ArrowUp`,
  ei = `ArrowDown`,
  ti = 2,
  ni = `hide${Yr}`,
  ri = `hidden${Yr}`,
  ii = `show${Yr}`,
  ai = `shown${Yr}`,
  oi = `click${Yr}${Xr}`,
  si = `keydown${Yr}${Xr}`,
  ci = `keyup${Yr}${Xr}`,
  li = `show`,
  ui = `dropup`,
  di = `dropend`,
  fi = `dropstart`,
  pi = `dropup-center`,
  mi = `dropdown-center`,
  hi = `[data-bs-toggle="dropdown"]:not(.disabled):not(:disabled)`,
  gi = `${hi}.${li}`,
  _i = `.dropdown-menu`,
  vi = `.navbar`,
  yi = `.navbar-nav`,
  bi = `.dropdown-menu .dropdown-item:not(.disabled):not(:disabled)`,
  xi = R() ? `top-end` : `top-start`,
  Si = R() ? `top-start` : `top-end`,
  Ci = R() ? `bottom-end` : `bottom-start`,
  wi = R() ? `bottom-start` : `bottom-end`,
  Ti = R() ? `left-start` : `right-start`,
  Ei = R() ? `right-start` : `left-start`,
  Di = `top`,
  Oi = `bottom`,
  ki = {
    autoClose: !0,
    boundary: `clippingParents`,
    display: `dynamic`,
    offset: [0, 2],
    popperConfig: null,
    reference: `toggle`,
  },
  Ai = {
    autoClose: `(boolean|string)`,
    boundary: `(string|element)`,
    display: `string`,
    offset: `(array|string|function)`,
    popperConfig: `(null|object|function)`,
    reference: `(string|element|object)`,
  },
  ji = class e extends U {
    constructor(e, t) {
      super(e, t),
        (this._popper = null),
        (this._parent = this._element.parentNode),
        (this._menu =
          W.next(this._element, _i)[0] ||
          W.prev(this._element, _i)[0] ||
          W.findOne(_i, this._parent)),
        (this._inNavbar = this._detectNavbar());
    }
    static get Default() {
      return ki;
    }
    static get DefaultType() {
      return Ai;
    }
    static get NAME() {
      return Jr;
    }
    toggle() {
      return this._isShown() ? this.hide() : this.show();
    }
    show() {
      if (Lt(this._element) || this._isShown()) return;
      let e = { relatedTarget: this._element };
      if (!V.trigger(this._element, ii, e).defaultPrevented) {
        if (
          (this._createPopper(),
          `ontouchstart` in document.documentElement &&
            !this._parent.closest(yi))
        )
          for (let e of [].concat(...document.body.children))
            V.on(e, `mouseover`, zt);
        this._element.focus(),
          this._element.setAttribute(`aria-expanded`, !0),
          this._menu.classList.add(li),
          this._element.classList.add(li),
          V.trigger(this._element, ai, e);
      }
    }
    hide() {
      if (Lt(this._element) || !this._isShown()) return;
      let e = { relatedTarget: this._element };
      this._completeHide(e);
    }
    dispose() {
      this._popper && this._popper.destroy(), super.dispose();
    }
    update() {
      (this._inNavbar = this._detectNavbar()),
        this._popper && this._popper.update();
    }
    _completeHide(e) {
      if (!V.trigger(this._element, ni, e).defaultPrevented) {
        if (`ontouchstart` in document.documentElement)
          for (let e of [].concat(...document.body.children))
            V.off(e, `mouseover`, zt);
        this._popper && this._popper.destroy(),
          this._menu.classList.remove(li),
          this._element.classList.remove(li),
          this._element.setAttribute(`aria-expanded`, `false`),
          H.removeDataAttribute(this._menu, `popper`),
          V.trigger(this._element, ri, e);
      }
    }
    _getConfig(e) {
      if (
        ((e = super._getConfig(e)),
        typeof e.reference == `object` &&
          !Pt(e.reference) &&
          typeof e.reference.getBoundingClientRect != `function`)
      )
        throw TypeError(
          `${Jr.toUpperCase()}: Option "reference" provided type "object" without a required "getBoundingClientRect" method.`,
        );
      return e;
    }
    _createPopper() {
      if (Ct === void 0)
        throw TypeError(
          `Bootstrap's dropdowns require Popper (https://popper.js.org/docs/v2/)`,
        );
      let e = this._element;
      this._config.reference === `parent`
        ? (e = this._parent)
        : Pt(this._config.reference)
        ? (e = Ft(this._config.reference))
        : typeof this._config.reference == `object` &&
          (e = this._config.reference);
      let t = this._getPopperConfig();
      this._popper = St(e, this._menu, t);
    }
    _isShown() {
      return this._menu.classList.contains(li);
    }
    _getPlacement() {
      let e = this._parent;
      if (e.classList.contains(di)) return Ti;
      if (e.classList.contains(fi)) return Ei;
      if (e.classList.contains(pi)) return Di;
      if (e.classList.contains(mi)) return Oi;
      let t =
        getComputedStyle(this._menu)
          .getPropertyValue(`--bs-position`)
          .trim() === `end`;
      return e.classList.contains(ui) ? (t ? Si : xi) : t ? wi : Ci;
    }
    _detectNavbar() {
      return this._element.closest(vi) !== null;
    }
    _getOffset() {
      let { offset: e } = this._config;
      return typeof e == `string`
        ? e.split(`,`).map((e) => Number.parseInt(e, 10))
        : typeof e == `function`
        ? (t) => e(t, this._element)
        : e;
    }
    _getPopperConfig() {
      let e = {
        placement: this._getPlacement(),
        modifiers: [
          {
            name: `preventOverflow`,
            options: { boundary: this._config.boundary },
          },
          { name: `offset`, options: { offset: this._getOffset() } },
        ],
      };
      return (
        (this._inNavbar || this._config.display === `static`) &&
          (H.setDataAttribute(this._menu, `popper`, `static`),
          (e.modifiers = [{ name: `applyStyles`, enabled: !1 }])),
        { ...e, ...B(this._config.popperConfig, [void 0, e]) }
      );
    }
    _selectMenuItem({ key: e, target: t }) {
      let n = W.find(bi, this._menu).filter((e) => It(e));
      n.length && Gt(n, t, e === ei, !n.includes(t)).focus();
    }
    static jQueryInterface(t) {
      return this.each(function () {
        let n = e.getOrCreateInstance(this, t);
        if (typeof t == `string`) {
          if (n[t] === void 0) throw TypeError(`No method named "${t}"`);
          n[t]();
        }
      });
    }
    static clearMenus(t) {
      if (t.button === ti || (t.type === `keyup` && t.key !== Qr)) return;
      let n = W.find(gi);
      for (let r of n) {
        let n = e.getInstance(r);
        if (!n || n._config.autoClose === !1) continue;
        let i = t.composedPath(),
          a = i.includes(n._menu);
        if (
          i.includes(n._element) ||
          (n._config.autoClose === `inside` && !a) ||
          (n._config.autoClose === `outside` && a) ||
          (n._menu.contains(t.target) &&
            ((t.type === `keyup` && t.key === Qr) ||
              /input|select|option|textarea|form/i.test(t.target.tagName)))
        )
          continue;
        let o = { relatedTarget: n._element };
        t.type === `click` && (o.clickEvent = t), n._completeHide(o);
      }
    }
    static dataApiKeydownHandler(t) {
      let n = /input|textarea/i.test(t.target.tagName),
        r = t.key === Zr,
        i = [$r, ei].includes(t.key);
      if ((!i && !r) || (n && !r)) return;
      t.preventDefault();
      let a = this.matches(hi)
          ? this
          : W.prev(this, hi)[0] ||
            W.next(this, hi)[0] ||
            W.findOne(hi, t.delegateTarget.parentNode),
        o = e.getOrCreateInstance(a);
      if (i) {
        t.stopPropagation(), o.show(), o._selectMenuItem(t);
        return;
      }
      o._isShown() && (t.stopPropagation(), o.hide(), a.focus());
    }
  };
V.on(document, si, hi, ji.dataApiKeydownHandler),
  V.on(document, si, _i, ji.dataApiKeydownHandler),
  V.on(document, oi, ji.clearMenus),
  V.on(document, ci, ji.clearMenus),
  V.on(document, oi, hi, function (e) {
    e.preventDefault(), ji.getOrCreateInstance(this).toggle();
  }),
  z(ji);
var Mi = `backdrop`,
  Ni = `fade`,
  Pi = `show`,
  Fi = `mousedown.bs.${Mi}`,
  Ii = {
    className: `modal-backdrop`,
    clickCallback: null,
    isAnimated: !1,
    isVisible: !0,
    rootElement: `body`,
  },
  Li = {
    className: `string`,
    clickCallback: `(function|null)`,
    isAnimated: `boolean`,
    isVisible: `boolean`,
    rootElement: `(element|string)`,
  },
  Ri = class extends pn {
    constructor(e) {
      super(),
        (this._config = this._getConfig(e)),
        (this._isAppended = !1),
        (this._element = null);
    }
    static get Default() {
      return Ii;
    }
    static get DefaultType() {
      return Li;
    }
    static get NAME() {
      return Mi;
    }
    show(e) {
      if (!this._config.isVisible) {
        B(e);
        return;
      }
      this._append();
      let t = this._getElement();
      this._config.isAnimated && Bt(t),
        t.classList.add(Pi),
        this._emulateAnimation(() => {
          B(e);
        });
    }
    hide(e) {
      if (!this._config.isVisible) {
        B(e);
        return;
      }
      this._getElement().classList.remove(Pi),
        this._emulateAnimation(() => {
          this.dispose(), B(e);
        });
    }
    dispose() {
      this._isAppended &&=
        (V.off(this._element, Fi), this._element.remove(), !1);
    }
    _getElement() {
      if (!this._element) {
        let e = document.createElement(`div`);
        (e.className = this._config.className),
          this._config.isAnimated && e.classList.add(Ni),
          (this._element = e);
      }
      return this._element;
    }
    _configAfterMerge(e) {
      return (e.rootElement = Ft(e.rootElement)), e;
    }
    _append() {
      if (this._isAppended) return;
      let e = this._getElement();
      this._config.rootElement.append(e),
        V.on(e, Fi, () => {
          B(this._config.clickCallback);
        }),
        (this._isAppended = !0);
    }
    _emulateAnimation(e) {
      Wt(e, this._getElement(), this._config.isAnimated);
    }
  },
  zi = `focustrap`,
  Bi = `.bs.focustrap`,
  Vi = `focusin${Bi}`,
  Hi = `keydown.tab${Bi}`,
  Ui = `Tab`,
  Wi = `forward`,
  Gi = `backward`,
  Ki = { autofocus: !0, trapElement: null },
  qi = { autofocus: `boolean`, trapElement: `element` },
  Ji = class extends pn {
    constructor(e) {
      super(),
        (this._config = this._getConfig(e)),
        (this._isActive = !1),
        (this._lastTabNavDirection = null);
    }
    static get Default() {
      return Ki;
    }
    static get DefaultType() {
      return qi;
    }
    static get NAME() {
      return zi;
    }
    activate() {
      this._isActive ||=
        (this._config.autofocus && this._config.trapElement.focus(),
        V.off(document, Bi),
        V.on(document, Vi, (e) => this._handleFocusin(e)),
        V.on(document, Hi, (e) => this._handleKeydown(e)),
        !0);
    }
    deactivate() {
      this._isActive && ((this._isActive = !1), V.off(document, Bi));
    }
    _handleFocusin(e) {
      let { trapElement: t } = this._config;
      if (e.target === document || e.target === t || t.contains(e.target))
        return;
      let n = W.focusableChildren(t);
      n.length === 0
        ? t.focus()
        : this._lastTabNavDirection === Gi
        ? n[n.length - 1].focus()
        : n[0].focus();
    }
    _handleKeydown(e) {
      e.key === Ui && (this._lastTabNavDirection = e.shiftKey ? Gi : Wi);
    }
  },
  Yi = `.fixed-top, .fixed-bottom, .is-fixed, .sticky-top`,
  Xi = `.sticky-top`,
  Zi = `padding-right`,
  Qi = `margin-right`,
  $i = class {
    constructor() {
      this._element = document.body;
    }
    getWidth() {
      let e = document.documentElement.clientWidth;
      return Math.abs(window.innerWidth - e);
    }
    hide() {
      let e = this.getWidth();
      this._disableOverFlow(),
        this._setElementAttributes(this._element, Zi, (t) => t + e),
        this._setElementAttributes(Yi, Zi, (t) => t + e),
        this._setElementAttributes(Xi, Qi, (t) => t - e);
    }
    reset() {
      this._resetElementAttributes(this._element, `overflow`),
        this._resetElementAttributes(this._element, Zi),
        this._resetElementAttributes(Yi, Zi),
        this._resetElementAttributes(Xi, Qi);
    }
    isOverflowing() {
      return this.getWidth() > 0;
    }
    _disableOverFlow() {
      this._saveInitialAttribute(this._element, `overflow`),
        (this._element.style.overflow = `hidden`);
    }
    _setElementAttributes(e, t, n) {
      let r = this.getWidth();
      this._applyManipulationCallback(e, (e) => {
        if (e !== this._element && window.innerWidth > e.clientWidth + r)
          return;
        this._saveInitialAttribute(e, t);
        let i = window.getComputedStyle(e).getPropertyValue(t);
        e.style.setProperty(t, `${n(Number.parseFloat(i))}px`);
      });
    }
    _saveInitialAttribute(e, t) {
      let n = e.style.getPropertyValue(t);
      n && H.setDataAttribute(e, t, n);
    }
    _resetElementAttributes(e, t) {
      this._applyManipulationCallback(e, (e) => {
        let n = H.getDataAttribute(e, t);
        if (n === null) {
          e.style.removeProperty(t);
          return;
        }
        H.removeDataAttribute(e, t), e.style.setProperty(t, n);
      });
    }
    _applyManipulationCallback(e, t) {
      if (Pt(e)) {
        t(e);
        return;
      }
      for (let n of W.find(e, this._element)) t(n);
    }
  },
  ea = `modal`,
  G = `.bs.modal`,
  ta = `.data-api`,
  na = `Escape`,
  ra = `hide${G}`,
  ia = `hidePrevented${G}`,
  aa = `hidden${G}`,
  oa = `show${G}`,
  sa = `shown${G}`,
  ca = `resize${G}`,
  la = `click.dismiss${G}`,
  ua = `mousedown.dismiss${G}`,
  da = `keydown.dismiss${G}`,
  fa = `click${G}${ta}`,
  pa = `modal-open`,
  ma = `fade`,
  ha = `show`,
  ga = `modal-static`,
  _a = `.modal.show`,
  va = `.modal-dialog`,
  ya = `.modal-body`,
  ba = `[data-bs-toggle="modal"]`,
  xa = { backdrop: !0, focus: !0, keyboard: !0 },
  Sa = { backdrop: `(boolean|string)`, focus: `boolean`, keyboard: `boolean` },
  Ca = class e extends U {
    constructor(e, t) {
      super(e, t),
        (this._dialog = W.findOne(va, this._element)),
        (this._backdrop = this._initializeBackDrop()),
        (this._focustrap = this._initializeFocusTrap()),
        (this._isShown = !1),
        (this._isTransitioning = !1),
        (this._scrollBar = new $i()),
        this._addEventListeners();
    }
    static get Default() {
      return xa;
    }
    static get DefaultType() {
      return Sa;
    }
    static get NAME() {
      return ea;
    }
    toggle(e) {
      return this._isShown ? this.hide() : this.show(e);
    }
    show(e) {
      this._isShown ||
        this._isTransitioning ||
        V.trigger(this._element, oa, { relatedTarget: e }).defaultPrevented ||
        ((this._isShown = !0),
        (this._isTransitioning = !0),
        this._scrollBar.hide(),
        document.body.classList.add(pa),
        this._adjustDialog(),
        this._backdrop.show(() => this._showElement(e)));
    }
    hide() {
      !this._isShown ||
        this._isTransitioning ||
        V.trigger(this._element, ra).defaultPrevented ||
        ((this._isShown = !1),
        (this._isTransitioning = !0),
        this._focustrap.deactivate(),
        this._element.classList.remove(ha),
        this._queueCallback(
          () => this._hideModal(),
          this._element,
          this._isAnimated(),
        ));
    }
    dispose() {
      V.off(window, G),
        V.off(this._dialog, G),
        this._backdrop.dispose(),
        this._focustrap.deactivate(),
        super.dispose();
    }
    handleUpdate() {
      this._adjustDialog();
    }
    _initializeBackDrop() {
      return new Ri({
        isVisible: !!this._config.backdrop,
        isAnimated: this._isAnimated(),
      });
    }
    _initializeFocusTrap() {
      return new Ji({ trapElement: this._element });
    }
    _showElement(e) {
      document.body.contains(this._element) ||
        document.body.append(this._element),
        (this._element.style.display = `block`),
        this._element.removeAttribute(`aria-hidden`),
        this._element.setAttribute(`aria-modal`, !0),
        this._element.setAttribute(`role`, `dialog`),
        (this._element.scrollTop = 0);
      let t = W.findOne(ya, this._dialog);
      t && (t.scrollTop = 0),
        Bt(this._element),
        this._element.classList.add(ha),
        this._queueCallback(
          () => {
            this._config.focus && this._focustrap.activate(),
              (this._isTransitioning = !1),
              V.trigger(this._element, sa, { relatedTarget: e });
          },
          this._dialog,
          this._isAnimated(),
        );
    }
    _addEventListeners() {
      V.on(this._element, da, (e) => {
        if (e.key === na) {
          if (this._config.keyboard) {
            this.hide();
            return;
          }
          this._triggerBackdropTransition();
        }
      }),
        V.on(window, ca, () => {
          this._isShown && !this._isTransitioning && this._adjustDialog();
        }),
        V.on(this._element, ua, (e) => {
          V.one(this._element, la, (t) => {
            if (!(this._element !== e.target || this._element !== t.target)) {
              if (this._config.backdrop === `static`) {
                this._triggerBackdropTransition();
                return;
              }
              this._config.backdrop && this.hide();
            }
          });
        });
    }
    _hideModal() {
      (this._element.style.display = `none`),
        this._element.setAttribute(`aria-hidden`, !0),
        this._element.removeAttribute(`aria-modal`),
        this._element.removeAttribute(`role`),
        (this._isTransitioning = !1),
        this._backdrop.hide(() => {
          document.body.classList.remove(pa),
            this._resetAdjustments(),
            this._scrollBar.reset(),
            V.trigger(this._element, aa);
        });
    }
    _isAnimated() {
      return this._element.classList.contains(ma);
    }
    _triggerBackdropTransition() {
      if (V.trigger(this._element, ia).defaultPrevented) return;
      let e =
          this._element.scrollHeight > document.documentElement.clientHeight,
        t = this._element.style.overflowY;
      t === `hidden` ||
        this._element.classList.contains(ga) ||
        (e || (this._element.style.overflowY = `hidden`),
        this._element.classList.add(ga),
        this._queueCallback(() => {
          this._element.classList.remove(ga),
            this._queueCallback(() => {
              this._element.style.overflowY = t;
            }, this._dialog);
        }, this._dialog),
        this._element.focus());
    }
    _adjustDialog() {
      let e =
          this._element.scrollHeight > document.documentElement.clientHeight,
        t = this._scrollBar.getWidth(),
        n = t > 0;
      if (n && !e) {
        let e = R() ? `paddingLeft` : `paddingRight`;
        this._element.style[e] = `${t}px`;
      }
      if (!n && e) {
        let e = R() ? `paddingRight` : `paddingLeft`;
        this._element.style[e] = `${t}px`;
      }
    }
    _resetAdjustments() {
      (this._element.style.paddingLeft = ``),
        (this._element.style.paddingRight = ``);
    }
    static jQueryInterface(t, n) {
      return this.each(function () {
        let r = e.getOrCreateInstance(this, t);
        if (typeof t == `string`) {
          if (r[t] === void 0) throw TypeError(`No method named "${t}"`);
          r[t](n);
        }
      });
    }
  };
V.on(document, fa, ba, function (e) {
  let t = W.getElementFromSelector(this);
  [`A`, `AREA`].includes(this.tagName) && e.preventDefault(),
    V.one(t, oa, (e) => {
      e.defaultPrevented ||
        V.one(t, aa, () => {
          It(this) && this.focus();
        });
    });
  let n = W.findOne(_a);
  n && Ca.getInstance(n).hide(), Ca.getOrCreateInstance(t).toggle(this);
}),
  gn(Ca),
  z(Ca);
var wa = `offcanvas`,
  K = `.bs.offcanvas`,
  Ta = `.data-api`,
  Ea = `load${K}${Ta}`,
  Da = `Escape`,
  Oa = `show`,
  ka = `showing`,
  Aa = `hiding`,
  ja = `offcanvas-backdrop`,
  Ma = `.offcanvas.show`,
  Na = `show${K}`,
  Pa = `shown${K}`,
  Fa = `hide${K}`,
  Ia = `hidePrevented${K}`,
  La = `hidden${K}`,
  Ra = `resize${K}`,
  za = `click${K}${Ta}`,
  Ba = `keydown.dismiss${K}`,
  Va = `[data-bs-toggle="offcanvas"]`,
  Ha = { backdrop: !0, keyboard: !0, scroll: !1 },
  Ua = { backdrop: `(boolean|string)`, keyboard: `boolean`, scroll: `boolean` },
  Wa = class e extends U {
    constructor(e, t) {
      super(e, t),
        (this._isShown = !1),
        (this._backdrop = this._initializeBackDrop()),
        (this._focustrap = this._initializeFocusTrap()),
        this._addEventListeners();
    }
    static get Default() {
      return Ha;
    }
    static get DefaultType() {
      return Ua;
    }
    static get NAME() {
      return wa;
    }
    toggle(e) {
      return this._isShown ? this.hide() : this.show(e);
    }
    show(e) {
      this._isShown ||
        V.trigger(this._element, Na, { relatedTarget: e }).defaultPrevented ||
        ((this._isShown = !0),
        this._backdrop.show(),
        this._config.scroll || new $i().hide(),
        this._element.setAttribute(`aria-modal`, !0),
        this._element.setAttribute(`role`, `dialog`),
        this._element.classList.add(ka),
        this._queueCallback(
          () => {
            (!this._config.scroll || this._config.backdrop) &&
              this._focustrap.activate(),
              this._element.classList.add(Oa),
              this._element.classList.remove(ka),
              V.trigger(this._element, Pa, { relatedTarget: e });
          },
          this._element,
          !0,
        ));
    }
    hide() {
      !this._isShown ||
        V.trigger(this._element, Fa).defaultPrevented ||
        (this._focustrap.deactivate(),
        this._element.blur(),
        (this._isShown = !1),
        this._element.classList.add(Aa),
        this._backdrop.hide(),
        this._queueCallback(
          () => {
            this._element.classList.remove(Oa, Aa),
              this._element.removeAttribute(`aria-modal`),
              this._element.removeAttribute(`role`),
              this._config.scroll || new $i().reset(),
              V.trigger(this._element, La);
          },
          this._element,
          !0,
        ));
    }
    dispose() {
      this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose();
    }
    _initializeBackDrop() {
      let e = () => {
          if (this._config.backdrop === `static`) {
            V.trigger(this._element, Ia);
            return;
          }
          this.hide();
        },
        t = !!this._config.backdrop;
      return new Ri({
        className: ja,
        isVisible: t,
        isAnimated: !0,
        rootElement: this._element.parentNode,
        clickCallback: t ? e : null,
      });
    }
    _initializeFocusTrap() {
      return new Ji({ trapElement: this._element });
    }
    _addEventListeners() {
      V.on(this._element, Ba, (e) => {
        if (e.key === Da) {
          if (this._config.keyboard) {
            this.hide();
            return;
          }
          V.trigger(this._element, Ia);
        }
      });
    }
    static jQueryInterface(t) {
      return this.each(function () {
        let n = e.getOrCreateInstance(this, t);
        if (typeof t == `string`) {
          if (n[t] === void 0 || t.startsWith(`_`) || t === `constructor`)
            throw TypeError(`No method named "${t}"`);
          n[t](this);
        }
      });
    }
  };
V.on(document, za, Va, function (e) {
  let t = W.getElementFromSelector(this);
  if (([`A`, `AREA`].includes(this.tagName) && e.preventDefault(), Lt(this)))
    return;
  V.one(t, La, () => {
    It(this) && this.focus();
  });
  let n = W.findOne(Ma);
  n && n !== t && Wa.getInstance(n).hide(),
    Wa.getOrCreateInstance(t).toggle(this);
}),
  V.on(window, Ea, () => {
    for (let e of W.find(Ma)) Wa.getOrCreateInstance(e).show();
  }),
  V.on(window, Ra, () => {
    for (let e of W.find(`[aria-modal][class*=show][class*=offcanvas-]`))
      getComputedStyle(e).position !== `fixed` &&
        Wa.getOrCreateInstance(e).hide();
  }),
  gn(Wa),
  z(Wa);
var Ga = /^aria-[\w-]*$/i,
  Ka = {
    "*": [`class`, `dir`, `id`, `lang`, `role`, Ga],
    a: [`target`, `href`, `title`, `rel`],
    area: [],
    b: [],
    br: [],
    col: [],
    code: [],
    dd: [],
    div: [],
    dl: [],
    dt: [],
    em: [],
    hr: [],
    h1: [],
    h2: [],
    h3: [],
    h4: [],
    h5: [],
    h6: [],
    i: [],
    img: [`src`, `srcset`, `alt`, `title`, `width`, `height`],
    li: [],
    ol: [],
    p: [],
    pre: [],
    s: [],
    small: [],
    span: [],
    sub: [],
    sup: [],
    strong: [],
    u: [],
    ul: [],
  },
  qa = new Set([
    `background`,
    `cite`,
    `href`,
    `itemtype`,
    `longdesc`,
    `poster`,
    `src`,
    `xlink:href`,
  ]),
  Ja = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:/?#]*(?:[/?#]|$))/i,
  Ya = (e, t) => {
    let n = e.nodeName.toLowerCase();
    return t.includes(n)
      ? qa.has(n)
        ? !!Ja.test(e.nodeValue)
        : !0
      : t.filter((e) => e instanceof RegExp).some((e) => e.test(n));
  };
function Xa(e, t, n) {
  if (!e.length) return e;
  if (n && typeof n == `function`) return n(e);
  let r = new window.DOMParser().parseFromString(e, `text/html`),
    i = [].concat(...r.body.querySelectorAll(`*`));
  for (let e of i) {
    let n = e.nodeName.toLowerCase();
    if (!Object.keys(t).includes(n)) {
      e.remove();
      continue;
    }
    let r = [].concat(...e.attributes),
      i = [].concat(t[`*`] || [], t[n] || []);
    for (let t of r) Ya(t, i) || e.removeAttribute(t.nodeName);
  }
  return r.body.innerHTML;
}
var Za = `TemplateFactory`,
  Qa = {
    allowList: Ka,
    content: {},
    extraClass: ``,
    html: !1,
    sanitize: !0,
    sanitizeFn: null,
    template: `<div></div>`,
  },
  $a = {
    allowList: `object`,
    content: `object`,
    extraClass: `(string|function)`,
    html: `boolean`,
    sanitize: `boolean`,
    sanitizeFn: `(null|function)`,
    template: `string`,
  },
  eo = {
    entry: `(string|element|function|null)`,
    selector: `(string|element)`,
  },
  to = class extends pn {
    constructor(e) {
      super(), (this._config = this._getConfig(e));
    }
    static get Default() {
      return Qa;
    }
    static get DefaultType() {
      return $a;
    }
    static get NAME() {
      return Za;
    }
    getContent() {
      return Object.values(this._config.content)
        .map((e) => this._resolvePossibleFunction(e))
        .filter(Boolean);
    }
    hasContent() {
      return this.getContent().length > 0;
    }
    changeContent(e) {
      return (
        this._checkContent(e),
        (this._config.content = { ...this._config.content, ...e }),
        this
      );
    }
    toHtml() {
      let e = document.createElement(`div`);
      e.innerHTML = this._maybeSanitize(this._config.template);
      for (let [t, n] of Object.entries(this._config.content))
        this._setContent(e, n, t);
      let t = e.children[0],
        n = this._resolvePossibleFunction(this._config.extraClass);
      return n && t.classList.add(...n.split(` `)), t;
    }
    _typeCheckConfig(e) {
      super._typeCheckConfig(e), this._checkContent(e.content);
    }
    _checkContent(e) {
      for (let [t, n] of Object.entries(e))
        super._typeCheckConfig({ selector: t, entry: n }, eo);
    }
    _setContent(e, t, n) {
      let r = W.findOne(n, e);
      if (r) {
        if (((t = this._resolvePossibleFunction(t)), !t)) {
          r.remove();
          return;
        }
        if (Pt(t)) {
          this._putElementInTemplate(Ft(t), r);
          return;
        }
        if (this._config.html) {
          r.innerHTML = this._maybeSanitize(t);
          return;
        }
        r.textContent = t;
      }
    }
    _maybeSanitize(e) {
      return this._config.sanitize
        ? Xa(e, this._config.allowList, this._config.sanitizeFn)
        : e;
    }
    _resolvePossibleFunction(e) {
      return B(e, [void 0, this]);
    }
    _putElementInTemplate(e, t) {
      if (this._config.html) {
        (t.innerHTML = ``), t.append(e);
        return;
      }
      t.textContent = e.textContent;
    }
  },
  no = `tooltip`,
  ro = new Set([`sanitize`, `allowList`, `sanitizeFn`]),
  io = `fade`,
  ao = `modal`,
  oo = `show`,
  so = `.tooltip-inner`,
  co = `.${ao}`,
  lo = `hide.bs.modal`,
  uo = `hover`,
  fo = `focus`,
  po = `click`,
  mo = `manual`,
  ho = `hide`,
  go = `hidden`,
  _o = `show`,
  vo = `shown`,
  yo = `inserted`,
  bo = `click`,
  xo = `focusin`,
  So = `focusout`,
  Co = `mouseenter`,
  wo = `mouseleave`,
  To = {
    AUTO: `auto`,
    TOP: `top`,
    RIGHT: R() ? `left` : `right`,
    BOTTOM: `bottom`,
    LEFT: R() ? `right` : `left`,
  },
  Eo = {
    allowList: Ka,
    animation: !0,
    boundary: `clippingParents`,
    container: !1,
    customClass: ``,
    delay: 0,
    fallbackPlacements: [`top`, `right`, `bottom`, `left`],
    html: !1,
    offset: [0, 6],
    placement: `top`,
    popperConfig: null,
    sanitize: !0,
    sanitizeFn: null,
    selector: !1,
    template: `<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>`,
    title: ``,
    trigger: `hover focus`,
  },
  Do = {
    allowList: `object`,
    animation: `boolean`,
    boundary: `(string|element)`,
    container: `(string|element|boolean)`,
    customClass: `(string|function)`,
    delay: `(number|object)`,
    fallbackPlacements: `array`,
    html: `boolean`,
    offset: `(array|string|function)`,
    placement: `(string|function)`,
    popperConfig: `(null|object|function)`,
    sanitize: `boolean`,
    sanitizeFn: `(null|function)`,
    selector: `(string|boolean)`,
    template: `string`,
    title: `(string|element|function)`,
    trigger: `string`,
  },
  Oo = class e extends U {
    constructor(e, t) {
      if (Ct === void 0)
        throw TypeError(
          `Bootstrap's tooltips require Popper (https://popper.js.org/docs/v2/)`,
        );
      super(e, t),
        (this._isEnabled = !0),
        (this._timeout = 0),
        (this._isHovered = null),
        (this._activeTrigger = {}),
        (this._popper = null),
        (this._templateFactory = null),
        (this._newContent = null),
        (this.tip = null),
        this._setListeners(),
        this._config.selector || this._fixTitle();
    }
    static get Default() {
      return Eo;
    }
    static get DefaultType() {
      return Do;
    }
    static get NAME() {
      return no;
    }
    enable() {
      this._isEnabled = !0;
    }
    disable() {
      this._isEnabled = !1;
    }
    toggleEnabled() {
      this._isEnabled = !this._isEnabled;
    }
    toggle() {
      if (this._isEnabled) {
        if (this._isShown()) {
          this._leave();
          return;
        }
        this._enter();
      }
    }
    dispose() {
      clearTimeout(this._timeout),
        V.off(this._element.closest(co), lo, this._hideModalHandler),
        this._element.getAttribute(`data-bs-original-title`) &&
          this._element.setAttribute(
            `title`,
            this._element.getAttribute(`data-bs-original-title`),
          ),
        this._disposePopper(),
        super.dispose();
    }
    show() {
      if (this._element.style.display === `none`)
        throw Error(`Please use show on visible elements`);
      if (!(this._isWithContent() && this._isEnabled)) return;
      let e = V.trigger(this._element, this.constructor.eventName(_o)),
        t = (
          Rt(this._element) || this._element.ownerDocument.documentElement
        ).contains(this._element);
      if (e.defaultPrevented || !t) return;
      this._disposePopper();
      let n = this._getTipElement();
      this._element.setAttribute(`aria-describedby`, n.getAttribute(`id`));
      let { container: r } = this._config;
      if (
        (this._element.ownerDocument.documentElement.contains(this.tip) ||
          (r.append(n),
          V.trigger(this._element, this.constructor.eventName(yo))),
        (this._popper = this._createPopper(n)),
        n.classList.add(oo),
        `ontouchstart` in document.documentElement)
      )
        for (let e of [].concat(...document.body.children))
          V.on(e, `mouseover`, zt);
      this._queueCallback(
        () => {
          V.trigger(this._element, this.constructor.eventName(vo)),
            this._isHovered === !1 && this._leave(),
            (this._isHovered = !1);
        },
        this.tip,
        this._isAnimated(),
      );
    }
    hide() {
      if (
        !(
          !this._isShown() ||
          V.trigger(this._element, this.constructor.eventName(ho))
            .defaultPrevented
        )
      ) {
        if (
          (this._getTipElement().classList.remove(oo),
          `ontouchstart` in document.documentElement)
        )
          for (let e of [].concat(...document.body.children))
            V.off(e, `mouseover`, zt);
        (this._activeTrigger[po] = !1),
          (this._activeTrigger[fo] = !1),
          (this._activeTrigger[uo] = !1),
          (this._isHovered = null),
          this._queueCallback(
            () => {
              this._isWithActiveTrigger() ||
                (this._isHovered || this._disposePopper(),
                this._element.removeAttribute(`aria-describedby`),
                V.trigger(this._element, this.constructor.eventName(go)));
            },
            this.tip,
            this._isAnimated(),
          );
      }
    }
    update() {
      this._popper && this._popper.update();
    }
    _isWithContent() {
      return !!this._getTitle();
    }
    _getTipElement() {
      return (
        (this.tip ||= this._createTipElement(
          this._newContent || this._getContentForTemplate(),
        )),
        this.tip
      );
    }
    _createTipElement(e) {
      let t = this._getTemplateFactory(e).toHtml();
      if (!t) return null;
      t.classList.remove(io, oo),
        t.classList.add(`bs-${this.constructor.NAME}-auto`);
      let n = jt(this.constructor.NAME).toString();
      return (
        t.setAttribute(`id`, n), this._isAnimated() && t.classList.add(io), t
      );
    }
    setContent(e) {
      (this._newContent = e),
        this._isShown() && (this._disposePopper(), this.show());
    }
    _getTemplateFactory(e) {
      return (
        this._templateFactory
          ? this._templateFactory.changeContent(e)
          : (this._templateFactory = new to({
              ...this._config,
              content: e,
              extraClass: this._resolvePossibleFunction(
                this._config.customClass,
              ),
            })),
        this._templateFactory
      );
    }
    _getContentForTemplate() {
      return { [so]: this._getTitle() };
    }
    _getTitle() {
      return (
        this._resolvePossibleFunction(this._config.title) ||
        this._element.getAttribute(`data-bs-original-title`)
      );
    }
    _initializeOnDelegatedTarget(e) {
      return this.constructor.getOrCreateInstance(
        e.delegateTarget,
        this._getDelegateConfig(),
      );
    }
    _isAnimated() {
      return (
        this._config.animation || (this.tip && this.tip.classList.contains(io))
      );
    }
    _isShown() {
      return this.tip && this.tip.classList.contains(oo);
    }
    _createPopper(e) {
      let t =
        To[B(this._config.placement, [this, e, this._element]).toUpperCase()];
      return St(this._element, e, this._getPopperConfig(t));
    }
    _getOffset() {
      let { offset: e } = this._config;
      return typeof e == `string`
        ? e.split(`,`).map((e) => Number.parseInt(e, 10))
        : typeof e == `function`
        ? (t) => e(t, this._element)
        : e;
    }
    _resolvePossibleFunction(e) {
      return B(e, [this._element, this._element]);
    }
    _getPopperConfig(e) {
      let t = {
        placement: e,
        modifiers: [
          {
            name: `flip`,
            options: { fallbackPlacements: this._config.fallbackPlacements },
          },
          { name: `offset`, options: { offset: this._getOffset() } },
          {
            name: `preventOverflow`,
            options: { boundary: this._config.boundary },
          },
          {
            name: `arrow`,
            options: { element: `.${this.constructor.NAME}-arrow` },
          },
          {
            name: `preSetPlacement`,
            enabled: !0,
            phase: `beforeMain`,
            fn: (e) => {
              this._getTipElement().setAttribute(
                `data-popper-placement`,
                e.state.placement,
              );
            },
          },
        ],
      };
      return { ...t, ...B(this._config.popperConfig, [void 0, t]) };
    }
    _setListeners() {
      let e = this._config.trigger.split(` `);
      for (let t of e)
        if (t === `click`)
          V.on(
            this._element,
            this.constructor.eventName(bo),
            this._config.selector,
            (e) => {
              let t = this._initializeOnDelegatedTarget(e);
              (t._activeTrigger[po] = !(t._isShown() && t._activeTrigger[po])),
                t.toggle();
            },
          );
        else if (t !== mo) {
          let e =
              t === uo
                ? this.constructor.eventName(Co)
                : this.constructor.eventName(xo),
            n =
              t === uo
                ? this.constructor.eventName(wo)
                : this.constructor.eventName(So);
          V.on(this._element, e, this._config.selector, (e) => {
            let t = this._initializeOnDelegatedTarget(e);
            (t._activeTrigger[e.type === `focusin` ? fo : uo] = !0), t._enter();
          }),
            V.on(this._element, n, this._config.selector, (e) => {
              let t = this._initializeOnDelegatedTarget(e);
              (t._activeTrigger[e.type === `focusout` ? fo : uo] =
                t._element.contains(e.relatedTarget)),
                t._leave();
            });
        }
      (this._hideModalHandler = () => {
        this._element && this.hide();
      }),
        V.on(this._element.closest(co), lo, this._hideModalHandler);
    }
    _fixTitle() {
      let e = this._element.getAttribute(`title`);
      e &&
        (!this._element.getAttribute(`aria-label`) &&
          !this._element.textContent.trim() &&
          this._element.setAttribute(`aria-label`, e),
        this._element.setAttribute(`data-bs-original-title`, e),
        this._element.removeAttribute(`title`));
    }
    _enter() {
      if (this._isShown() || this._isHovered) {
        this._isHovered = !0;
        return;
      }
      (this._isHovered = !0),
        this._setTimeout(() => {
          this._isHovered && this.show();
        }, this._config.delay.show);
    }
    _leave() {
      this._isWithActiveTrigger() ||
        ((this._isHovered = !1),
        this._setTimeout(() => {
          this._isHovered || this.hide();
        }, this._config.delay.hide));
    }
    _setTimeout(e, t) {
      clearTimeout(this._timeout), (this._timeout = setTimeout(e, t));
    }
    _isWithActiveTrigger() {
      return Object.values(this._activeTrigger).includes(!0);
    }
    _getConfig(e) {
      let t = H.getDataAttributes(this._element);
      for (let e of Object.keys(t)) ro.has(e) && delete t[e];
      return (
        (e = { ...t, ...(typeof e == `object` && e ? e : {}) }),
        (e = this._mergeConfigObj(e)),
        (e = this._configAfterMerge(e)),
        this._typeCheckConfig(e),
        e
      );
    }
    _configAfterMerge(e) {
      return (
        (e.container = e.container === !1 ? document.body : Ft(e.container)),
        typeof e.delay == `number` &&
          (e.delay = { show: e.delay, hide: e.delay }),
        typeof e.title == `number` && (e.title = e.title.toString()),
        typeof e.content == `number` && (e.content = e.content.toString()),
        e
      );
    }
    _getDelegateConfig() {
      let e = {};
      for (let [t, n] of Object.entries(this._config))
        this.constructor.Default[t] !== n && (e[t] = n);
      return (e.selector = !1), (e.trigger = `manual`), e;
    }
    _disposePopper() {
      (this._popper &&= (this._popper.destroy(), null)),
        (this.tip &&= (this.tip.remove(), null));
    }
    static jQueryInterface(t) {
      return this.each(function () {
        let n = e.getOrCreateInstance(this, t);
        if (typeof t == `string`) {
          if (n[t] === void 0) throw TypeError(`No method named "${t}"`);
          n[t]();
        }
      });
    }
  };
z(Oo);
var ko = `popover`,
  Ao = `.popover-header`,
  jo = `.popover-body`,
  Mo = {
    ...Oo.Default,
    content: ``,
    offset: [0, 8],
    placement: `right`,
    template: `<div class="popover" role="tooltip"><div class="popover-arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>`,
    trigger: `click`,
  },
  No = { ...Oo.DefaultType, content: `(null|string|element|function)` };
z(
  class e extends Oo {
    static get Default() {
      return Mo;
    }
    static get DefaultType() {
      return No;
    }
    static get NAME() {
      return ko;
    }
    _isWithContent() {
      return this._getTitle() || this._getContent();
    }
    _getContentForTemplate() {
      return { [Ao]: this._getTitle(), [jo]: this._getContent() };
    }
    _getContent() {
      return this._resolvePossibleFunction(this._config.content);
    }
    static jQueryInterface(t) {
      return this.each(function () {
        let n = e.getOrCreateInstance(this, t);
        if (typeof t == `string`) {
          if (n[t] === void 0) throw TypeError(`No method named "${t}"`);
          n[t]();
        }
      });
    }
  },
);
var Po = `scrollspy`,
  Fo = `.bs.scrollspy`,
  Io = `.data-api`,
  Lo = `activate${Fo}`,
  Ro = `click${Fo}`,
  zo = `load${Fo}${Io}`,
  Bo = `dropdown-item`,
  Vo = `active`,
  Ho = `[data-bs-spy="scroll"]`,
  Uo = `[href]`,
  Wo = `.nav, .list-group`,
  Go = `.nav-link`,
  Ko = `${Go}, .nav-item > ${Go}, .list-group-item`,
  qo = `.dropdown`,
  Jo = `.dropdown-toggle`,
  Yo = {
    offset: null,
    rootMargin: `0px 0px -25%`,
    smoothScroll: !1,
    target: null,
    threshold: [0.1, 0.5, 1],
  },
  Xo = {
    offset: `(number|null)`,
    rootMargin: `string`,
    smoothScroll: `boolean`,
    target: `element`,
    threshold: `array`,
  },
  Zo = class e extends U {
    constructor(e, t) {
      super(e, t),
        (this._targetLinks = new Map()),
        (this._observableSections = new Map()),
        (this._rootElement =
          getComputedStyle(this._element).overflowY === `visible`
            ? null
            : this._element),
        (this._activeTarget = null),
        (this._observer = null),
        (this._previousScrollData = { visibleEntryTop: 0, parentScrollTop: 0 }),
        this.refresh();
    }
    static get Default() {
      return Yo;
    }
    static get DefaultType() {
      return Xo;
    }
    static get NAME() {
      return Po;
    }
    refresh() {
      this._initializeTargetsAndObservables(),
        this._maybeEnableSmoothScroll(),
        this._observer
          ? this._observer.disconnect()
          : (this._observer = this._getNewObserver());
      for (let e of this._observableSections.values())
        this._observer.observe(e);
    }
    dispose() {
      this._observer.disconnect(), super.dispose();
    }
    _configAfterMerge(e) {
      return (
        (e.target = Ft(e.target) || document.body),
        (e.rootMargin = e.offset ? `${e.offset}px 0px -30%` : e.rootMargin),
        typeof e.threshold == `string` &&
          (e.threshold = e.threshold
            .split(`,`)
            .map((e) => Number.parseFloat(e))),
        e
      );
    }
    _maybeEnableSmoothScroll() {
      this._config.smoothScroll &&
        (V.off(this._config.target, Ro),
        V.on(this._config.target, Ro, Uo, (e) => {
          let t = this._observableSections.get(e.target.hash);
          if (t) {
            e.preventDefault();
            let n = this._rootElement || window,
              r = t.offsetTop - this._element.offsetTop;
            if (n.scrollTo) {
              n.scrollTo({ top: r, behavior: `smooth` });
              return;
            }
            n.scrollTop = r;
          }
        }));
    }
    _getNewObserver() {
      let e = {
        root: this._rootElement,
        threshold: this._config.threshold,
        rootMargin: this._config.rootMargin,
      };
      return new IntersectionObserver((e) => this._observerCallback(e), e);
    }
    _observerCallback(e) {
      let t = (e) => this._targetLinks.get(`#${e.target.id}`),
        n = (e) => {
          (this._previousScrollData.visibleEntryTop = e.target.offsetTop),
            this._process(t(e));
        },
        r = (this._rootElement || document.documentElement).scrollTop,
        i = r >= this._previousScrollData.parentScrollTop;
      this._previousScrollData.parentScrollTop = r;
      for (let a of e) {
        if (!a.isIntersecting) {
          (this._activeTarget = null), this._clearActiveClass(t(a));
          continue;
        }
        let e = a.target.offsetTop >= this._previousScrollData.visibleEntryTop;
        if (i && e) {
          if ((n(a), !r)) return;
          continue;
        }
        !i && !e && n(a);
      }
    }
    _initializeTargetsAndObservables() {
      (this._targetLinks = new Map()), (this._observableSections = new Map());
      let e = W.find(Uo, this._config.target);
      for (let t of e) {
        if (!t.hash || Lt(t)) continue;
        let e = W.findOne(decodeURI(t.hash), this._element);
        It(e) &&
          (this._targetLinks.set(decodeURI(t.hash), t),
          this._observableSections.set(t.hash, e));
      }
    }
    _process(e) {
      this._activeTarget !== e &&
        (this._clearActiveClass(this._config.target),
        (this._activeTarget = e),
        e.classList.add(Vo),
        this._activateParents(e),
        V.trigger(this._element, Lo, { relatedTarget: e }));
    }
    _activateParents(e) {
      if (e.classList.contains(Bo)) {
        W.findOne(Jo, e.closest(qo)).classList.add(Vo);
        return;
      }
      for (let t of W.parents(e, Wo))
        for (let e of W.prev(t, Ko)) e.classList.add(Vo);
    }
    _clearActiveClass(e) {
      e.classList.remove(Vo);
      let t = W.find(`${Uo}.${Vo}`, e);
      for (let e of t) e.classList.remove(Vo);
    }
    static jQueryInterface(t) {
      return this.each(function () {
        let n = e.getOrCreateInstance(this, t);
        if (typeof t == `string`) {
          if (n[t] === void 0 || t.startsWith(`_`) || t === `constructor`)
            throw TypeError(`No method named "${t}"`);
          n[t]();
        }
      });
    }
  };
V.on(window, zo, () => {
  for (let e of W.find(Ho)) Zo.getOrCreateInstance(e);
}),
  z(Zo);
var Qo = `tab`,
  $o = `.bs.tab`,
  es = `hide${$o}`,
  ts = `hidden${$o}`,
  ns = `show${$o}`,
  rs = `shown${$o}`,
  is = `click${$o}`,
  as = `keydown${$o}`,
  os = `load${$o}`,
  ss = `ArrowLeft`,
  cs = `ArrowRight`,
  ls = `ArrowUp`,
  us = `ArrowDown`,
  ds = `Home`,
  fs = `End`,
  ps = `active`,
  ms = `fade`,
  hs = `show`,
  gs = `dropdown`,
  _s = `.dropdown-toggle`,
  vs = `.dropdown-menu`,
  ys = `:not(${_s})`,
  bs = `.list-group, .nav, [role="tablist"]`,
  xs = `.nav-item, .list-group-item`,
  Ss = `.nav-link${ys}, .list-group-item${ys}, [role="tab"]${ys}`,
  Cs = `[data-bs-toggle="tab"], [data-bs-toggle="pill"], [data-bs-toggle="list"]`,
  ws = `${Ss}, ${Cs}`,
  Ts = `.${ps}[data-bs-toggle="tab"], .${ps}[data-bs-toggle="pill"], .${ps}[data-bs-toggle="list"]`,
  Es = class e extends U {
    constructor(e) {
      super(e),
        (this._parent = this._element.closest(bs)),
        this._parent &&
          (this._setInitialAttributes(this._parent, this._getChildren()),
          V.on(this._element, as, (e) => this._keydown(e)));
    }
    static get NAME() {
      return Qo;
    }
    show() {
      let e = this._element;
      if (this._elemIsActive(e)) return;
      let t = this._getActiveElem(),
        n = t ? V.trigger(t, es, { relatedTarget: e }) : null;
      V.trigger(e, ns, { relatedTarget: t }).defaultPrevented ||
        (n && n.defaultPrevented) ||
        (this._deactivate(t, e), this._activate(e, t));
    }
    _activate(e, t) {
      e &&
        (e.classList.add(ps),
        this._activate(W.getElementFromSelector(e)),
        this._queueCallback(
          () => {
            if (e.getAttribute(`role`) !== `tab`) {
              e.classList.add(hs);
              return;
            }
            e.removeAttribute(`tabindex`),
              e.setAttribute(`aria-selected`, !0),
              this._toggleDropDown(e, !0),
              V.trigger(e, rs, { relatedTarget: t });
          },
          e,
          e.classList.contains(ms),
        ));
    }
    _deactivate(e, t) {
      e &&
        (e.classList.remove(ps),
        e.blur(),
        this._deactivate(W.getElementFromSelector(e)),
        this._queueCallback(
          () => {
            if (e.getAttribute(`role`) !== `tab`) {
              e.classList.remove(hs);
              return;
            }
            e.setAttribute(`aria-selected`, !1),
              e.setAttribute(`tabindex`, `-1`),
              this._toggleDropDown(e, !1),
              V.trigger(e, ts, { relatedTarget: t });
          },
          e,
          e.classList.contains(ms),
        ));
    }
    _keydown(t) {
      if (![ss, cs, ls, us, ds, fs].includes(t.key)) return;
      t.stopPropagation(), t.preventDefault();
      let n = this._getChildren().filter((e) => !Lt(e)),
        r;
      if ([ds, fs].includes(t.key)) r = n[t.key === ds ? 0 : n.length - 1];
      else {
        let e = [cs, us].includes(t.key);
        r = Gt(n, t.target, e, !0);
      }
      r && (r.focus({ preventScroll: !0 }), e.getOrCreateInstance(r).show());
    }
    _getChildren() {
      return W.find(ws, this._parent);
    }
    _getActiveElem() {
      return this._getChildren().find((e) => this._elemIsActive(e)) || null;
    }
    _setInitialAttributes(e, t) {
      this._setAttributeIfNotExists(e, `role`, `tablist`);
      for (let e of t) this._setInitialAttributesOnChild(e);
    }
    _setInitialAttributesOnChild(e) {
      e = this._getInnerElement(e);
      let t = this._elemIsActive(e),
        n = this._getOuterElement(e);
      e.setAttribute(`aria-selected`, t),
        n !== e && this._setAttributeIfNotExists(n, `role`, `presentation`),
        t || e.setAttribute(`tabindex`, `-1`),
        this._setAttributeIfNotExists(e, `role`, `tab`),
        this._setInitialAttributesOnTargetPanel(e);
    }
    _setInitialAttributesOnTargetPanel(e) {
      let t = W.getElementFromSelector(e);
      t &&
        (this._setAttributeIfNotExists(t, `role`, `tabpanel`),
        e.id && this._setAttributeIfNotExists(t, `aria-labelledby`, `${e.id}`));
    }
    _toggleDropDown(e, t) {
      let n = this._getOuterElement(e);
      if (!n.classList.contains(gs)) return;
      let r = (e, r) => {
        let i = W.findOne(e, n);
        i && i.classList.toggle(r, t);
      };
      r(_s, ps), r(vs, hs), n.setAttribute(`aria-expanded`, t);
    }
    _setAttributeIfNotExists(e, t, n) {
      e.hasAttribute(t) || e.setAttribute(t, n);
    }
    _elemIsActive(e) {
      return e.classList.contains(ps);
    }
    _getInnerElement(e) {
      return e.matches(ws) ? e : W.findOne(ws, e);
    }
    _getOuterElement(e) {
      return e.closest(xs) || e;
    }
    static jQueryInterface(t) {
      return this.each(function () {
        let n = e.getOrCreateInstance(this);
        if (typeof t == `string`) {
          if (n[t] === void 0 || t.startsWith(`_`) || t === `constructor`)
            throw TypeError(`No method named "${t}"`);
          n[t]();
        }
      });
    }
  };
V.on(document, is, Cs, function (e) {
  [`A`, `AREA`].includes(this.tagName) && e.preventDefault(),
    !Lt(this) && Es.getOrCreateInstance(this).show();
}),
  V.on(window, os, () => {
    for (let e of W.find(Ts)) Es.getOrCreateInstance(e);
  }),
  z(Es);
var Ds = `toast`,
  Os = `.bs.toast`,
  ks = `mouseover${Os}`,
  As = `mouseout${Os}`,
  js = `focusin${Os}`,
  Ms = `focusout${Os}`,
  Ns = `hide${Os}`,
  Ps = `hidden${Os}`,
  Fs = `show${Os}`,
  Is = `shown${Os}`,
  Ls = `fade`,
  Rs = `hide`,
  zs = `show`,
  Bs = `showing`,
  Vs = { animation: `boolean`, autohide: `boolean`, delay: `number` },
  Hs = { animation: !0, autohide: !0, delay: 5e3 },
  Us = class e extends U {
    constructor(e, t) {
      super(e, t),
        (this._timeout = null),
        (this._hasMouseInteraction = !1),
        (this._hasKeyboardInteraction = !1),
        this._setListeners();
    }
    static get Default() {
      return Hs;
    }
    static get DefaultType() {
      return Vs;
    }
    static get NAME() {
      return Ds;
    }
    show() {
      V.trigger(this._element, Fs).defaultPrevented ||
        (this._clearTimeout(),
        this._config.animation && this._element.classList.add(Ls),
        this._element.classList.remove(Rs),
        Bt(this._element),
        this._element.classList.add(zs, Bs),
        this._queueCallback(
          () => {
            this._element.classList.remove(Bs),
              V.trigger(this._element, Is),
              this._maybeScheduleHide();
          },
          this._element,
          this._config.animation,
        ));
    }
    hide() {
      !this.isShown() ||
        V.trigger(this._element, Ns).defaultPrevented ||
        (this._element.classList.add(Bs),
        this._queueCallback(
          () => {
            this._element.classList.add(Rs),
              this._element.classList.remove(Bs, zs),
              V.trigger(this._element, Ps);
          },
          this._element,
          this._config.animation,
        ));
    }
    dispose() {
      this._clearTimeout(),
        this.isShown() && this._element.classList.remove(zs),
        super.dispose();
    }
    isShown() {
      return this._element.classList.contains(zs);
    }
    _maybeScheduleHide() {
      this._config.autohide &&
        (this._hasMouseInteraction ||
          this._hasKeyboardInteraction ||
          (this._timeout = setTimeout(() => {
            this.hide();
          }, this._config.delay)));
    }
    _onInteraction(e, t) {
      switch (e.type) {
        case `mouseover`:
        case `mouseout`:
          this._hasMouseInteraction = t;
          break;
        case `focusin`:
        case `focusout`:
          this._hasKeyboardInteraction = t;
          break;
      }
      if (t) {
        this._clearTimeout();
        return;
      }
      let n = e.relatedTarget;
      this._element === n ||
        this._element.contains(n) ||
        this._maybeScheduleHide();
    }
    _setListeners() {
      V.on(this._element, ks, (e) => this._onInteraction(e, !0)),
        V.on(this._element, As, (e) => this._onInteraction(e, !1)),
        V.on(this._element, js, (e) => this._onInteraction(e, !0)),
        V.on(this._element, Ms, (e) => this._onInteraction(e, !1));
    }
    _clearTimeout() {
      clearTimeout(this._timeout), (this._timeout = null);
    }
    static jQueryInterface(t) {
      return this.each(function () {
        let n = e.getOrCreateInstance(this, t);
        if (typeof t == `string`) {
          if (n[t] === void 0) throw TypeError(`No method named "${t}"`);
          n[t](this);
        }
      });
    }
  };
gn(Us), z(Us);
var Ws = { value: () => {} };
function Gs() {
  for (var e = 0, t = arguments.length, n = {}, r; e < t; ++e) {
    if (!(r = arguments[e] + ``) || r in n || /[\s.]/.test(r))
      throw Error(`illegal type: ` + r);
    n[r] = [];
  }
  return new Ks(n);
}
function Ks(e) {
  this._ = e;
}
function qs(e, t) {
  return e
    .trim()
    .split(/^|\s+/)
    .map(function (e) {
      var n = ``,
        r = e.indexOf(`.`);
      if (
        (r >= 0 && ((n = e.slice(r + 1)), (e = e.slice(0, r))),
        e && !t.hasOwnProperty(e))
      )
        throw Error(`unknown type: ` + e);
      return { type: e, name: n };
    });
}
Ks.prototype = Gs.prototype = {
  constructor: Ks,
  on: function (e, t) {
    var n = this._,
      r = qs(e + ``, n),
      i,
      a = -1,
      o = r.length;
    if (arguments.length < 2) {
      for (; ++a < o; )
        if ((i = (e = r[a]).type) && (i = Js(n[i], e.name))) return i;
      return;
    }
    if (t != null && typeof t != `function`)
      throw Error(`invalid callback: ` + t);
    for (; ++a < o; )
      if ((i = (e = r[a]).type)) n[i] = Ys(n[i], e.name, t);
      else if (t == null) for (i in n) n[i] = Ys(n[i], e.name, null);
    return this;
  },
  copy: function () {
    var e = {},
      t = this._;
    for (var n in t) e[n] = t[n].slice();
    return new Ks(e);
  },
  call: function (e, t) {
    if ((i = arguments.length - 2) > 0)
      for (var n = Array(i), r = 0, i, a; r < i; ++r) n[r] = arguments[r + 2];
    if (!this._.hasOwnProperty(e)) throw Error(`unknown type: ` + e);
    for (a = this._[e], r = 0, i = a.length; r < i; ++r) a[r].value.apply(t, n);
  },
  apply: function (e, t, n) {
    if (!this._.hasOwnProperty(e)) throw Error(`unknown type: ` + e);
    for (var r = this._[e], i = 0, a = r.length; i < a; ++i)
      r[i].value.apply(t, n);
  },
};
function Js(e, t) {
  for (var n = 0, r = e.length, i; n < r; ++n)
    if ((i = e[n]).name === t) return i.value;
}
function Ys(e, t, n) {
  for (var r = 0, i = e.length; r < i; ++r)
    if (e[r].name === t) {
      (e[r] = Ws), (e = e.slice(0, r).concat(e.slice(r + 1)));
      break;
    }
  return n != null && e.push({ name: t, value: n }), e;
}
var Xs = Gs,
  Zs = {
    svg: `http://www.w3.org/2000/svg`,
    xhtml: `http://www.w3.org/1999/xhtml`,
    xlink: `http://www.w3.org/1999/xlink`,
    xml: `http://www.w3.org/XML/1998/namespace`,
    xmlns: `http://www.w3.org/2000/xmlns/`,
  };
function Qs(e) {
  var t = (e += ``),
    n = t.indexOf(`:`);
  return (
    n >= 0 && (t = e.slice(0, n)) !== `xmlns` && (e = e.slice(n + 1)),
    Zs.hasOwnProperty(t) ? { space: Zs[t], local: e } : e
  );
}
function $s(e) {
  return function () {
    var t = this.ownerDocument,
      n = this.namespaceURI;
    return n === `http://www.w3.org/1999/xhtml` &&
      t.documentElement.namespaceURI === `http://www.w3.org/1999/xhtml`
      ? t.createElement(e)
      : t.createElementNS(n, e);
  };
}
function ec(e) {
  return function () {
    return this.ownerDocument.createElementNS(e.space, e.local);
  };
}
function tc(e) {
  var t = Qs(e);
  return (t.local ? ec : $s)(t);
}
function nc() {}
function rc(e) {
  return e == null
    ? nc
    : function () {
        return this.querySelector(e);
      };
}
function ic(e) {
  typeof e != `function` && (e = rc(e));
  for (var t = this._groups, n = t.length, r = Array(n), i = 0; i < n; ++i)
    for (
      var a = t[i], o = a.length, s = (r[i] = Array(o)), c, l, u = 0;
      u < o;
      ++u
    )
      (c = a[u]) &&
        (l = e.call(c, c.__data__, u, a)) &&
        (`__data__` in c && (l.__data__ = c.__data__), (s[u] = l));
  return new q(r, this._parents);
}
function ac(e) {
  return e == null ? [] : Array.isArray(e) ? e : Array.from(e);
}
function oc() {
  return [];
}
function sc(e) {
  return e == null
    ? oc
    : function () {
        return this.querySelectorAll(e);
      };
}
function cc(e) {
  return function () {
    return ac(e.apply(this, arguments));
  };
}
function lc(e) {
  e = typeof e == `function` ? cc(e) : sc(e);
  for (var t = this._groups, n = t.length, r = [], i = [], a = 0; a < n; ++a)
    for (var o = t[a], s = o.length, c, l = 0; l < s; ++l)
      (c = o[l]) && (r.push(e.call(c, c.__data__, l, o)), i.push(c));
  return new q(r, i);
}
function uc(e) {
  return function () {
    return this.matches(e);
  };
}
function dc(e) {
  return function (t) {
    return t.matches(e);
  };
}
var fc = Array.prototype.find;
function pc(e) {
  return function () {
    return fc.call(this.children, e);
  };
}
function mc() {
  return this.firstElementChild;
}
function hc(e) {
  return this.select(e == null ? mc : pc(typeof e == `function` ? e : dc(e)));
}
var gc = Array.prototype.filter;
function _c() {
  return Array.from(this.children);
}
function vc(e) {
  return function () {
    return gc.call(this.children, e);
  };
}
function yc(e) {
  return this.selectAll(
    e == null ? _c : vc(typeof e == `function` ? e : dc(e)),
  );
}
function bc(e) {
  typeof e != `function` && (e = uc(e));
  for (var t = this._groups, n = t.length, r = Array(n), i = 0; i < n; ++i)
    for (var a = t[i], o = a.length, s = (r[i] = []), c, l = 0; l < o; ++l)
      (c = a[l]) && e.call(c, c.__data__, l, a) && s.push(c);
  return new q(r, this._parents);
}
function xc(e) {
  return Array(e.length);
}
function Sc() {
  return new q(this._enter || this._groups.map(xc), this._parents);
}
function Cc(e, t) {
  (this.ownerDocument = e.ownerDocument),
    (this.namespaceURI = e.namespaceURI),
    (this._next = null),
    (this._parent = e),
    (this.__data__ = t);
}
Cc.prototype = {
  constructor: Cc,
  appendChild: function (e) {
    return this._parent.insertBefore(e, this._next);
  },
  insertBefore: function (e, t) {
    return this._parent.insertBefore(e, t);
  },
  querySelector: function (e) {
    return this._parent.querySelector(e);
  },
  querySelectorAll: function (e) {
    return this._parent.querySelectorAll(e);
  },
};
function wc(e) {
  return function () {
    return e;
  };
}
function Tc(e, t, n, r, i, a) {
  for (var o = 0, s, c = t.length, l = a.length; o < l; ++o)
    (s = t[o]) ? ((s.__data__ = a[o]), (r[o] = s)) : (n[o] = new Cc(e, a[o]));
  for (; o < c; ++o) (s = t[o]) && (i[o] = s);
}
function Ec(e, t, n, r, i, a, o) {
  var s,
    c,
    l = new Map(),
    u = t.length,
    d = a.length,
    f = Array(u),
    p;
  for (s = 0; s < u; ++s)
    (c = t[s]) &&
      ((f[s] = p = o.call(c, c.__data__, s, t) + ``),
      l.has(p) ? (i[s] = c) : l.set(p, c));
  for (s = 0; s < d; ++s)
    (p = o.call(e, a[s], s, a) + ``),
      (c = l.get(p))
        ? ((r[s] = c), (c.__data__ = a[s]), l.delete(p))
        : (n[s] = new Cc(e, a[s]));
  for (s = 0; s < u; ++s) (c = t[s]) && l.get(f[s]) === c && (i[s] = c);
}
function Dc(e) {
  return e.__data__;
}
function Oc(e, t) {
  if (!arguments.length) return Array.from(this, Dc);
  var n = t ? Ec : Tc,
    r = this._parents,
    i = this._groups;
  typeof e != `function` && (e = wc(e));
  for (
    var a = i.length, o = Array(a), s = Array(a), c = Array(a), l = 0;
    l < a;
    ++l
  ) {
    var u = r[l],
      d = i[l],
      f = d.length,
      p = kc(e.call(u, u && u.__data__, l, r)),
      m = p.length,
      h = (s[l] = Array(m)),
      g = (o[l] = Array(m));
    n(u, d, h, g, (c[l] = Array(f)), p, t);
    for (var _ = 0, v = 0, y, b; _ < m; ++_)
      if ((y = h[_])) {
        for (_ >= v && (v = _ + 1); !(b = g[v]) && ++v < m; );
        y._next = b || null;
      }
  }
  return (o = new q(o, r)), (o._enter = s), (o._exit = c), o;
}
function kc(e) {
  return typeof e == `object` && `length` in e ? e : Array.from(e);
}
function Ac() {
  return new q(this._exit || this._groups.map(xc), this._parents);
}
function jc(e, t, n) {
  var r = this.enter(),
    i = this,
    a = this.exit();
  return (
    typeof e == `function`
      ? ((r = e(r)), (r &&= r.selection()))
      : (r = r.append(e + ``)),
    t != null && ((i = t(i)), (i &&= i.selection())),
    n == null ? a.remove() : n(a),
    r && i ? r.merge(i).order() : i
  );
}
function Mc(e) {
  for (
    var t = e.selection ? e.selection() : e,
      n = this._groups,
      r = t._groups,
      i = n.length,
      a = r.length,
      o = Math.min(i, a),
      s = Array(i),
      c = 0;
    c < o;
    ++c
  )
    for (
      var l = n[c], u = r[c], d = l.length, f = (s[c] = Array(d)), p, m = 0;
      m < d;
      ++m
    )
      (p = l[m] || u[m]) && (f[m] = p);
  for (; c < i; ++c) s[c] = n[c];
  return new q(s, this._parents);
}
function Nc() {
  for (var e = this._groups, t = -1, n = e.length; ++t < n; )
    for (var r = e[t], i = r.length - 1, a = r[i], o; --i >= 0; )
      (o = r[i]) &&
        (a &&
          o.compareDocumentPosition(a) ^ 4 &&
          a.parentNode.insertBefore(o, a),
        (a = o));
  return this;
}
function Pc(e) {
  e ||= Fc;
  function t(t, n) {
    return t && n ? e(t.__data__, n.__data__) : !t - !n;
  }
  for (var n = this._groups, r = n.length, i = Array(r), a = 0; a < r; ++a) {
    for (
      var o = n[a], s = o.length, c = (i[a] = Array(s)), l, u = 0;
      u < s;
      ++u
    )
      (l = o[u]) && (c[u] = l);
    c.sort(t);
  }
  return new q(i, this._parents).order();
}
function Fc(e, t) {
  return e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN;
}
function Ic() {
  var e = arguments[0];
  return (arguments[0] = this), e.apply(null, arguments), this;
}
function Lc() {
  return Array.from(this);
}
function Rc() {
  for (var e = this._groups, t = 0, n = e.length; t < n; ++t)
    for (var r = e[t], i = 0, a = r.length; i < a; ++i) {
      var o = r[i];
      if (o) return o;
    }
  return null;
}
function zc() {
  let e = 0;
  for (let t of this) ++e;
  return e;
}
function Bc() {
  return !this.node();
}
function Vc(e) {
  for (var t = this._groups, n = 0, r = t.length; n < r; ++n)
    for (var i = t[n], a = 0, o = i.length, s; a < o; ++a)
      (s = i[a]) && e.call(s, s.__data__, a, i);
  return this;
}
function Hc(e) {
  return function () {
    this.removeAttribute(e);
  };
}
function Uc(e) {
  return function () {
    this.removeAttributeNS(e.space, e.local);
  };
}
function Wc(e, t) {
  return function () {
    this.setAttribute(e, t);
  };
}
function Gc(e, t) {
  return function () {
    this.setAttributeNS(e.space, e.local, t);
  };
}
function Kc(e, t) {
  return function () {
    var n = t.apply(this, arguments);
    n == null ? this.removeAttribute(e) : this.setAttribute(e, n);
  };
}
function qc(e, t) {
  return function () {
    var n = t.apply(this, arguments);
    n == null
      ? this.removeAttributeNS(e.space, e.local)
      : this.setAttributeNS(e.space, e.local, n);
  };
}
function Jc(e, t) {
  var n = Qs(e);
  if (arguments.length < 2) {
    var r = this.node();
    return n.local ? r.getAttributeNS(n.space, n.local) : r.getAttribute(n);
  }
  return this.each(
    (t == null
      ? n.local
        ? Uc
        : Hc
      : typeof t == `function`
      ? n.local
        ? qc
        : Kc
      : n.local
      ? Gc
      : Wc)(n, t),
  );
}
function Yc(e) {
  return (
    (e.ownerDocument && e.ownerDocument.defaultView) ||
    (e.document && e) ||
    e.defaultView
  );
}
function Xc(e) {
  return function () {
    this.style.removeProperty(e);
  };
}
function Zc(e, t, n) {
  return function () {
    this.style.setProperty(e, t, n);
  };
}
function Qc(e, t, n) {
  return function () {
    var r = t.apply(this, arguments);
    r == null ? this.style.removeProperty(e) : this.style.setProperty(e, r, n);
  };
}
function $c(e, t, n) {
  return arguments.length > 1
    ? this.each(
        (t == null ? Xc : typeof t == `function` ? Qc : Zc)(e, t, n ?? ``),
      )
    : el(this.node(), e);
}
function el(e, t) {
  return (
    e.style.getPropertyValue(t) ||
    Yc(e).getComputedStyle(e, null).getPropertyValue(t)
  );
}
function tl(e) {
  return function () {
    delete this[e];
  };
}
function nl(e, t) {
  return function () {
    this[e] = t;
  };
}
function rl(e, t) {
  return function () {
    var n = t.apply(this, arguments);
    n == null ? delete this[e] : (this[e] = n);
  };
}
function il(e, t) {
  return arguments.length > 1
    ? this.each((t == null ? tl : typeof t == `function` ? rl : nl)(e, t))
    : this.node()[e];
}
function al(e) {
  return e.trim().split(/^|\s+/);
}
function ol(e) {
  return e.classList || new sl(e);
}
function sl(e) {
  (this._node = e), (this._names = al(e.getAttribute(`class`) || ``));
}
sl.prototype = {
  add: function (e) {
    this._names.indexOf(e) < 0 &&
      (this._names.push(e),
      this._node.setAttribute(`class`, this._names.join(` `)));
  },
  remove: function (e) {
    var t = this._names.indexOf(e);
    t >= 0 &&
      (this._names.splice(t, 1),
      this._node.setAttribute(`class`, this._names.join(` `)));
  },
  contains: function (e) {
    return this._names.indexOf(e) >= 0;
  },
};
function cl(e, t) {
  for (var n = ol(e), r = -1, i = t.length; ++r < i; ) n.add(t[r]);
}
function ll(e, t) {
  for (var n = ol(e), r = -1, i = t.length; ++r < i; ) n.remove(t[r]);
}
function ul(e) {
  return function () {
    cl(this, e);
  };
}
function dl(e) {
  return function () {
    ll(this, e);
  };
}
function fl(e, t) {
  return function () {
    (t.apply(this, arguments) ? cl : ll)(this, e);
  };
}
function pl(e, t) {
  var n = al(e + ``);
  if (arguments.length < 2) {
    for (var r = ol(this.node()), i = -1, a = n.length; ++i < a; )
      if (!r.contains(n[i])) return !1;
    return !0;
  }
  return this.each((typeof t == `function` ? fl : t ? ul : dl)(n, t));
}
function ml() {
  this.textContent = ``;
}
function hl(e) {
  return function () {
    this.textContent = e;
  };
}
function gl(e) {
  return function () {
    this.textContent = e.apply(this, arguments) ?? ``;
  };
}
function _l(e) {
  return arguments.length
    ? this.each(e == null ? ml : (typeof e == `function` ? gl : hl)(e))
    : this.node().textContent;
}
function vl() {
  this.innerHTML = ``;
}
function yl(e) {
  return function () {
    this.innerHTML = e;
  };
}
function bl(e) {
  return function () {
    this.innerHTML = e.apply(this, arguments) ?? ``;
  };
}
function xl(e) {
  return arguments.length
    ? this.each(e == null ? vl : (typeof e == `function` ? bl : yl)(e))
    : this.node().innerHTML;
}
function Sl() {
  this.nextSibling && this.parentNode.appendChild(this);
}
function Cl() {
  return this.each(Sl);
}
function wl() {
  this.previousSibling &&
    this.parentNode.insertBefore(this, this.parentNode.firstChild);
}
function Tl() {
  return this.each(wl);
}
function El(e) {
  var t = typeof e == `function` ? e : tc(e);
  return this.select(function () {
    return this.appendChild(t.apply(this, arguments));
  });
}
function Dl() {
  return null;
}
function Ol(e, t) {
  var n = typeof e == `function` ? e : tc(e),
    r = t == null ? Dl : typeof t == `function` ? t : rc(t);
  return this.select(function () {
    return this.insertBefore(
      n.apply(this, arguments),
      r.apply(this, arguments) || null,
    );
  });
}
function kl() {
  var e = this.parentNode;
  e && e.removeChild(this);
}
function Al() {
  return this.each(kl);
}
function jl() {
  var e = this.cloneNode(!1),
    t = this.parentNode;
  return t ? t.insertBefore(e, this.nextSibling) : e;
}
function Ml() {
  var e = this.cloneNode(!0),
    t = this.parentNode;
  return t ? t.insertBefore(e, this.nextSibling) : e;
}
function Nl(e) {
  return this.select(e ? Ml : jl);
}
function Pl(e) {
  return arguments.length ? this.property(`__data__`, e) : this.node().__data__;
}
function Fl(e) {
  return function (t) {
    e.call(this, t, this.__data__);
  };
}
function Il(e) {
  return e
    .trim()
    .split(/^|\s+/)
    .map(function (e) {
      var t = ``,
        n = e.indexOf(`.`);
      return (
        n >= 0 && ((t = e.slice(n + 1)), (e = e.slice(0, n))),
        { type: e, name: t }
      );
    });
}
function Ll(e) {
  return function () {
    var t = this.__on;
    if (t) {
      for (var n = 0, r = -1, i = t.length, a; n < i; ++n)
        (a = t[n]),
          (!e.type || a.type === e.type) && a.name === e.name
            ? this.removeEventListener(a.type, a.listener, a.options)
            : (t[++r] = a);
      ++r ? (t.length = r) : delete this.__on;
    }
  };
}
function Rl(e, t, n) {
  return function () {
    var r = this.__on,
      i,
      a = Fl(t);
    if (r) {
      for (var o = 0, s = r.length; o < s; ++o)
        if ((i = r[o]).type === e.type && i.name === e.name) {
          this.removeEventListener(i.type, i.listener, i.options),
            this.addEventListener(i.type, (i.listener = a), (i.options = n)),
            (i.value = t);
          return;
        }
    }
    this.addEventListener(e.type, a, n),
      (i = { type: e.type, name: e.name, value: t, listener: a, options: n }),
      r ? r.push(i) : (this.__on = [i]);
  };
}
function zl(e, t, n) {
  var r = Il(e + ``),
    i,
    a = r.length,
    o;
  if (arguments.length < 2) {
    var s = this.node().__on;
    if (s) {
      for (var c = 0, l = s.length, u; c < l; ++c)
        for (i = 0, u = s[c]; i < a; ++i)
          if ((o = r[i]).type === u.type && o.name === u.name) return u.value;
    }
    return;
  }
  for (s = t ? Rl : Ll, i = 0; i < a; ++i) this.each(s(r[i], t, n));
  return this;
}
function Bl(e, t, n) {
  var r = Yc(e),
    i = r.CustomEvent;
  typeof i == `function`
    ? (i = new i(t, n))
    : ((i = r.document.createEvent(`Event`)),
      n
        ? (i.initEvent(t, n.bubbles, n.cancelable), (i.detail = n.detail))
        : i.initEvent(t, !1, !1)),
    e.dispatchEvent(i);
}
function Vl(e, t) {
  return function () {
    return Bl(this, e, t);
  };
}
function Hl(e, t) {
  return function () {
    return Bl(this, e, t.apply(this, arguments));
  };
}
function Ul(e, t) {
  return this.each((typeof t == `function` ? Hl : Vl)(e, t));
}
function* Wl() {
  for (var e = this._groups, t = 0, n = e.length; t < n; ++t)
    for (var r = e[t], i = 0, a = r.length, o; i < a; ++i)
      (o = r[i]) && (yield o);
}
var Gl = [null];
function q(e, t) {
  (this._groups = e), (this._parents = t);
}
function Kl() {
  return new q([[document.documentElement]], Gl);
}
function ql() {
  return this;
}
q.prototype = Kl.prototype = {
  constructor: q,
  select: ic,
  selectAll: lc,
  selectChild: hc,
  selectChildren: yc,
  filter: bc,
  data: Oc,
  enter: Sc,
  exit: Ac,
  join: jc,
  merge: Mc,
  selection: ql,
  order: Nc,
  sort: Pc,
  call: Ic,
  nodes: Lc,
  node: Rc,
  size: zc,
  empty: Bc,
  each: Vc,
  attr: Jc,
  style: $c,
  property: il,
  classed: pl,
  text: _l,
  html: xl,
  raise: Cl,
  lower: Tl,
  append: El,
  insert: Ol,
  remove: Al,
  clone: Nl,
  datum: Pl,
  on: zl,
  dispatch: Ul,
  [Symbol.iterator]: Wl,
};
var Jl = Kl;
function Yl(e) {
  return typeof e == `string`
    ? new q([[document.querySelector(e)]], [document.documentElement])
    : new q([[e]], Gl);
}
function Xl(e) {
  let t;
  for (; (t = e.sourceEvent); ) e = t;
  return e;
}
function Zl(e, t) {
  if (((e = Xl(e)), t === void 0 && (t = e.currentTarget), t)) {
    var n = t.ownerSVGElement || t;
    if (n.createSVGPoint) {
      var r = n.createSVGPoint();
      return (
        (r.x = e.clientX),
        (r.y = e.clientY),
        (r = r.matrixTransform(t.getScreenCTM().inverse())),
        [r.x, r.y]
      );
    }
    if (t.getBoundingClientRect) {
      var i = t.getBoundingClientRect();
      return [
        e.clientX - i.left - t.clientLeft,
        e.clientY - i.top - t.clientTop,
      ];
    }
  }
  return [e.pageX, e.pageY];
}
const Ql = { capture: !0, passive: !1 };
function $l(e) {
  e.preventDefault(), e.stopImmediatePropagation();
}
function eu(e) {
  var t = e.document.documentElement,
    n = Yl(e).on(`dragstart.drag`, $l, Ql);
  `onselectstart` in t
    ? n.on(`selectstart.drag`, $l, Ql)
    : ((t.__noselect = t.style.MozUserSelect),
      (t.style.MozUserSelect = `none`));
}
function tu(e, t) {
  var n = e.document.documentElement,
    r = Yl(e).on(`dragstart.drag`, null);
  t &&
    (r.on(`click.drag`, $l, Ql),
    setTimeout(function () {
      r.on(`click.drag`, null);
    }, 0)),
    `onselectstart` in n
      ? r.on(`selectstart.drag`, null)
      : ((n.style.MozUserSelect = n.__noselect), delete n.__noselect);
}
function nu(e, t, n) {
  (e.prototype = t.prototype = n), (n.constructor = e);
}
function ru(e, t) {
  var n = Object.create(e.prototype);
  for (var r in t) n[r] = t[r];
  return n;
}
function iu() {}
var au = 0.7,
  ou = 1 / au,
  su = `\\s*([+-]?\\d+)\\s*`,
  cu = `\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*`,
  J = `\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*`,
  lu = /^#([0-9a-f]{3,8})$/,
  uu = RegExp(`^rgb\\(${su},${su},${su}\\)$`),
  du = RegExp(`^rgb\\(${J},${J},${J}\\)$`),
  fu = RegExp(`^rgba\\(${su},${su},${su},${cu}\\)$`),
  pu = RegExp(`^rgba\\(${J},${J},${J},${cu}\\)$`),
  mu = RegExp(`^hsl\\(${cu},${J},${J}\\)$`),
  hu = RegExp(`^hsla\\(${cu},${J},${J},${cu}\\)$`),
  gu = {
    aliceblue: 15792383,
    antiquewhite: 16444375,
    aqua: 65535,
    aquamarine: 8388564,
    azure: 15794175,
    beige: 16119260,
    bisque: 16770244,
    black: 0,
    blanchedalmond: 16772045,
    blue: 255,
    blueviolet: 9055202,
    brown: 10824234,
    burlywood: 14596231,
    cadetblue: 6266528,
    chartreuse: 8388352,
    chocolate: 13789470,
    coral: 16744272,
    cornflowerblue: 6591981,
    cornsilk: 16775388,
    crimson: 14423100,
    cyan: 65535,
    darkblue: 139,
    darkcyan: 35723,
    darkgoldenrod: 12092939,
    darkgray: 11119017,
    darkgreen: 25600,
    darkgrey: 11119017,
    darkkhaki: 12433259,
    darkmagenta: 9109643,
    darkolivegreen: 5597999,
    darkorange: 16747520,
    darkorchid: 10040012,
    darkred: 9109504,
    darksalmon: 15308410,
    darkseagreen: 9419919,
    darkslateblue: 4734347,
    darkslategray: 3100495,
    darkslategrey: 3100495,
    darkturquoise: 52945,
    darkviolet: 9699539,
    deeppink: 16716947,
    deepskyblue: 49151,
    dimgray: 6908265,
    dimgrey: 6908265,
    dodgerblue: 2003199,
    firebrick: 11674146,
    floralwhite: 16775920,
    forestgreen: 2263842,
    fuchsia: 16711935,
    gainsboro: 14474460,
    ghostwhite: 16316671,
    gold: 16766720,
    goldenrod: 14329120,
    gray: 8421504,
    green: 32768,
    greenyellow: 11403055,
    grey: 8421504,
    honeydew: 15794160,
    hotpink: 16738740,
    indianred: 13458524,
    indigo: 4915330,
    ivory: 16777200,
    khaki: 15787660,
    lavender: 15132410,
    lavenderblush: 16773365,
    lawngreen: 8190976,
    lemonchiffon: 16775885,
    lightblue: 11393254,
    lightcoral: 15761536,
    lightcyan: 14745599,
    lightgoldenrodyellow: 16448210,
    lightgray: 13882323,
    lightgreen: 9498256,
    lightgrey: 13882323,
    lightpink: 16758465,
    lightsalmon: 16752762,
    lightseagreen: 2142890,
    lightskyblue: 8900346,
    lightslategray: 7833753,
    lightslategrey: 7833753,
    lightsteelblue: 11584734,
    lightyellow: 16777184,
    lime: 65280,
    limegreen: 3329330,
    linen: 16445670,
    magenta: 16711935,
    maroon: 8388608,
    mediumaquamarine: 6737322,
    mediumblue: 205,
    mediumorchid: 12211667,
    mediumpurple: 9662683,
    mediumseagreen: 3978097,
    mediumslateblue: 8087790,
    mediumspringgreen: 64154,
    mediumturquoise: 4772300,
    mediumvioletred: 13047173,
    midnightblue: 1644912,
    mintcream: 16121850,
    mistyrose: 16770273,
    moccasin: 16770229,
    navajowhite: 16768685,
    navy: 128,
    oldlace: 16643558,
    olive: 8421376,
    olivedrab: 7048739,
    orange: 16753920,
    orangered: 16729344,
    orchid: 14315734,
    palegoldenrod: 15657130,
    palegreen: 10025880,
    paleturquoise: 11529966,
    palevioletred: 14381203,
    papayawhip: 16773077,
    peachpuff: 16767673,
    peru: 13468991,
    pink: 16761035,
    plum: 14524637,
    powderblue: 11591910,
    purple: 8388736,
    rebeccapurple: 6697881,
    red: 16711680,
    rosybrown: 12357519,
    royalblue: 4286945,
    saddlebrown: 9127187,
    salmon: 16416882,
    sandybrown: 16032864,
    seagreen: 3050327,
    seashell: 16774638,
    sienna: 10506797,
    silver: 12632256,
    skyblue: 8900331,
    slateblue: 6970061,
    slategray: 7372944,
    slategrey: 7372944,
    snow: 16775930,
    springgreen: 65407,
    steelblue: 4620980,
    tan: 13808780,
    teal: 32896,
    thistle: 14204888,
    tomato: 16737095,
    turquoise: 4251856,
    violet: 15631086,
    wheat: 16113331,
    white: 16777215,
    whitesmoke: 16119285,
    yellow: 16776960,
    yellowgreen: 10145074,
  };
nu(iu, xu, {
  copy(e) {
    return Object.assign(new this.constructor(), this, e);
  },
  displayable() {
    return this.rgb().displayable();
  },
  hex: _u,
  formatHex: _u,
  formatHex8: vu,
  formatHsl: yu,
  formatRgb: bu,
  toString: bu,
});
function _u() {
  return this.rgb().formatHex();
}
function vu() {
  return this.rgb().formatHex8();
}
function yu() {
  return Nu(this).formatHsl();
}
function bu() {
  return this.rgb().formatRgb();
}
function xu(e) {
  var t, n;
  return (
    (e = (e + ``).trim().toLowerCase()),
    (t = lu.exec(e))
      ? ((n = t[1].length),
        (t = parseInt(t[1], 16)),
        n === 6
          ? Su(t)
          : n === 3
          ? new Y(
              ((t >> 8) & 15) | ((t >> 4) & 240),
              ((t >> 4) & 15) | (t & 240),
              ((t & 15) << 4) | (t & 15),
              1,
            )
          : n === 8
          ? Cu(
              (t >> 24) & 255,
              (t >> 16) & 255,
              (t >> 8) & 255,
              (t & 255) / 255,
            )
          : n === 4
          ? Cu(
              ((t >> 12) & 15) | ((t >> 8) & 240),
              ((t >> 8) & 15) | ((t >> 4) & 240),
              ((t >> 4) & 15) | (t & 240),
              (((t & 15) << 4) | (t & 15)) / 255,
            )
          : null)
      : (t = uu.exec(e))
      ? new Y(t[1], t[2], t[3], 1)
      : (t = du.exec(e))
      ? new Y((t[1] * 255) / 100, (t[2] * 255) / 100, (t[3] * 255) / 100, 1)
      : (t = fu.exec(e))
      ? Cu(t[1], t[2], t[3], t[4])
      : (t = pu.exec(e))
      ? Cu((t[1] * 255) / 100, (t[2] * 255) / 100, (t[3] * 255) / 100, t[4])
      : (t = mu.exec(e))
      ? Mu(t[1], t[2] / 100, t[3] / 100, 1)
      : (t = hu.exec(e))
      ? Mu(t[1], t[2] / 100, t[3] / 100, t[4])
      : gu.hasOwnProperty(e)
      ? Su(gu[e])
      : e === `transparent`
      ? new Y(NaN, NaN, NaN, 0)
      : null
  );
}
function Su(e) {
  return new Y((e >> 16) & 255, (e >> 8) & 255, e & 255, 1);
}
function Cu(e, t, n, r) {
  return r <= 0 && (e = t = n = NaN), new Y(e, t, n, r);
}
function wu(e) {
  return (
    e instanceof iu || (e = xu(e)),
    e ? ((e = e.rgb()), new Y(e.r, e.g, e.b, e.opacity)) : new Y()
  );
}
function Tu(e, t, n, r) {
  return arguments.length === 1 ? wu(e) : new Y(e, t, n, r ?? 1);
}
function Y(e, t, n, r) {
  (this.r = +e), (this.g = +t), (this.b = +n), (this.opacity = +r);
}
nu(
  Y,
  Tu,
  ru(iu, {
    brighter(e) {
      return (
        (e = e == null ? ou : ou ** +e),
        new Y(this.r * e, this.g * e, this.b * e, this.opacity)
      );
    },
    darker(e) {
      return (
        (e = e == null ? au : au ** +e),
        new Y(this.r * e, this.g * e, this.b * e, this.opacity)
      );
    },
    rgb() {
      return this;
    },
    clamp() {
      return new Y(Au(this.r), Au(this.g), Au(this.b), ku(this.opacity));
    },
    displayable() {
      return (
        -0.5 <= this.r &&
        this.r < 255.5 &&
        -0.5 <= this.g &&
        this.g < 255.5 &&
        -0.5 <= this.b &&
        this.b < 255.5 &&
        0 <= this.opacity &&
        this.opacity <= 1
      );
    },
    hex: Eu,
    formatHex: Eu,
    formatHex8: Du,
    formatRgb: Ou,
    toString: Ou,
  }),
);
function Eu() {
  return `#${ju(this.r)}${ju(this.g)}${ju(this.b)}`;
}
function Du() {
  return `#${ju(this.r)}${ju(this.g)}${ju(this.b)}${ju(
    (isNaN(this.opacity) ? 1 : this.opacity) * 255,
  )}`;
}
function Ou() {
  let e = ku(this.opacity);
  return `${e === 1 ? `rgb(` : `rgba(`}${Au(this.r)}, ${Au(this.g)}, ${Au(
    this.b,
  )}${e === 1 ? `)` : `, ${e})`}`;
}
function ku(e) {
  return isNaN(e) ? 1 : Math.max(0, Math.min(1, e));
}
function Au(e) {
  return Math.max(0, Math.min(255, Math.round(e) || 0));
}
function ju(e) {
  return (e = Au(e)), (e < 16 ? `0` : ``) + e.toString(16);
}
function Mu(e, t, n, r) {
  return (
    r <= 0
      ? (e = t = n = NaN)
      : n <= 0 || n >= 1
      ? (e = t = NaN)
      : t <= 0 && (e = NaN),
    new X(e, t, n, r)
  );
}
function Nu(e) {
  if (e instanceof X) return new X(e.h, e.s, e.l, e.opacity);
  if ((e instanceof iu || (e = xu(e)), !e)) return new X();
  if (e instanceof X) return e;
  e = e.rgb();
  var t = e.r / 255,
    n = e.g / 255,
    r = e.b / 255,
    i = Math.min(t, n, r),
    a = Math.max(t, n, r),
    o = NaN,
    s = a - i,
    c = (a + i) / 2;
  return (
    s
      ? ((o =
          t === a
            ? (n - r) / s + (n < r) * 6
            : n === a
            ? (r - t) / s + 2
            : (t - n) / s + 4),
        (s /= c < 0.5 ? a + i : 2 - a - i),
        (o *= 60))
      : (s = c > 0 && c < 1 ? 0 : o),
    new X(o, s, c, e.opacity)
  );
}
function Pu(e, t, n, r) {
  return arguments.length === 1 ? Nu(e) : new X(e, t, n, r ?? 1);
}
function X(e, t, n, r) {
  (this.h = +e), (this.s = +t), (this.l = +n), (this.opacity = +r);
}
nu(
  X,
  Pu,
  ru(iu, {
    brighter(e) {
      return (
        (e = e == null ? ou : ou ** +e),
        new X(this.h, this.s, this.l * e, this.opacity)
      );
    },
    darker(e) {
      return (
        (e = e == null ? au : au ** +e),
        new X(this.h, this.s, this.l * e, this.opacity)
      );
    },
    rgb() {
      var e = (this.h % 360) + (this.h < 0) * 360,
        t = isNaN(e) || isNaN(this.s) ? 0 : this.s,
        n = this.l,
        r = n + (n < 0.5 ? n : 1 - n) * t,
        i = 2 * n - r;
      return new Y(
        Lu(e >= 240 ? e - 240 : e + 120, i, r),
        Lu(e, i, r),
        Lu(e < 120 ? e + 240 : e - 120, i, r),
        this.opacity,
      );
    },
    clamp() {
      return new X(Fu(this.h), Iu(this.s), Iu(this.l), ku(this.opacity));
    },
    displayable() {
      return (
        ((0 <= this.s && this.s <= 1) || isNaN(this.s)) &&
        0 <= this.l &&
        this.l <= 1 &&
        0 <= this.opacity &&
        this.opacity <= 1
      );
    },
    formatHsl() {
      let e = ku(this.opacity);
      return `${e === 1 ? `hsl(` : `hsla(`}${Fu(this.h)}, ${
        Iu(this.s) * 100
      }%, ${Iu(this.l) * 100}%${e === 1 ? `)` : `, ${e})`}`;
    },
  }),
);
function Fu(e) {
  return (e = (e || 0) % 360), e < 0 ? e + 360 : e;
}
function Iu(e) {
  return Math.max(0, Math.min(1, e || 0));
}
function Lu(e, t, n) {
  return (
    (e < 60
      ? t + ((n - t) * e) / 60
      : e < 180
      ? n
      : e < 240
      ? t + ((n - t) * (240 - e)) / 60
      : t) * 255
  );
}
var Ru = (e) => () => e;
function zu(e, t) {
  return function (n) {
    return e + n * t;
  };
}
function Bu(e, t, n) {
  return (
    (e **= +n),
    (t = t ** +n - e),
    (n = 1 / n),
    function (r) {
      return (e + r * t) ** +n;
    }
  );
}
function Vu(e) {
  return (e = +e) == 1
    ? Hu
    : function (t, n) {
        return n - t ? Bu(t, n, e) : Ru(isNaN(t) ? n : t);
      };
}
function Hu(e, t) {
  var n = t - e;
  return n ? zu(e, n) : Ru(isNaN(e) ? t : e);
}
var Uu = (function e(t) {
  var n = Vu(t);
  function r(e, t) {
    var r = n((e = Tu(e)).r, (t = Tu(t)).r),
      i = n(e.g, t.g),
      a = n(e.b, t.b),
      o = Hu(e.opacity, t.opacity);
    return function (t) {
      return (
        (e.r = r(t)), (e.g = i(t)), (e.b = a(t)), (e.opacity = o(t)), e + ``
      );
    };
  }
  return (r.gamma = e), r;
})(1);
function Wu(e, t) {
  return (
    (e = +e),
    (t = +t),
    function (n) {
      return e * (1 - n) + t * n;
    }
  );
}
var Gu = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g,
  Ku = new RegExp(Gu.source, `g`);
function qu(e) {
  return function () {
    return e;
  };
}
function Ju(e) {
  return function (t) {
    return e(t) + ``;
  };
}
function Yu(e, t) {
  var n = (Gu.lastIndex = Ku.lastIndex = 0),
    r,
    i,
    a,
    o = -1,
    s = [],
    c = [];
  for (e += ``, t += ``; (r = Gu.exec(e)) && (i = Ku.exec(t)); )
    (a = i.index) > n &&
      ((a = t.slice(n, a)), s[o] ? (s[o] += a) : (s[++o] = a)),
      (r = r[0]) === (i = i[0])
        ? s[o]
          ? (s[o] += i)
          : (s[++o] = i)
        : ((s[++o] = null), c.push({ i: o, x: Wu(r, i) })),
      (n = Ku.lastIndex);
  return (
    n < t.length && ((a = t.slice(n)), s[o] ? (s[o] += a) : (s[++o] = a)),
    s.length < 2
      ? c[0]
        ? Ju(c[0].x)
        : qu(t)
      : ((t = c.length),
        function (e) {
          for (var n = 0, r; n < t; ++n) s[(r = c[n]).i] = r.x(e);
          return s.join(``);
        })
  );
}
var Xu = 180 / Math.PI,
  Zu = {
    translateX: 0,
    translateY: 0,
    rotate: 0,
    skewX: 0,
    scaleX: 1,
    scaleY: 1,
  };
function Qu(e, t, n, r, i, a) {
  var o, s, c;
  return (
    (o = Math.sqrt(e * e + t * t)) && ((e /= o), (t /= o)),
    (c = e * n + t * r) && ((n -= e * c), (r -= t * c)),
    (s = Math.sqrt(n * n + r * r)) && ((n /= s), (r /= s), (c /= s)),
    e * r < t * n && ((e = -e), (t = -t), (c = -c), (o = -o)),
    {
      translateX: i,
      translateY: a,
      rotate: Math.atan2(t, e) * Xu,
      skewX: Math.atan(c) * Xu,
      scaleX: o,
      scaleY: s,
    }
  );
}
var $u;
function ed(e) {
  let t = new (typeof DOMMatrix == `function` ? DOMMatrix : WebKitCSSMatrix)(
    e + ``,
  );
  return t.isIdentity ? Zu : Qu(t.a, t.b, t.c, t.d, t.e, t.f);
}
function td(e) {
  return e == null ||
    (($u ||= document.createElementNS(`http://www.w3.org/2000/svg`, `g`)),
    $u.setAttribute(`transform`, e),
    !(e = $u.transform.baseVal.consolidate()))
    ? Zu
    : ((e = e.matrix), Qu(e.a, e.b, e.c, e.d, e.e, e.f));
}
function nd(e, t, n, r) {
  function i(e) {
    return e.length ? e.pop() + ` ` : ``;
  }
  function a(e, r, i, a, o, s) {
    if (e !== i || r !== a) {
      var c = o.push(`translate(`, null, t, null, n);
      s.push({ i: c - 4, x: Wu(e, i) }, { i: c - 2, x: Wu(r, a) });
    } else (i || a) && o.push(`translate(` + i + t + a + n);
  }
  function o(e, t, n, a) {
    e === t
      ? t && n.push(i(n) + `rotate(` + t + r)
      : (e - t > 180 ? (t += 360) : t - e > 180 && (e += 360),
        a.push({ i: n.push(i(n) + `rotate(`, null, r) - 2, x: Wu(e, t) }));
  }
  function s(e, t, n, a) {
    e === t
      ? t && n.push(i(n) + `skewX(` + t + r)
      : a.push({ i: n.push(i(n) + `skewX(`, null, r) - 2, x: Wu(e, t) });
  }
  function c(e, t, n, r, a, o) {
    if (e !== n || t !== r) {
      var s = a.push(i(a) + `scale(`, null, `,`, null, `)`);
      o.push({ i: s - 4, x: Wu(e, n) }, { i: s - 2, x: Wu(t, r) });
    } else (n !== 1 || r !== 1) && a.push(i(a) + `scale(` + n + `,` + r + `)`);
  }
  return function (t, n) {
    var r = [],
      i = [];
    return (
      (t = e(t)),
      (n = e(n)),
      a(t.translateX, t.translateY, n.translateX, n.translateY, r, i),
      o(t.rotate, n.rotate, r, i),
      s(t.skewX, n.skewX, r, i),
      c(t.scaleX, t.scaleY, n.scaleX, n.scaleY, r, i),
      (t = n = null),
      function (e) {
        for (var t = -1, n = i.length, a; ++t < n; ) r[(a = i[t]).i] = a.x(e);
        return r.join(``);
      }
    );
  };
}
var rd = nd(ed, `px, `, `px)`, `deg)`),
  id = nd(td, `, `, `)`, `)`),
  ad = 1e-12;
function od(e) {
  return ((e = Math.exp(e)) + 1 / e) / 2;
}
function sd(e) {
  return ((e = Math.exp(e)) - 1 / e) / 2;
}
function cd(e) {
  return ((e = Math.exp(2 * e)) - 1) / (e + 1);
}
var ld = (function e(t, n, r) {
    function i(e, i) {
      var a = e[0],
        o = e[1],
        s = e[2],
        c = i[0],
        l = i[1],
        u = i[2],
        d = c - a,
        f = l - o,
        p = d * d + f * f,
        m,
        h;
      if (p < ad)
        (h = Math.log(u / s) / t),
          (m = function (e) {
            return [a + e * d, o + e * f, s * Math.exp(t * e * h)];
          });
      else {
        var g = Math.sqrt(p),
          _ = (u * u - s * s + r * p) / (2 * s * n * g),
          v = (u * u - s * s - r * p) / (2 * u * n * g),
          y = Math.log(Math.sqrt(_ * _ + 1) - _);
        (h = (Math.log(Math.sqrt(v * v + 1) - v) - y) / t),
          (m = function (e) {
            var r = e * h,
              i = od(y),
              c = (s / (n * g)) * (i * cd(t * r + y) - sd(y));
            return [a + c * d, o + c * f, (s * i) / od(t * r + y)];
          });
      }
      return (m.duration = (h * 1e3 * t) / Math.SQRT2), m;
    }
    return (
      (i.rho = function (t) {
        var n = Math.max(0.001, +t),
          r = n * n;
        return e(n, r, r * r);
      }),
      i
    );
  })(Math.SQRT2, 2, 4),
  ud = 0,
  dd = 0,
  fd = 0,
  pd = 1e3,
  md,
  hd,
  gd = 0,
  _d = 0,
  vd = 0,
  yd = typeof performance == `object` && performance.now ? performance : Date,
  bd =
    typeof window == `object` && window.requestAnimationFrame
      ? window.requestAnimationFrame.bind(window)
      : function (e) {
          setTimeout(e, 17);
        };
function xd() {
  return (_d ||= (bd(Sd), yd.now() + vd));
}
function Sd() {
  _d = 0;
}
function Cd() {
  this._call = this._time = this._next = null;
}
Cd.prototype = wd.prototype = {
  constructor: Cd,
  restart: function (e, t, n) {
    if (typeof e != `function`) throw TypeError(`callback is not a function`);
    (n = (n == null ? xd() : +n) + (t == null ? 0 : +t)),
      !this._next &&
        hd !== this &&
        (hd ? (hd._next = this) : (md = this), (hd = this)),
      (this._call = e),
      (this._time = n),
      kd();
  },
  stop: function () {
    this._call && ((this._call = null), (this._time = 1 / 0), kd());
  },
};
function wd(e, t, n) {
  var r = new Cd();
  return r.restart(e, t, n), r;
}
function Td() {
  xd(), ++ud;
  for (var e = md, t; e; )
    (t = _d - e._time) >= 0 && e._call.call(void 0, t), (e = e._next);
  --ud;
}
function Ed() {
  (_d = (gd = yd.now()) + vd), (ud = dd = 0);
  try {
    Td();
  } finally {
    (ud = 0), Od(), (_d = 0);
  }
}
function Dd() {
  var e = yd.now(),
    t = e - gd;
  t > pd && ((vd -= t), (gd = e));
}
function Od() {
  for (var e, t = md, n, r = 1 / 0; t; )
    t._call
      ? (r > t._time && (r = t._time), (e = t), (t = t._next))
      : ((n = t._next), (t._next = null), (t = e ? (e._next = n) : (md = n)));
  (hd = e), kd(r);
}
function kd(e) {
  ud ||
    ((dd &&= clearTimeout(dd)),
    e - _d > 24
      ? (e < 1 / 0 && (dd = setTimeout(Ed, e - yd.now() - vd)),
        (fd &&= clearInterval(fd)))
      : ((fd ||= ((gd = yd.now()), setInterval(Dd, pd))), (ud = 1), bd(Ed)));
}
function Ad(e, t, n) {
  var r = new Cd();
  return (
    (t = t == null ? 0 : +t),
    r.restart(
      (n) => {
        r.stop(), e(n + t);
      },
      t,
      n,
    ),
    r
  );
}
var jd = Xs(`start`, `end`, `cancel`, `interrupt`),
  Md = [];
function Nd(e, t, n, r, i, a) {
  var o = e.__transition;
  if (!o) e.__transition = {};
  else if (n in o) return;
  Fd(e, n, {
    name: t,
    index: r,
    group: i,
    on: jd,
    tween: Md,
    time: a.time,
    delay: a.delay,
    duration: a.duration,
    ease: a.ease,
    timer: null,
    state: 0,
  });
}
function Pd(e, t) {
  var n = Q(e, t);
  if (n.state > 0) throw Error(`too late; already scheduled`);
  return n;
}
function Z(e, t) {
  var n = Q(e, t);
  if (n.state > 3) throw Error(`too late; already running`);
  return n;
}
function Q(e, t) {
  var n = e.__transition;
  if (!n || !(n = n[t])) throw Error(`transition not found`);
  return n;
}
function Fd(e, t, n) {
  var r = e.__transition,
    i;
  (r[t] = n), (n.timer = wd(a, 0, n.time));
  function a(e) {
    (n.state = 1),
      n.timer.restart(o, n.delay, n.time),
      n.delay <= e && o(e - n.delay);
  }
  function o(a) {
    var l, u, d, f;
    if (n.state !== 1) return c();
    for (l in r)
      if (((f = r[l]), f.name === n.name)) {
        if (f.state === 3) return Ad(o);
        f.state === 4
          ? ((f.state = 6),
            f.timer.stop(),
            f.on.call(`interrupt`, e, e.__data__, f.index, f.group),
            delete r[l])
          : +l < t &&
            ((f.state = 6),
            f.timer.stop(),
            f.on.call(`cancel`, e, e.__data__, f.index, f.group),
            delete r[l]);
      }
    if (
      (Ad(function () {
        n.state === 3 &&
          ((n.state = 4), n.timer.restart(s, n.delay, n.time), s(a));
      }),
      (n.state = 2),
      n.on.call(`start`, e, e.__data__, n.index, n.group),
      n.state === 2)
    ) {
      for (
        n.state = 3, i = Array((d = n.tween.length)), l = 0, u = -1;
        l < d;
        ++l
      )
        (f = n.tween[l].value.call(e, e.__data__, n.index, n.group)) &&
          (i[++u] = f);
      i.length = u + 1;
    }
  }
  function s(t) {
    for (
      var r =
          t < n.duration
            ? n.ease.call(null, t / n.duration)
            : (n.timer.restart(c), (n.state = 5), 1),
        a = -1,
        o = i.length;
      ++a < o;

    )
      i[a].call(e, r);
    n.state === 5 && (n.on.call(`end`, e, e.__data__, n.index, n.group), c());
  }
  function c() {
    for (var i in ((n.state = 6), n.timer.stop(), delete r[t], r)) return;
    delete e.__transition;
  }
}
function Id(e, t) {
  var n = e.__transition,
    r,
    i,
    a = !0,
    o;
  if (n) {
    for (o in ((t = t == null ? null : t + ``), n)) {
      if ((r = n[o]).name !== t) {
        a = !1;
        continue;
      }
      (i = r.state > 2 && r.state < 5),
        (r.state = 6),
        r.timer.stop(),
        r.on.call(i ? `interrupt` : `cancel`, e, e.__data__, r.index, r.group),
        delete n[o];
    }
    a && delete e.__transition;
  }
}
function Ld(e) {
  return this.each(function () {
    Id(this, e);
  });
}
function Rd(e, t) {
  var n, r;
  return function () {
    var i = Z(this, e),
      a = i.tween;
    if (a !== n) {
      r = n = a;
      for (var o = 0, s = r.length; o < s; ++o)
        if (r[o].name === t) {
          (r = r.slice()), r.splice(o, 1);
          break;
        }
    }
    i.tween = r;
  };
}
function zd(e, t, n) {
  var r, i;
  if (typeof n != `function`) throw Error();
  return function () {
    var a = Z(this, e),
      o = a.tween;
    if (o !== r) {
      i = (r = o).slice();
      for (var s = { name: t, value: n }, c = 0, l = i.length; c < l; ++c)
        if (i[c].name === t) {
          i[c] = s;
          break;
        }
      c === l && i.push(s);
    }
    a.tween = i;
  };
}
function Bd(e, t) {
  var n = this._id;
  if (((e += ``), arguments.length < 2)) {
    for (var r = Q(this.node(), n).tween, i = 0, a = r.length, o; i < a; ++i)
      if ((o = r[i]).name === e) return o.value;
    return null;
  }
  return this.each((t == null ? Rd : zd)(n, e, t));
}
function Vd(e, t, n) {
  var r = e._id;
  return (
    e.each(function () {
      var e = Z(this, r);
      (e.value ||= {})[t] = n.apply(this, arguments);
    }),
    function (e) {
      return Q(e, r).value[t];
    }
  );
}
function Hd(e, t) {
  var n;
  return (
    typeof t == `number`
      ? Wu
      : t instanceof xu
      ? Uu
      : (n = xu(t))
      ? ((t = n), Uu)
      : Yu
  )(e, t);
}
function Ud(e) {
  return function () {
    this.removeAttribute(e);
  };
}
function Wd(e) {
  return function () {
    this.removeAttributeNS(e.space, e.local);
  };
}
function Gd(e, t, n) {
  var r,
    i = n + ``,
    a;
  return function () {
    var o = this.getAttribute(e);
    return o === i ? null : o === r ? a : (a = t((r = o), n));
  };
}
function Kd(e, t, n) {
  var r,
    i = n + ``,
    a;
  return function () {
    var o = this.getAttributeNS(e.space, e.local);
    return o === i ? null : o === r ? a : (a = t((r = o), n));
  };
}
function qd(e, t, n) {
  var r, i, a;
  return function () {
    var o,
      s = n(this),
      c;
    return s == null
      ? void this.removeAttribute(e)
      : ((o = this.getAttribute(e)),
        (c = s + ``),
        o === c
          ? null
          : o === r && c === i
          ? a
          : ((i = c), (a = t((r = o), s))));
  };
}
function Jd(e, t, n) {
  var r, i, a;
  return function () {
    var o,
      s = n(this),
      c;
    return s == null
      ? void this.removeAttributeNS(e.space, e.local)
      : ((o = this.getAttributeNS(e.space, e.local)),
        (c = s + ``),
        o === c
          ? null
          : o === r && c === i
          ? a
          : ((i = c), (a = t((r = o), s))));
  };
}
function Yd(e, t) {
  var n = Qs(e),
    r = n === `transform` ? id : Hd;
  return this.attrTween(
    e,
    typeof t == `function`
      ? (n.local ? Jd : qd)(n, r, Vd(this, `attr.` + e, t))
      : t == null
      ? (n.local ? Wd : Ud)(n)
      : (n.local ? Kd : Gd)(n, r, t),
  );
}
function Xd(e, t) {
  return function (n) {
    this.setAttribute(e, t.call(this, n));
  };
}
function Zd(e, t) {
  return function (n) {
    this.setAttributeNS(e.space, e.local, t.call(this, n));
  };
}
function Qd(e, t) {
  var n, r;
  function i() {
    var i = t.apply(this, arguments);
    return i !== r && (n = (r = i) && Zd(e, i)), n;
  }
  return (i._value = t), i;
}
function $d(e, t) {
  var n, r;
  function i() {
    var i = t.apply(this, arguments);
    return i !== r && (n = (r = i) && Xd(e, i)), n;
  }
  return (i._value = t), i;
}
function ef(e, t) {
  var n = `attr.` + e;
  if (arguments.length < 2) return (n = this.tween(n)) && n._value;
  if (t == null) return this.tween(n, null);
  if (typeof t != `function`) throw Error();
  var r = Qs(e);
  return this.tween(n, (r.local ? Qd : $d)(r, t));
}
function tf(e, t) {
  return function () {
    Pd(this, e).delay = +t.apply(this, arguments);
  };
}
function nf(e, t) {
  return (
    (t = +t),
    function () {
      Pd(this, e).delay = t;
    }
  );
}
function rf(e) {
  var t = this._id;
  return arguments.length
    ? this.each((typeof e == `function` ? tf : nf)(t, e))
    : Q(this.node(), t).delay;
}
function af(e, t) {
  return function () {
    Z(this, e).duration = +t.apply(this, arguments);
  };
}
function of(e, t) {
  return (
    (t = +t),
    function () {
      Z(this, e).duration = t;
    }
  );
}
function sf(e) {
  var t = this._id;
  return arguments.length
    ? this.each((typeof e == `function` ? af : of)(t, e))
    : Q(this.node(), t).duration;
}
function cf(e, t) {
  if (typeof t != `function`) throw Error();
  return function () {
    Z(this, e).ease = t;
  };
}
function lf(e) {
  var t = this._id;
  return arguments.length ? this.each(cf(t, e)) : Q(this.node(), t).ease;
}
function uf(e, t) {
  return function () {
    var n = t.apply(this, arguments);
    if (typeof n != `function`) throw Error();
    Z(this, e).ease = n;
  };
}
function df(e) {
  if (typeof e != `function`) throw Error();
  return this.each(uf(this._id, e));
}
function ff(e) {
  typeof e != `function` && (e = uc(e));
  for (var t = this._groups, n = t.length, r = Array(n), i = 0; i < n; ++i)
    for (var a = t[i], o = a.length, s = (r[i] = []), c, l = 0; l < o; ++l)
      (c = a[l]) && e.call(c, c.__data__, l, a) && s.push(c);
  return new Vf(r, this._parents, this._name, this._id);
}
function pf(e) {
  if (e._id !== this._id) throw Error();
  for (
    var t = this._groups,
      n = e._groups,
      r = t.length,
      i = n.length,
      a = Math.min(r, i),
      o = Array(r),
      s = 0;
    s < a;
    ++s
  )
    for (
      var c = t[s], l = n[s], u = c.length, d = (o[s] = Array(u)), f, p = 0;
      p < u;
      ++p
    )
      (f = c[p] || l[p]) && (d[p] = f);
  for (; s < r; ++s) o[s] = t[s];
  return new Vf(o, this._parents, this._name, this._id);
}
function mf(e) {
  return (e + ``)
    .trim()
    .split(/^|\s+/)
    .every(function (e) {
      var t = e.indexOf(`.`);
      return t >= 0 && (e = e.slice(0, t)), !e || e === `start`;
    });
}
function hf(e, t, n) {
  var r,
    i,
    a = mf(t) ? Pd : Z;
  return function () {
    var o = a(this, e),
      s = o.on;
    s !== r && (i = (r = s).copy()).on(t, n), (o.on = i);
  };
}
function gf(e, t) {
  var n = this._id;
  return arguments.length < 2
    ? Q(this.node(), n).on.on(e)
    : this.each(hf(n, e, t));
}
function _f(e) {
  return function () {
    var t = this.parentNode;
    for (var n in this.__transition) if (+n !== e) return;
    t && t.removeChild(this);
  };
}
function vf() {
  return this.on(`end.remove`, _f(this._id));
}
function yf(e) {
  var t = this._name,
    n = this._id;
  typeof e != `function` && (e = rc(e));
  for (var r = this._groups, i = r.length, a = Array(i), o = 0; o < i; ++o)
    for (
      var s = r[o], c = s.length, l = (a[o] = Array(c)), u, d, f = 0;
      f < c;
      ++f
    )
      (u = s[f]) &&
        (d = e.call(u, u.__data__, f, s)) &&
        (`__data__` in u && (d.__data__ = u.__data__),
        (l[f] = d),
        Nd(l[f], t, n, f, l, Q(u, n)));
  return new Vf(a, this._parents, t, n);
}
function bf(e) {
  var t = this._name,
    n = this._id;
  typeof e != `function` && (e = sc(e));
  for (var r = this._groups, i = r.length, a = [], o = [], s = 0; s < i; ++s)
    for (var c = r[s], l = c.length, u, d = 0; d < l; ++d)
      if ((u = c[d])) {
        for (
          var f = e.call(u, u.__data__, d, c),
            p,
            m = Q(u, n),
            h = 0,
            g = f.length;
          h < g;
          ++h
        )
          (p = f[h]) && Nd(p, t, n, h, f, m);
        a.push(f), o.push(u);
      }
  return new Vf(a, o, t, n);
}
var xf = Jl.prototype.constructor;
function Sf() {
  return new xf(this._groups, this._parents);
}
function Cf(e, t) {
  var n, r, i;
  return function () {
    var a = el(this, e),
      o = (this.style.removeProperty(e), el(this, e));
    return a === o ? null : a === n && o === r ? i : (i = t((n = a), (r = o)));
  };
}
function wf(e) {
  return function () {
    this.style.removeProperty(e);
  };
}
function Tf(e, t, n) {
  var r,
    i = n + ``,
    a;
  return function () {
    var o = el(this, e);
    return o === i ? null : o === r ? a : (a = t((r = o), n));
  };
}
function Ef(e, t, n) {
  var r, i, a;
  return function () {
    var o = el(this, e),
      s = n(this),
      c = s + ``;
    return (
      s ?? (c = s = (this.style.removeProperty(e), el(this, e))),
      o === c ? null : o === r && c === i ? a : ((i = c), (a = t((r = o), s)))
    );
  };
}
function Df(e, t) {
  var n,
    r,
    i,
    a = `style.` + t,
    o = `end.` + a,
    s;
  return function () {
    var c = Z(this, e),
      l = c.on,
      u = c.value[a] == null ? (s ||= wf(t)) : void 0;
    (l !== n || i !== u) && (r = (n = l).copy()).on(o, (i = u)), (c.on = r);
  };
}
function Of(e, t, n) {
  var r = (e += ``) == `transform` ? rd : Hd;
  return t == null
    ? this.styleTween(e, Cf(e, r)).on(`end.style.` + e, wf(e))
    : typeof t == `function`
    ? this.styleTween(e, Ef(e, r, Vd(this, `style.` + e, t))).each(
        Df(this._id, e),
      )
    : this.styleTween(e, Tf(e, r, t), n).on(`end.style.` + e, null);
}
function kf(e, t, n) {
  return function (r) {
    this.style.setProperty(e, t.call(this, r), n);
  };
}
function Af(e, t, n) {
  var r, i;
  function a() {
    var a = t.apply(this, arguments);
    return a !== i && (r = (i = a) && kf(e, a, n)), r;
  }
  return (a._value = t), a;
}
function jf(e, t, n) {
  var r = `style.` + (e += ``);
  if (arguments.length < 2) return (r = this.tween(r)) && r._value;
  if (t == null) return this.tween(r, null);
  if (typeof t != `function`) throw Error();
  return this.tween(r, Af(e, t, n ?? ``));
}
function Mf(e) {
  return function () {
    this.textContent = e;
  };
}
function Nf(e) {
  return function () {
    this.textContent = e(this) ?? ``;
  };
}
function Pf(e) {
  return this.tween(
    `text`,
    typeof e == `function`
      ? Nf(Vd(this, `text`, e))
      : Mf(e == null ? `` : e + ``),
  );
}
function Ff(e) {
  return function (t) {
    this.textContent = e.call(this, t);
  };
}
function If(e) {
  var t, n;
  function r() {
    var r = e.apply(this, arguments);
    return r !== n && (t = (n = r) && Ff(r)), t;
  }
  return (r._value = e), r;
}
function Lf(e) {
  var t = `text`;
  if (arguments.length < 1) return (t = this.tween(t)) && t._value;
  if (e == null) return this.tween(t, null);
  if (typeof e != `function`) throw Error();
  return this.tween(t, If(e));
}
function Rf() {
  for (
    var e = this._name,
      t = this._id,
      n = Uf(),
      r = this._groups,
      i = r.length,
      a = 0;
    a < i;
    ++a
  )
    for (var o = r[a], s = o.length, c, l = 0; l < s; ++l)
      if ((c = o[l])) {
        var u = Q(c, t);
        Nd(c, e, n, l, o, {
          time: u.time + u.delay + u.duration,
          delay: 0,
          duration: u.duration,
          ease: u.ease,
        });
      }
  return new Vf(r, this._parents, e, n);
}
function zf() {
  var e,
    t,
    n = this,
    r = n._id,
    i = n.size();
  return new Promise(function (a, o) {
    var s = { value: o },
      c = {
        value: function () {
          --i === 0 && a();
        },
      };
    n.each(function () {
      var n = Z(this, r),
        i = n.on;
      i !== e &&
        ((t = (e = i).copy()),
        t._.cancel.push(s),
        t._.interrupt.push(s),
        t._.end.push(c)),
        (n.on = t);
    }),
      i === 0 && a();
  });
}
var Bf = 0;
function Vf(e, t, n, r) {
  (this._groups = e), (this._parents = t), (this._name = n), (this._id = r);
}
function Hf(e) {
  return Jl().transition(e);
}
function Uf() {
  return ++Bf;
}
var Wf = Jl.prototype;
Vf.prototype = Hf.prototype = {
  constructor: Vf,
  select: yf,
  selectAll: bf,
  selectChild: Wf.selectChild,
  selectChildren: Wf.selectChildren,
  filter: ff,
  merge: pf,
  selection: Sf,
  transition: Rf,
  call: Wf.call,
  nodes: Wf.nodes,
  node: Wf.node,
  size: Wf.size,
  empty: Wf.empty,
  each: Wf.each,
  on: gf,
  attr: Yd,
  attrTween: ef,
  style: Of,
  styleTween: jf,
  text: Pf,
  textTween: Lf,
  remove: vf,
  tween: Bd,
  delay: rf,
  duration: sf,
  ease: lf,
  easeVarying: df,
  end: zf,
  [Symbol.iterator]: Wf[Symbol.iterator],
};
function Gf(e) {
  return ((e *= 2) <= 1 ? e * e * e : (e -= 2) * e * e + 2) / 2;
}
var Kf = { time: null, delay: 0, duration: 250, ease: Gf };
function qf(e, t) {
  for (var n; !(n = e.__transition) || !(n = n[t]); )
    if (!(e = e.parentNode)) throw Error(`transition ${t} not found`);
  return n;
}
function Jf(e) {
  var t, n;
  e instanceof Vf
    ? ((t = e._id), (e = e._name))
    : ((t = Uf()), ((n = Kf).time = xd()), (e = e == null ? null : e + ``));
  for (var r = this._groups, i = r.length, a = 0; a < i; ++a)
    for (var o = r[a], s = o.length, c, l = 0; l < s; ++l)
      (c = o[l]) && Nd(c, e, t, l, o, n || qf(c, t));
  return new Vf(r, this._parents, e, t);
}
(Jl.prototype.interrupt = Ld), (Jl.prototype.transition = Jf);
var { abs: Yf, max: Xf, min: Zf } = Math;
[`w`, `e`].map(Qf),
  [`n`, `s`].map(Qf),
  [`n`, `w`, `e`, `s`, `nw`, `ne`, `sw`, `se`].map(Qf);
function Qf(e) {
  return { type: e };
}
var $f = Math.PI,
  ep = 2 * $f,
  tp = 1e-6,
  np = ep - tp;
function rp(e) {
  this._ += e[0];
  for (let t = 1, n = e.length; t < n; ++t) this._ += arguments[t] + e[t];
}
function ip(e) {
  let t = Math.floor(e);
  if (!(t >= 0)) throw Error(`invalid digits: ${e}`);
  if (t > 15) return rp;
  let n = 10 ** t;
  return function (e) {
    this._ += e[0];
    for (let t = 1, r = e.length; t < r; ++t)
      this._ += Math.round(arguments[t] * n) / n + e[t];
  };
}
var ap = class {
  constructor(e) {
    (this._x0 = this._y0 = this._x1 = this._y1 = null),
      (this._ = ``),
      (this._append = e == null ? rp : ip(e));
  }
  moveTo(e, t) {
    this._append`M${(this._x0 = this._x1 = +e)},${(this._y0 = this._y1 = +t)}`;
  }
  closePath() {
    this._x1 !== null &&
      ((this._x1 = this._x0), (this._y1 = this._y0), this._append`Z`);
  }
  lineTo(e, t) {
    this._append`L${(this._x1 = +e)},${(this._y1 = +t)}`;
  }
  quadraticCurveTo(e, t, n, r) {
    this._append`Q${+e},${+t},${(this._x1 = +n)},${(this._y1 = +r)}`;
  }
  bezierCurveTo(e, t, n, r, i, a) {
    this._append`C${+e},${+t},${+n},${+r},${(this._x1 = +i)},${(this._y1 =
      +a)}`;
  }
  arcTo(e, t, n, r, i) {
    if (((e = +e), (t = +t), (n = +n), (r = +r), (i = +i), i < 0))
      throw Error(`negative radius: ${i}`);
    let a = this._x1,
      o = this._y1,
      s = n - e,
      c = r - t,
      l = a - e,
      u = o - t,
      d = l * l + u * u;
    if (this._x1 === null) this._append`M${(this._x1 = e)},${(this._y1 = t)}`;
    else if (d > tp)
      if (!(Math.abs(u * s - c * l) > tp) || !i)
        this._append`L${(this._x1 = e)},${(this._y1 = t)}`;
      else {
        let f = n - a,
          p = r - o,
          m = s * s + c * c,
          h = f * f + p * p,
          g = Math.sqrt(m),
          _ = Math.sqrt(d),
          v = i * Math.tan(($f - Math.acos((m + d - h) / (2 * g * _))) / 2),
          y = v / _,
          b = v / g;
        Math.abs(y - 1) > tp && this._append`L${e + y * l},${t + y * u}`,
          this._append`A${i},${i},0,0,${+(u * f > l * p)},${(this._x1 =
            e + b * s)},${(this._y1 = t + b * c)}`;
      }
  }
  arc(e, t, n, r, i, a) {
    if (((e = +e), (t = +t), (n = +n), (a = !!a), n < 0))
      throw Error(`negative radius: ${n}`);
    let o = n * Math.cos(r),
      s = n * Math.sin(r),
      c = e + o,
      l = t + s,
      u = 1 ^ a,
      d = a ? r - i : i - r;
    this._x1 === null
      ? this._append`M${c},${l}`
      : (Math.abs(this._x1 - c) > tp || Math.abs(this._y1 - l) > tp) &&
        this._append`L${c},${l}`,
      n &&
        (d < 0 && (d = (d % ep) + ep),
        d > np
          ? this._append`A${n},${n},0,1,${u},${e - o},${
              t - s
            }A${n},${n},0,1,${u},${(this._x1 = c)},${(this._y1 = l)}`
          : d > tp &&
            this._append`A${n},${n},0,${+(d >= $f)},${u},${(this._x1 =
              e + n * Math.cos(i))},${(this._y1 = t + n * Math.sin(i))}`);
  }
  rect(e, t, n, r) {
    this._append`M${(this._x0 = this._x1 = +e)},${(this._y0 = this._y1 =
      +t)}h${(n = +n)}v${+r}h${-n}Z`;
  }
  toString() {
    return this._;
  }
};
function op() {
  return new ap();
}
op.prototype = ap.prototype;
function sp(e) {
  var t = 0,
    n = e.children,
    r = n && n.length;
  if (!r) t = 1;
  else for (; --r >= 0; ) t += n[r].value;
  e.value = t;
}
function cp() {
  return this.eachAfter(sp);
}
function lp(e, t) {
  let n = -1;
  for (let r of this) e.call(t, r, ++n, this);
  return this;
}
function up(e, t) {
  for (var n = this, r = [n], i, a, o = -1; (n = r.pop()); )
    if ((e.call(t, n, ++o, this), (i = n.children)))
      for (a = i.length - 1; a >= 0; --a) r.push(i[a]);
  return this;
}
function dp(e, t) {
  for (var n = this, r = [n], i = [], a, o, s, c = -1; (n = r.pop()); )
    if ((i.push(n), (a = n.children)))
      for (o = 0, s = a.length; o < s; ++o) r.push(a[o]);
  for (; (n = i.pop()); ) e.call(t, n, ++c, this);
  return this;
}
function fp(e, t) {
  let n = -1;
  for (let r of this) if (e.call(t, r, ++n, this)) return r;
}
function pp(e) {
  return this.eachAfter(function (t) {
    for (var n = +e(t.data) || 0, r = t.children, i = r && r.length; --i >= 0; )
      n += r[i].value;
    t.value = n;
  });
}
function mp(e) {
  return this.eachBefore(function (t) {
    t.children && t.children.sort(e);
  });
}
function hp(e) {
  for (var t = this, n = gp(t, e), r = [t]; t !== n; )
    (t = t.parent), r.push(t);
  for (var i = r.length; e !== n; ) r.splice(i, 0, e), (e = e.parent);
  return r;
}
function gp(e, t) {
  if (e === t) return e;
  var n = e.ancestors(),
    r = t.ancestors(),
    i = null;
  for (e = n.pop(), t = r.pop(); e === t; )
    (i = e), (e = n.pop()), (t = r.pop());
  return i;
}
function _p() {
  for (var e = this, t = [e]; (e = e.parent); ) t.push(e);
  return t;
}
function vp() {
  return Array.from(this);
}
function yp() {
  var e = [];
  return (
    this.eachBefore(function (t) {
      t.children || e.push(t);
    }),
    e
  );
}
function bp() {
  var e = this,
    t = [];
  return (
    e.each(function (n) {
      n !== e && t.push({ source: n.parent, target: n });
    }),
    t
  );
}
function* xp() {
  var e = this,
    t,
    n = [e],
    r,
    i,
    a;
  do
    for (t = n.reverse(), n = []; (e = t.pop()); )
      if ((yield e, (r = e.children)))
        for (i = 0, a = r.length; i < a; ++i) n.push(r[i]);
  while (n.length);
}
function Sp(e, t) {
  e instanceof Map
    ? ((e = [void 0, e]), t === void 0 && (t = Tp))
    : t === void 0 && (t = wp);
  for (var n = new Op(e), r, i = [n], a, o, s, c; (r = i.pop()); )
    if ((o = t(r.data)) && (c = (o = Array.from(o)).length))
      for (r.children = o, s = c - 1; s >= 0; --s)
        i.push((a = o[s] = new Op(o[s]))),
          (a.parent = r),
          (a.depth = r.depth + 1);
  return n.eachBefore(Dp);
}
function Cp() {
  return Sp(this).eachBefore(Ep);
}
function wp(e) {
  return e.children;
}
function Tp(e) {
  return Array.isArray(e) ? e[1] : null;
}
function Ep(e) {
  e.data.value !== void 0 && (e.value = e.data.value), (e.data = e.data.data);
}
function Dp(e) {
  var t = 0;
  do e.height = t;
  while ((e = e.parent) && e.height < ++t);
}
function Op(e) {
  (this.data = e), (this.depth = this.height = 0), (this.parent = null);
}
Op.prototype = Sp.prototype = {
  constructor: Op,
  count: cp,
  each: lp,
  eachAfter: dp,
  eachBefore: up,
  find: fp,
  sum: pp,
  sort: mp,
  path: hp,
  ancestors: _p,
  descendants: vp,
  leaves: yp,
  links: bp,
  copy: Cp,
  [Symbol.iterator]: xp,
};
function kp(e, t) {
  return e.parent === t.parent ? 1 : 2;
}
function Ap(e) {
  var t = e.children;
  return t ? t[0] : e.t;
}
function jp(e) {
  var t = e.children;
  return t ? t[t.length - 1] : e.t;
}
function Mp(e, t, n) {
  var r = n / (t.i - e.i);
  (t.c -= r), (t.s += n), (e.c += r), (t.z += n), (t.m += n);
}
function Np(e) {
  for (var t = 0, n = 0, r = e.children, i = r.length, a; --i >= 0; )
    (a = r[i]), (a.z += t), (a.m += t), (t += a.s + (n += a.c));
}
function Pp(e, t, n) {
  return e.a.parent === t.parent ? e.a : n;
}
function Fp(e, t) {
  (this._ = e),
    (this.parent = null),
    (this.children = null),
    (this.A = null),
    (this.a = this),
    (this.z = 0),
    (this.m = 0),
    (this.c = 0),
    (this.s = 0),
    (this.t = null),
    (this.i = t);
}
Fp.prototype = Object.create(Op.prototype);
function Ip(e) {
  for (var t = new Fp(e, 0), n, r = [t], i, a, o, s; (n = r.pop()); )
    if ((a = n._.children))
      for (n.children = Array((s = a.length)), o = s - 1; o >= 0; --o)
        r.push((i = n.children[o] = new Fp(a[o], o))), (i.parent = n);
  return ((t.parent = new Fp(null, 0)).children = [t]), t;
}
function Lp() {
  var e = kp,
    t = 1,
    n = 1,
    r = null;
  function i(i) {
    var s = Ip(i);
    if ((s.eachAfter(a), (s.parent.m = -s.z), s.eachBefore(o), r))
      i.eachBefore(c);
    else {
      var l = i,
        u = i,
        d = i;
      i.eachBefore(function (e) {
        e.x < l.x && (l = e),
          e.x > u.x && (u = e),
          e.depth > d.depth && (d = e);
      });
      var f = l === u ? 1 : e(l, u) / 2,
        p = f - l.x,
        m = t / (u.x + f + p),
        h = n / (d.depth || 1);
      i.eachBefore(function (e) {
        (e.x = (e.x + p) * m), (e.y = e.depth * h);
      });
    }
    return i;
  }
  function a(t) {
    var n = t.children,
      r = t.parent.children,
      i = t.i ? r[t.i - 1] : null;
    if (n) {
      Np(t);
      var a = (n[0].z + n[n.length - 1].z) / 2;
      i ? ((t.z = i.z + e(t._, i._)), (t.m = t.z - a)) : (t.z = a);
    } else i && (t.z = i.z + e(t._, i._));
    t.parent.A = s(t, i, t.parent.A || r[0]);
  }
  function o(e) {
    (e._.x = e.z + e.parent.m), (e.m += e.parent.m);
  }
  function s(t, n, r) {
    if (n) {
      for (
        var i = t,
          a = t,
          o = n,
          s = i.parent.children[0],
          c = i.m,
          l = a.m,
          u = o.m,
          d = s.m,
          f;
        (o = jp(o)), (i = Ap(i)), o && i;

      )
        (s = Ap(s)),
          (a = jp(a)),
          (a.a = t),
          (f = o.z + u - i.z - c + e(o._, i._)),
          f > 0 && (Mp(Pp(o, t, r), t, f), (c += f), (l += f)),
          (u += o.m),
          (c += i.m),
          (d += s.m),
          (l += a.m);
      o && !jp(a) && ((a.t = o), (a.m += u - l)),
        i && !Ap(s) && ((s.t = i), (s.m += c - d), (r = t));
    }
    return r;
  }
  function c(e) {
    (e.x *= t), (e.y = e.depth * n);
  }
  return (
    (i.separation = function (t) {
      return arguments.length ? ((e = t), i) : e;
    }),
    (i.size = function (e) {
      return arguments.length
        ? ((r = !1), (t = +e[0]), (n = +e[1]), i)
        : r
        ? null
        : [t, n];
    }),
    (i.nodeSize = function (e) {
      return arguments.length
        ? ((r = !0), (t = +e[0]), (n = +e[1]), i)
        : r
        ? [t, n]
        : null;
    }),
    i
  );
}
function Rp(e) {
  return function () {
    return e;
  };
}
function zp(e) {
  let t = 3;
  return (
    (e.digits = function (n) {
      if (!arguments.length) return t;
      if (n == null) t = null;
      else {
        let e = Math.floor(n);
        if (!(e >= 0)) throw RangeError(`invalid digits: ${n}`);
        t = e;
      }
      return e;
    }),
    () => new ap(t)
  );
}
var Bp = Array.prototype.slice;
function Vp(e) {
  return e[0];
}
function Hp(e) {
  return e[1];
}
var Up = class {
  constructor(e, t) {
    (this._context = e), (this._x = t);
  }
  areaStart() {
    this._line = 0;
  }
  areaEnd() {
    this._line = NaN;
  }
  lineStart() {
    this._point = 0;
  }
  lineEnd() {
    (this._line || (this._line !== 0 && this._point === 1)) &&
      this._context.closePath(),
      (this._line = 1 - this._line);
  }
  point(e, t) {
    switch (((e = +e), (t = +t), this._point)) {
      case 0:
        (this._point = 1),
          this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      default:
        this._x
          ? this._context.bezierCurveTo(
              (this._x0 = (this._x0 + e) / 2),
              this._y0,
              this._x0,
              t,
              e,
              t,
            )
          : this._context.bezierCurveTo(
              this._x0,
              (this._y0 = (this._y0 + t) / 2),
              e,
              this._y0,
              e,
              t,
            );
        break;
    }
    (this._x0 = e), (this._y0 = t);
  }
};
function Wp(e) {
  return new Up(e, !0);
}
function Gp(e) {
  return e.source;
}
function Kp(e) {
  return e.target;
}
function qp(e) {
  let t = Gp,
    n = Kp,
    r = Vp,
    i = Hp,
    a = null,
    o = null,
    s = zp(c);
  function c() {
    let c,
      l = Bp.call(arguments),
      u = t.apply(this, l),
      d = n.apply(this, l);
    if (
      (a ?? (o = e((c = s()))),
      o.lineStart(),
      (l[0] = u),
      o.point(+r.apply(this, l), +i.apply(this, l)),
      (l[0] = d),
      o.point(+r.apply(this, l), +i.apply(this, l)),
      o.lineEnd(),
      c)
    )
      return (o = null), c + `` || null;
  }
  return (
    (c.source = function (e) {
      return arguments.length ? ((t = e), c) : t;
    }),
    (c.target = function (e) {
      return arguments.length ? ((n = e), c) : n;
    }),
    (c.x = function (e) {
      return arguments.length
        ? ((r = typeof e == `function` ? e : Rp(+e)), c)
        : r;
    }),
    (c.y = function (e) {
      return arguments.length
        ? ((i = typeof e == `function` ? e : Rp(+e)), c)
        : i;
    }),
    (c.context = function (t) {
      return arguments.length
        ? (t == null ? (a = o = null) : (o = e((a = t))), c)
        : a;
    }),
    c
  );
}
function Jp() {
  return qp(Wp);
}
var Yp = (e) => () => e;
function Xp(e, { sourceEvent: t, target: n, transform: r, dispatch: i }) {
  Object.defineProperties(this, {
    type: { value: e, enumerable: !0, configurable: !0 },
    sourceEvent: { value: t, enumerable: !0, configurable: !0 },
    target: { value: n, enumerable: !0, configurable: !0 },
    transform: { value: r, enumerable: !0, configurable: !0 },
    _: { value: i },
  });
}
function Zp(e, t, n) {
  (this.k = e), (this.x = t), (this.y = n);
}
Zp.prototype = {
  constructor: Zp,
  scale: function (e) {
    return e === 1 ? this : new Zp(this.k * e, this.x, this.y);
  },
  translate: function (e, t) {
    return (e === 0) & (t === 0)
      ? this
      : new Zp(this.k, this.x + this.k * e, this.y + this.k * t);
  },
  apply: function (e) {
    return [e[0] * this.k + this.x, e[1] * this.k + this.y];
  },
  applyX: function (e) {
    return e * this.k + this.x;
  },
  applyY: function (e) {
    return e * this.k + this.y;
  },
  invert: function (e) {
    return [(e[0] - this.x) / this.k, (e[1] - this.y) / this.k];
  },
  invertX: function (e) {
    return (e - this.x) / this.k;
  },
  invertY: function (e) {
    return (e - this.y) / this.k;
  },
  rescaleX: function (e) {
    return e.copy().domain(e.range().map(this.invertX, this).map(e.invert, e));
  },
  rescaleY: function (e) {
    return e.copy().domain(e.range().map(this.invertY, this).map(e.invert, e));
  },
  toString: function () {
    return `translate(` + this.x + `,` + this.y + `) scale(` + this.k + `)`;
  },
};
var Qp = new Zp(1, 0, 0);
$p.prototype = Zp.prototype;
function $p(e) {
  for (; !e.__zoom; ) if (!(e = e.parentNode)) return Qp;
  return e.__zoom;
}
function em(e) {
  e.stopImmediatePropagation();
}
function tm(e) {
  e.preventDefault(), e.stopImmediatePropagation();
}
function nm(e) {
  return (!e.ctrlKey || e.type === `wheel`) && !e.button;
}
function rm() {
  var e = this;
  return e instanceof SVGElement
    ? ((e = e.ownerSVGElement || e),
      e.hasAttribute(`viewBox`)
        ? ((e = e.viewBox.baseVal),
          [
            [e.x, e.y],
            [e.x + e.width, e.y + e.height],
          ])
        : [
            [0, 0],
            [e.width.baseVal.value, e.height.baseVal.value],
          ])
    : [
        [0, 0],
        [e.clientWidth, e.clientHeight],
      ];
}
function im() {
  return this.__zoom || Qp;
}
function am(e) {
  return (
    -e.deltaY *
    (e.deltaMode === 1 ? 0.05 : e.deltaMode ? 1 : 0.002) *
    (e.ctrlKey ? 10 : 1)
  );
}
function om() {
  return navigator.maxTouchPoints || `ontouchstart` in this;
}
function sm(e, t, n) {
  var r = e.invertX(t[0][0]) - n[0][0],
    i = e.invertX(t[1][0]) - n[1][0],
    a = e.invertY(t[0][1]) - n[0][1],
    o = e.invertY(t[1][1]) - n[1][1];
  return e.translate(
    i > r ? (r + i) / 2 : Math.min(0, r) || Math.max(0, i),
    o > a ? (a + o) / 2 : Math.min(0, a) || Math.max(0, o),
  );
}
function cm() {
  var e = nm,
    t = rm,
    n = sm,
    r = am,
    i = om,
    a = [0, 1 / 0],
    o = [
      [-1 / 0, -1 / 0],
      [1 / 0, 1 / 0],
    ],
    s = 250,
    c = ld,
    l = Xs(`start`, `zoom`, `end`),
    u,
    d,
    f,
    p = 500,
    m = 150,
    h = 0,
    g = 10;
  function _(e) {
    e.property(`__zoom`, im)
      .on(`wheel.zoom`, w, { passive: !1 })
      .on(`mousedown.zoom`, T)
      .on(`dblclick.zoom`, E)
      .filter(i)
      .on(`touchstart.zoom`, D)
      .on(`touchmove.zoom`, O)
      .on(`touchend.zoom touchcancel.zoom`, k)
      .style(`-webkit-tap-highlight-color`, `rgba(0,0,0,0)`);
  }
  (_.transform = function (e, t, n, r) {
    var i = e.selection ? e.selection() : e;
    i.property(`__zoom`, im),
      e === i
        ? i.interrupt().each(function () {
            S(this, arguments)
              .event(r)
              .start()
              .zoom(null, typeof t == `function` ? t.apply(this, arguments) : t)
              .end();
          })
        : x(e, t, n, r);
  }),
    (_.scaleBy = function (e, t, n, r) {
      _.scaleTo(
        e,
        function () {
          return (
            this.__zoom.k *
            (typeof t == `function` ? t.apply(this, arguments) : t)
          );
        },
        n,
        r,
      );
    }),
    (_.scaleTo = function (e, r, i, a) {
      _.transform(
        e,
        function () {
          var e = t.apply(this, arguments),
            a = this.__zoom,
            s =
              i == null
                ? b(e)
                : typeof i == `function`
                ? i.apply(this, arguments)
                : i,
            c = a.invert(s),
            l = typeof r == `function` ? r.apply(this, arguments) : r;
          return n(y(v(a, l), s, c), e, o);
        },
        i,
        a,
      );
    }),
    (_.translateBy = function (e, r, i, a) {
      _.transform(
        e,
        function () {
          return n(
            this.__zoom.translate(
              typeof r == `function` ? r.apply(this, arguments) : r,
              typeof i == `function` ? i.apply(this, arguments) : i,
            ),
            t.apply(this, arguments),
            o,
          );
        },
        null,
        a,
      );
    }),
    (_.translateTo = function (e, r, i, a, s) {
      _.transform(
        e,
        function () {
          var e = t.apply(this, arguments),
            s = this.__zoom,
            c =
              a == null
                ? b(e)
                : typeof a == `function`
                ? a.apply(this, arguments)
                : a;
          return n(
            Qp.translate(c[0], c[1])
              .scale(s.k)
              .translate(
                typeof r == `function` ? -r.apply(this, arguments) : -r,
                typeof i == `function` ? -i.apply(this, arguments) : -i,
              ),
            e,
            o,
          );
        },
        a,
        s,
      );
    });
  function v(e, t) {
    return (
      (t = Math.max(a[0], Math.min(a[1], t))),
      t === e.k ? e : new Zp(t, e.x, e.y)
    );
  }
  function y(e, t, n) {
    var r = t[0] - n[0] * e.k,
      i = t[1] - n[1] * e.k;
    return r === e.x && i === e.y ? e : new Zp(e.k, r, i);
  }
  function b(e) {
    return [(+e[0][0] + +e[1][0]) / 2, (+e[0][1] + +e[1][1]) / 2];
  }
  function x(e, n, r, i) {
    e.on(`start.zoom`, function () {
      S(this, arguments).event(i).start();
    })
      .on(`interrupt.zoom end.zoom`, function () {
        S(this, arguments).event(i).end();
      })
      .tween(`zoom`, function () {
        var e = this,
          a = arguments,
          o = S(e, a).event(i),
          s = t.apply(e, a),
          l = r == null ? b(s) : typeof r == `function` ? r.apply(e, a) : r,
          u = Math.max(s[1][0] - s[0][0], s[1][1] - s[0][1]),
          d = e.__zoom,
          f = typeof n == `function` ? n.apply(e, a) : n,
          p = c(d.invert(l).concat(u / d.k), f.invert(l).concat(u / f.k));
        return function (e) {
          if (e === 1) e = f;
          else {
            var t = p(e),
              n = u / t[2];
            e = new Zp(n, l[0] - t[0] * n, l[1] - t[1] * n);
          }
          o.zoom(null, e);
        };
      });
  }
  function S(e, t, n) {
    return (!n && e.__zooming) || new C(e, t);
  }
  function C(e, n) {
    (this.that = e),
      (this.args = n),
      (this.active = 0),
      (this.sourceEvent = null),
      (this.extent = t.apply(e, n)),
      (this.taps = 0);
  }
  C.prototype = {
    event: function (e) {
      return e && (this.sourceEvent = e), this;
    },
    start: function () {
      return (
        ++this.active === 1 &&
          ((this.that.__zooming = this), this.emit(`start`)),
        this
      );
    },
    zoom: function (e, t) {
      return (
        this.mouse &&
          e !== `mouse` &&
          (this.mouse[1] = t.invert(this.mouse[0])),
        this.touch0 &&
          e !== `touch` &&
          (this.touch0[1] = t.invert(this.touch0[0])),
        this.touch1 &&
          e !== `touch` &&
          (this.touch1[1] = t.invert(this.touch1[0])),
        (this.that.__zoom = t),
        this.emit(`zoom`),
        this
      );
    },
    end: function () {
      return (
        --this.active === 0 && (delete this.that.__zooming, this.emit(`end`)),
        this
      );
    },
    emit: function (e) {
      var t = Yl(this.that).datum();
      l.call(
        e,
        this.that,
        new Xp(e, {
          sourceEvent: this.sourceEvent,
          target: _,
          type: e,
          transform: this.that.__zoom,
          dispatch: l,
        }),
        t,
      );
    },
  };
  function w(t, ...i) {
    if (!e.apply(this, arguments)) return;
    var s = S(this, i).event(t),
      c = this.__zoom,
      l = Math.max(a[0], Math.min(a[1], c.k * 2 ** r.apply(this, arguments))),
      u = Zl(t);
    if (s.wheel)
      (s.mouse[0][0] !== u[0] || s.mouse[0][1] !== u[1]) &&
        (s.mouse[1] = c.invert((s.mouse[0] = u))),
        clearTimeout(s.wheel);
    else if (c.k === l) return;
    else (s.mouse = [u, c.invert(u)]), Id(this), s.start();
    tm(t),
      (s.wheel = setTimeout(d, m)),
      s.zoom(`mouse`, n(y(v(c, l), s.mouse[0], s.mouse[1]), s.extent, o));
    function d() {
      (s.wheel = null), s.end();
    }
  }
  function T(t, ...r) {
    if (f || !e.apply(this, arguments)) return;
    var i = t.currentTarget,
      a = S(this, r, !0).event(t),
      s = Yl(t.view).on(`mousemove.zoom`, d, !0).on(`mouseup.zoom`, p, !0),
      c = Zl(t, i),
      l = t.clientX,
      u = t.clientY;
    eu(t.view),
      em(t),
      (a.mouse = [c, this.__zoom.invert(c)]),
      Id(this),
      a.start();
    function d(e) {
      if ((tm(e), !a.moved)) {
        var t = e.clientX - l,
          r = e.clientY - u;
        a.moved = t * t + r * r > h;
      }
      a.event(e).zoom(
        `mouse`,
        n(y(a.that.__zoom, (a.mouse[0] = Zl(e, i)), a.mouse[1]), a.extent, o),
      );
    }
    function p(e) {
      s.on(`mousemove.zoom mouseup.zoom`, null),
        tu(e.view, a.moved),
        tm(e),
        a.event(e).end();
    }
  }
  function E(r, ...i) {
    if (e.apply(this, arguments)) {
      var a = this.__zoom,
        c = Zl(r.changedTouches ? r.changedTouches[0] : r, this),
        l = a.invert(c),
        u = a.k * (r.shiftKey ? 0.5 : 2),
        d = n(y(v(a, u), c, l), t.apply(this, i), o);
      tm(r),
        s > 0
          ? Yl(this).transition().duration(s).call(x, d, c, r)
          : Yl(this).call(_.transform, d, c, r);
    }
  }
  function D(t, ...n) {
    if (e.apply(this, arguments)) {
      var r = t.touches,
        i = r.length,
        a = S(this, n, t.changedTouches.length === i).event(t),
        o,
        s,
        c,
        l;
      for (em(t), s = 0; s < i; ++s)
        (c = r[s]),
          (l = Zl(c, this)),
          (l = [l, this.__zoom.invert(l), c.identifier]),
          a.touch0
            ? !a.touch1 &&
              a.touch0[2] !== l[2] &&
              ((a.touch1 = l), (a.taps = 0))
            : ((a.touch0 = l), (o = !0), (a.taps = 1 + !!u));
      (u &&= clearTimeout(u)),
        o &&
          (a.taps < 2 &&
            ((d = l[0]),
            (u = setTimeout(function () {
              u = null;
            }, p))),
          Id(this),
          a.start());
    }
  }
  function O(e, ...t) {
    if (this.__zooming) {
      var r = S(this, t).event(e),
        i = e.changedTouches,
        a = i.length,
        s,
        c,
        l,
        u;
      for (tm(e), s = 0; s < a; ++s)
        (c = i[s]),
          (l = Zl(c, this)),
          r.touch0 && r.touch0[2] === c.identifier
            ? (r.touch0[0] = l)
            : r.touch1 && r.touch1[2] === c.identifier && (r.touch1[0] = l);
      if (((c = r.that.__zoom), r.touch1)) {
        var d = r.touch0[0],
          f = r.touch0[1],
          p = r.touch1[0],
          m = r.touch1[1],
          h = (h = p[0] - d[0]) * h + (h = p[1] - d[1]) * h,
          g = (g = m[0] - f[0]) * g + (g = m[1] - f[1]) * g;
        (c = v(c, Math.sqrt(h / g))),
          (l = [(d[0] + p[0]) / 2, (d[1] + p[1]) / 2]),
          (u = [(f[0] + m[0]) / 2, (f[1] + m[1]) / 2]);
      } else if (r.touch0) (l = r.touch0[0]), (u = r.touch0[1]);
      else return;
      r.zoom(`touch`, n(y(c, l, u), r.extent, o));
    }
  }
  function k(e, ...t) {
    if (this.__zooming) {
      var n = S(this, t).event(e),
        r = e.changedTouches,
        i = r.length,
        a,
        o;
      for (
        em(e),
          f && clearTimeout(f),
          f = setTimeout(function () {
            f = null;
          }, p),
          a = 0;
        a < i;
        ++a
      )
        (o = r[a]),
          n.touch0 && n.touch0[2] === o.identifier
            ? delete n.touch0
            : n.touch1 && n.touch1[2] === o.identifier && delete n.touch1;
      if (
        (n.touch1 && !n.touch0 && ((n.touch0 = n.touch1), delete n.touch1),
        n.touch0)
      )
        n.touch0[1] = this.__zoom.invert(n.touch0[0]);
      else if (
        (n.end(),
        n.taps === 2 &&
          ((o = Zl(o, this)), Math.hypot(d[0] - o[0], d[1] - o[1]) < g))
      ) {
        var s = Yl(this).on(`dblclick.zoom`);
        s && s.apply(this, arguments);
      }
    }
  }
  return (
    (_.wheelDelta = function (e) {
      return arguments.length
        ? ((r = typeof e == `function` ? e : Yp(+e)), _)
        : r;
    }),
    (_.filter = function (t) {
      return arguments.length
        ? ((e = typeof t == `function` ? t : Yp(!!t)), _)
        : e;
    }),
    (_.touchable = function (e) {
      return arguments.length
        ? ((i = typeof e == `function` ? e : Yp(!!e)), _)
        : i;
    }),
    (_.extent = function (e) {
      return arguments.length
        ? ((t =
            typeof e == `function`
              ? e
              : Yp([
                  [+e[0][0], +e[0][1]],
                  [+e[1][0], +e[1][1]],
                ])),
          _)
        : t;
    }),
    (_.scaleExtent = function (e) {
      return arguments.length
        ? ((a[0] = +e[0]), (a[1] = +e[1]), _)
        : [a[0], a[1]];
    }),
    (_.translateExtent = function (e) {
      return arguments.length
        ? ((o[0][0] = +e[0][0]),
          (o[1][0] = +e[1][0]),
          (o[0][1] = +e[0][1]),
          (o[1][1] = +e[1][1]),
          _)
        : [
            [o[0][0], o[0][1]],
            [o[1][0], o[1][1]],
          ];
    }),
    (_.constrain = function (e) {
      return arguments.length ? ((n = e), _) : n;
    }),
    (_.duration = function (e) {
      return arguments.length ? ((s = +e), _) : s;
    }),
    (_.interpolate = function (e) {
      return arguments.length ? ((c = e), _) : c;
    }),
    (_.on = function () {
      var e = l.on.apply(l, arguments);
      return e === l ? _ : e;
    }),
    (_.clickDistance = function (e) {
      return arguments.length ? ((h = (e = +e) * e), _) : Math.sqrt(h);
    }),
    (_.tapDistance = function (e) {
      return arguments.length ? ((g = +e), _) : g;
    }),
    _
  );
}
function lm(e, t = document) {
  let n = t.querySelector(e);
  if (!n) throw Error(`HTML Element with selector ${e} not found`);
  return n;
}
var um = 6,
  $ = { top: 10, right: 90, bottom: 30, left: 90 },
  dm,
  fm,
  pm,
  mm,
  hm = [];
function gm(e, t, n, r, i) {
  (dm = e), (fm = n), (pm = r), (mm = t), (hm = i);
  let a = _m(),
    o = vm(),
    s = ym(o),
    c = s.append(`g`).attr(`transform`, `translate(${$.left}, 0)`);
  xm(bm(o), c, a),
    Sm(s, c),
    Dm(a, s),
    Om(a, s),
    Em(a, s),
    km(),
    Am(),
    Cm(),
    jm();
}
function _m() {
  return {
    indexSlider: lm(`#indexSlider`),
    sliderValue: lm(`#sliderValue`),
    incrementButton: lm(`#incrementButton`),
    decrementButton: lm(`#decrementButton`),
    iterationInfo: lm(`#iteration-info`),
    iterationSolutionDetails: lm(`#iteration-solution-details`),
  };
}
function vm() {
  let e = lm(`.graph-container`);
  return {
    width: e.getBoundingClientRect().width - $.left - $.right,
    height: 0.8 * e.getBoundingClientRect().width - $.bottom - $.top,
  };
}
function ym(e) {
  return Yl(`#bnb-graph`)
    .attr(`viewBox`, [
      0,
      0,
      e.width + $.left + $.right,
      e.height + $.top + $.bottom,
    ])
    .attr(`width`, `100%`)
    .attr(`height`, `100%`);
}
function bm(e) {
  let t = Sp(dm);
  return Lp().size([e.width, e.height])(t), t;
}
function xm(e, t, n) {
  t.selectAll(`.link`)
    .data(e.links())
    .enter()
    .append(`path`)
    .attr(`class`, `link`)
    .attr(
      `d`,
      Jp()
        .x((e) => e.y ?? 0)
        .y((e) => e.x ?? 0),
    );
  let r = t
    .selectAll(`.node`)
    .data(e.descendants())
    .enter()
    .append(`g`)
    .attr(`class`, `node`)
    .attr(`transform`, (e) => `translate(${e.y},${e.x})`);
  r
    .append(`circle`)
    .attr(`r`, um)
    .style(`fill`, (e) => e.data.color)
    .style(`cursor`, (e) =>
      e.data.processed_at === null ? `default` : `pointer`,
    )
    .on(`click`, (e, t) => {
      let r = t.data.processed_at;
      r !== null &&
        ((n.indexSlider.value = String(r)), Em(n, Yl(`#bnb-graph`)));
    })
    .attr(`data-bs-toggle`, `tooltip`)
    .attr(`data-bs-custom-class`, `node-tooltip`)
    .attr(`data-bs-title`, (e) =>
      e.data.node_id ? mm[e.data.node_id] : `No Tooltip found for this node`,
    ),
    r
      .append(`text`)
      .attr(`dy`, `0.35em`)
      .attr(`x`, (e) => (e.children ? -13 : 13))
      .style(`text-anchor`, (e) => (e.children ? `end` : `start`))
      .text((e) => e.data.label);
}
function Sm(e, t) {
  let n = cm()
    .scaleExtent([0.5, 8])
    .on(`zoom`, (e) => t.attr(`transform`, e.transform));
  e.call(n).on(`wheel`, (e) => e.preventDefault());
}
function Cm() {
  new Tablesort(document.getElementById(`instance-table`));
}
function wm(e, t) {
  function n(t) {
    return t.data.created_at > Number(e.value)
      ? 0.1
      : t.data.processed_at === null ||
        t.data.processed_at === void 0 ||
        t.data.processed_at > Number(e.value)
      ? 0.5
      : 1;
  }
  t.selectAll(`.node circle`).style(`opacity`, n),
    t.selectAll(`.node text`).style(`opacity`, n),
    t
      .selectAll(`.link`)
      .style(`opacity`, (e) => Math.min(n(e.source), n(e.target)));
}
function Tm(e, t) {
  t
    .selectAll(`.node circle`)
    .attr(`r`, (t) => (t.data.processed_at === Number(e.value) ? um * 1.8 : um))
    .classed(`current-node`, (t) => t.data.processed_at === Number(e.value)),
    wm(e, t);
}
function Em(e, t) {
  let n = hm[Number(e.indexSlider.value)];
  e.sliderValue.textContent = e.indexSlider.value;
  let r = fm[n] || `No iteration info available.`;
  (e.iterationInfo.innerHTML = r),
    new Tablesort(document.getElementById(`iteration-table`));
  let i = pm[n] || `No iteration solution details available.`;
  (e.iterationSolutionDetails.innerHTML = i), Tm(e.indexSlider, t);
}
function Dm(e, t) {
  e.indexSlider.addEventListener(`input`, () => {
    Em(e, t);
  });
}
function Om(e, t) {
  e.incrementButton.addEventListener(`click`, () => {
    Number(e.indexSlider.value) < Number(e.indexSlider.max) &&
      ((e.indexSlider.value = String(Number(e.indexSlider.value) + 1)),
      Em(e, t));
  }),
    e.decrementButton.addEventListener(`click`, () => {
      Number(e.indexSlider.value) > Number(e.indexSlider.min) &&
        ((e.indexSlider.value = String(Number(e.indexSlider.value) - 1)),
        Em(e, t));
    });
}
function km() {
  document.addEventListener(`show.bs.collapse`, (e) => {
    let t = e.target,
      n = t
        ? document.querySelector(`.js-eye-icon[data-bs-target="#${t.id}"]`)
        : null;
    n &&
      (n.classList.remove(`bi-eye-slash-fill`), n.classList.add(`bi-eye-fill`));
  }),
    document.addEventListener(`hide.bs.collapse`, (e) => {
      let t = e.target,
        n = t
          ? document.querySelector(`.js-eye-icon[data-bs-target="#${t.id}"]`)
          : null;
      n &&
        (n.classList.remove(`bi-eye-fill`),
        n.classList.add(`bi-eye-slash-fill`));
    });
}
function Am() {
  //! This is just a monkey-patch, might change behavior in future bootstrap versions
  let e = Oo.prototype._leave;
  (Oo.prototype._leave = function () {
    e.call(this);
    let t = this.tip,
      n = this._timeout;
    t &&
      t.addEventListener(
        `mouseenter`,
        () => {
          clearTimeout(n),
            t.addEventListener(
              `mouseleave`,
              () => {
                this.hide();
              },
              { once: !0 },
            );
        },
        { once: !0 },
      );
  }),
    [].slice
      .call(document.querySelectorAll(`[data-bs-toggle="tooltip"]`))
      .map((e) => new Oo(e, { html: !0, delay: { show: 50, hide: 200 } }));
}
function jm() {
  document.querySelectorAll(`.split-container`).forEach((e) => {
    let t = lm(
        e.dataset.panelDivider ? e.dataset.panelDivider : `.panel-divider`,
        e,
      ),
      n = lm(`.panel-left`, e),
      r = !1;
    t.addEventListener(`mousedown`, (i) => {
      (r = !0),
        (document.body.style.cursor = `col-resize`),
        t.classList.add(`active`),
        document.addEventListener(`mousemove`, a),
        document.addEventListener(`mouseup`, o);
      function a(t) {
        if (!r) return;
        let i = e.getBoundingClientRect();
        i.right <= t.clientX || (n.style.flexBasis = t.clientX - i.left + `px`);
      }
      function o(e) {
        (r = !1),
          (document.body.style.cursor = `default`),
          t.classList.remove(`active`),
          document.removeEventListener(`mousemove`, a),
          document.removeEventListener(`mouseup`, o);
      }
    });
  });
}
document.addEventListener(`DOMContentLoaded`, () => {
  let e = BNB_DATA;
  gm(
    e.treeData,
    e.node_tooltips,
    e.iteration_info,
    e.iteration_solution_details,
    e.iterations,
  );
});
